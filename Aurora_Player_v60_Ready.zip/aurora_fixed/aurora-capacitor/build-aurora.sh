#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  build-aurora.sh — بناء Aurora Player APK v3
# ═══════════════════════════════════════════════════════════
set -e

echo "🎵 بدء بناء Aurora Player APK..."

# 1. Android SDK
echo "📦 إعداد Android SDK..."
cd ~
if [ ! -d "android-sdk/cmdline-tools/latest" ]; then
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O cmdtools.zip
    mkdir -p android-sdk/cmdline-tools
    unzip -q cmdtools.zip -d android-sdk/cmdline-tools
    mv android-sdk/cmdline-tools/cmdline-tools android-sdk/cmdline-tools/latest
    rm cmdtools.zip
fi
export ANDROID_HOME=~/android-sdk
export ANDROID_SDK_ROOT=~/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
yes | sdkmanager --licenses > /dev/null 2>&1
sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools" --quiet
echo "✅ Android SDK جاهز"

# 2. Capacitor
cd ~/aurora-capacitor
echo "📦 تثبيت npm packages..."
npm install --quiet
echo "🔧 إعداد Capacitor..."
npx cap add android 2>/dev/null || true
npx cap sync android --quiet
echo "✅ Capacitor جاهز"

# 3. نسخ الـ Plugins الأصلية
echo "🔌 نسخ Plugins الأصلية..."
PKG="android/app/src/main/java/com/aurora/player"
mkdir -p $PKG
cp android-plugins/src/main/java/com/aurora/player/*.java $PKG/
echo "✅ Plugins منسوخة"

# 4. AndroidManifest.xml
echo "📝 تحديث AndroidManifest..."
MANIFEST="android/app/src/main/AndroidManifest.xml"

# تجنب التكرار
if ! grep -q "FOREGROUND_SERVICE" $MANIFEST; then
    sed -i 's|<uses-permission android:name="android.permission.INTERNET" />|<uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />\n    <uses-permission android:name="android.permission.WAKE_LOCK" />\n    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />\n    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />|' $MANIFEST
fi

# إضافة MediaService
if ! grep -q "MediaService" $MANIFEST; then
    sed -i 's|</application>|        <service\n            android:name="com.aurora.player.MediaService"\n            android:foregroundServiceType="mediaPlayback"\n            android:exported="false" />\n    </application>|' $MANIFEST
fi
echo "✅ AndroidManifest محدّث"

# 5. تسجيل Plugins في MainActivity
echo "🔧 تسجيل Plugins..."
MAIN=$(find android -name "MainActivity.java" | head -1)
if [ -n "$MAIN" ] && ! grep -q "AuroraMediaPlugin" "$MAIN"; then
    sed -i 's|import com.getcapacitor.BridgeActivity;|import com.getcapacitor.BridgeActivity;\nimport com.aurora.player.AuroraMediaPlugin;\nimport com.aurora.player.AuroraFilesPlugin;|' "$MAIN"
    sed -i 's|public class MainActivity extends BridgeActivity {|public class MainActivity extends BridgeActivity {\n  @Override\n  public void onCreate(android.os.Bundle savedInstanceState) {\n    registerPlugin(AuroraMediaPlugin.class);\n    registerPlugin(AuroraFilesPlugin.class);\n    super.onCreate(savedInstanceState);\n  }|' "$MAIN"
fi
echo "✅ MainActivity محدّثة"

# 6. إضافة مكتبة media compat
echo "📦 تحديث build.gradle..."
BUILD="android/app/build.gradle"
if ! grep -q "androidx.media:media" "$BUILD"; then
    # إضافة media compat قبل آخر سطر في dependencies {}
    sed -i '/^}/i\    implementation "androidx.media:media:1.7.0"' "$BUILD"
    echo "  ← تم إضافة androidx.media:media"
fi
echo "✅ build.gradle محدّث"

# 7. بناء APK
echo ""
echo "🔨 بناء APK (قد يستغرق 10-15 دقيقة)..."
cd android
chmod +x gradlew
./gradlew assembleDebug --quiet

# 8. نسخ النتيجة
cp app/build/outputs/apk/debug/app-debug.apk ~/Aurora_Player_v60.apk
echo ""
echo "✅══════════════════════════════════════✅"
echo "   Aurora Player APK جاهز!"
echo ""
echo "   لتحميله على هاتفك:"
echo "   cloudshell download ~/Aurora_Player_v60.apk"
echo "✅══════════════════════════════════════✅"

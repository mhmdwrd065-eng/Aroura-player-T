package com.aurora.player;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.IBinder;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "AuroraMedia")
public class AuroraMediaPlugin extends Plugin implements MediaService.MediaEventListener {

    private MediaService mediaService;
    private boolean bound = false;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            MediaService.LocalBinder lb = (MediaService.LocalBinder) binder;
            mediaService = lb.getService();
            MediaService.setEventListener(AuroraMediaPlugin.this);
            bound = true;
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            bound = false;
        }
    };

    @Override
    public void load() {
        Intent intent = new Intent(getContext(), MediaService.class);
        getContext().bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    // ── يُستدعى من JavaScript لتحديث الإشعار ──────────────────────────
    @PluginMethod
    public void updateNotification(PluginCall call) {
        String title    = call.getString("title", "Aurora Player");
        String artist   = call.getString("artist", "");
        String album    = call.getString("album", "");
        boolean playing = Boolean.TRUE.equals(call.getBoolean("isPlaying", false));
        String artBase64 = call.getString("artwork", null);

        Intent intent = new Intent(getContext(), MediaService.class);
        intent.setAction(MediaService.ACTION_UPDATE);
        intent.putExtra("title",     title);
        intent.putExtra("artist",    artist);
        intent.putExtra("album",     album);
        intent.putExtra("isPlaying", playing);

        if (artBase64 != null && !artBase64.isEmpty()) {
            try {
                String b64 = artBase64.contains(",")
                    ? artBase64.substring(artBase64.indexOf(",") + 1)
                    : artBase64;
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bmp != null) {
                    // تصغير الصورة لتجنب تجاوز حجم Intent
                    Bitmap scaled = Bitmap.createScaledBitmap(bmp, 256, 256, true);
                    java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                    scaled.compress(Bitmap.CompressFormat.JPEG, 80, baos);
                    intent.putExtra("artwork", baos.toByteArray());
                }
            } catch (Exception e) { /* تجاهل خطأ الصورة */ }
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            getContext().startForegroundService(intent);
        } else {
            getContext().startService(intent);
        }
        call.resolve();
    }

    @PluginMethod
    public void destroy(PluginCall call) {
        getContext().stopService(new Intent(getContext(), MediaService.class));
        call.resolve();
    }

    // ── أحداث الأزرار من الإشعار → JavaScript ──────────────────────────
    @Override public void onPlay()  { notifyJS("play");  }
    @Override public void onPause() { notifyJS("pause"); }
    @Override public void onNext()  { notifyJS("next");  }
    @Override public void onPrev()  { notifyJS("prev");  }

    private void notifyJS(String action) {
        JSObject data = new JSObject();
        data.put("action", action);
        notifyListeners("mediaControl", data);
    }
}

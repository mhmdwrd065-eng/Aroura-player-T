package com.aurora.player;

import android.app.Activity;
import android.content.Intent;
import android.content.UriPermission;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import java.util.ArrayList;
import java.util.List;

@CapacitorPlugin(
    name = "AuroraFiles",
    permissions = {
        @Permission(strings = {"android.permission.READ_MEDIA_AUDIO"},    alias = "readAudio"),
        @Permission(strings = {"android.permission.READ_EXTERNAL_STORAGE"}, alias = "readStorage")
    }
)
public class AuroraFilesPlugin extends Plugin {

    private static final String PREF_NAME      = "aurora_prefs";
    private static final String PREF_FOLDER_URI = "aurora_folder_uri";

    // ── فتح منتقي المجلدات ──────────────────────────────────────────
    @PluginMethod
    public void pickFolder(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION |
            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        );
        startActivityForResult(call, intent, "folderPickerResult");
    }

    @ActivityCallback
    private void folderPickerResult(PluginCall call, com.getcapacitor.ActivityResult result) {
        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            Uri uri = result.getData().getData();

            // حفظ الصلاحية بشكل دائم
            getActivity().getContentResolver().takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            );

            // حفظ URI في SharedPreferences
            getActivity().getSharedPreferences(PREF_NAME, 0)
                .edit().putString(PREF_FOLDER_URI, uri.toString()).apply();

            JSObject res = new JSObject();
            res.put("uri", uri.toString());
            call.resolve(res);
        } else {
            call.reject("USER_CANCELLED");
        }
    }

    // ── استعادة المجلد المحفوظ ───────────────────────────────────────
    @PluginMethod
    public void getSavedFolder(PluginCall call) {
        String savedUri = getActivity()
            .getSharedPreferences(PREF_NAME, 0)
            .getString(PREF_FOLDER_URI, null);

        if (savedUri == null) { call.resolve(new JSObject()); return; }

        // تحقق من صلاحية دائمة
        boolean valid = false;
        for (UriPermission p : getActivity().getContentResolver().getPersistedUriPermissions()) {
            if (p.getUri().toString().equals(savedUri) && p.isReadPermission()) {
                valid = true; break;
            }
        }

        if (valid) {
            JSObject res = new JSObject();
            res.put("uri", savedUri);
            call.resolve(res);
        } else {
            getActivity().getSharedPreferences(PREF_NAME, 0)
                .edit().remove(PREF_FOLDER_URI).apply();
            call.resolve(new JSObject());
        }
    }

    // ── قائمة ملفات الصوت من مجلد URI ────────────────────────────────
    @PluginMethod
    public void listAudioFiles(PluginCall call) {
        String folderUriStr = call.getString("uri");
        if (folderUriStr == null) { call.reject("URI مطلوب"); return; }

        try {
            Uri treeUri = Uri.parse(folderUriStr);
            Uri childUri = DocumentsContract.buildChildDocumentsUriUsingTree(
                treeUri, DocumentsContract.getTreeDocumentId(treeUri)
            );

            List<JSObject> result = new ArrayList<>();
            scanDocs(childUri, treeUri, result);

            JSArray arr = new JSArray();
            for (JSObject f : result) arr.put(f);

            JSObject res = new JSObject();
            res.put("files", arr);
            call.resolve(res);

        } catch (Exception e) {
            call.reject("خطأ: " + e.getMessage());
        }
    }

    private void scanDocs(Uri childUri, Uri treeUri, List<JSObject> out) {
        String[] proj = {
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        };
        try (Cursor c = getActivity().getContentResolver().query(childUri, proj, null, null, null)) {
            if (c == null) return;
            while (c.moveToNext()) {
                String id   = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                long   size = c.getLong(3);

                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    // مجلد فرعي — مسح تكراري
                    Uri sub = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, id);
                    scanDocs(sub, treeUri, out);
                } else if (isMedia(mime, name)) {
                    // صوت + صور أغلفة + ملفات كلمات
                    Uri fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id);

                    JSObject f = new JSObject();
                    f.put("name", name);
                    f.put("uri",  fileUri.toString());
                    f.put("mime", mime != null ? mime : mimeFromName(name));
                    f.put("size", size);
                    out.add(f);
                }
            }
        } catch (Exception e) { /* تخطّي أخطاء جزئية */ }
    }

    // يشمل الصوت + صور الأغلفة + ملفات الكلمات
    private boolean isMedia(String mime, String name) {
        if (mime != null) {
            if (mime.startsWith("audio/")) return true;
            if (mime.startsWith("image/")) return true;
            if (mime.equals("text/plain")) {
                // قد يكون lrc/srt
                String n = (name != null ? name : "").toLowerCase();
                return n.endsWith(".lrc") || n.endsWith(".srt");
            }
        }
        String n = (name != null ? name : "").toLowerCase();
        // صوت
        if (n.endsWith(".mp3") || n.endsWith(".flac") || n.endsWith(".ogg") ||
            n.endsWith(".m4a") || n.endsWith(".wav")  || n.endsWith(".aac") ||
            n.endsWith(".wma") || n.endsWith(".opus")) return true;
        // صور أغلفة
        if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") ||
            n.endsWith(".webp") || n.endsWith(".bmp")) return true;
        // كلمات
        if (n.endsWith(".lrc") || n.endsWith(".srt")) return true;
        return false;
    }

    private String mimeFromName(String name) {
        if (name == null) return "audio/mpeg";
        String n = name.toLowerCase();
        if (n.endsWith(".mp3"))  return "audio/mpeg";
        if (n.endsWith(".flac")) return "audio/flac";
        if (n.endsWith(".ogg"))  return "audio/ogg";
        if (n.endsWith(".m4a"))  return "audio/mp4";
        if (n.endsWith(".aac"))  return "audio/aac";
        if (n.endsWith(".wav"))  return "audio/wav";
        if (n.endsWith(".wma"))  return "audio/x-ms-wma";
        if (n.endsWith(".opus")) return "audio/opus";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".png"))  return "image/png";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".bmp"))  return "image/bmp";
        if (n.endsWith(".lrc"))  return "text/lrc";
        if (n.endsWith(".srt"))  return "text/srt";
        return "audio/mpeg";
    }
}

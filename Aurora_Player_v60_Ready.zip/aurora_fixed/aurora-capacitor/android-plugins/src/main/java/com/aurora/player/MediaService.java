package com.aurora.player;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import androidx.core.app.NotificationCompat;
import androidx.media.app.NotificationCompat.MediaStyle;

public class MediaService extends Service {

    public static final String CHANNEL_ID = "aurora_media_channel";
    public static final String ACTION_PLAY   = "com.aurora.player.PLAY";
    public static final String ACTION_PAUSE  = "com.aurora.player.PAUSE";
    public static final String ACTION_NEXT   = "com.aurora.player.NEXT";
    public static final String ACTION_PREV   = "com.aurora.player.PREV";
    public static final String ACTION_STOP   = "com.aurora.player.STOP";
    public static final String ACTION_UPDATE  = "com.aurora.player.UPDATE";

    private static final int NOTIFICATION_ID = 1;

    private MediaSessionCompat mediaSession;
    private final IBinder binder = new LocalBinder();

    // حالة التشغيل الحالية
    private String title   = "Aurora Player";
    private String artist  = "";
    private String album   = "";
    private boolean isPlaying = false;
    private Bitmap artwork = null;

    // Listener لإرسال الأحداث للـ Plugin
    public interface MediaEventListener {
        void onPlay();
        void onPause();
        void onNext();
        void onPrev();
    }
    private static MediaEventListener eventListener;

    public static void setEventListener(MediaEventListener l) { eventListener = l; }

    public class LocalBinder extends Binder {
        public MediaService getService() { return MediaService.this; }
    }

    private final BroadcastReceiver mediaReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null || eventListener == null) return;
            switch (action) {
                case ACTION_PLAY:   eventListener.onPlay();  break;
                case ACTION_PAUSE:  eventListener.onPause(); break;
                case ACTION_NEXT:   eventListener.onNext();  break;
                case ACTION_PREV:   eventListener.onPrev();  break;
                case ACTION_STOP:   stopForeground(true); stopSelf(); break;
                case android.content.Intent.ACTION_MEDIA_BUTTON: {
                    android.view.KeyEvent key = intent.getParcelableExtra(android.content.Intent.EXTRA_KEY_EVENT);
                    if (key != null && key.getAction() == android.view.KeyEvent.ACTION_DOWN) {
                        switch (key.getKeyCode()) {
                            case android.view.KeyEvent.KEYCODE_MEDIA_PLAY:   eventListener.onPlay();  break;
                            case android.view.KeyEvent.KEYCODE_MEDIA_PAUSE:  eventListener.onPause(); break;
                            case android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: eventListener.onPlay(); break;
                            case android.view.KeyEvent.KEYCODE_MEDIA_NEXT:   eventListener.onNext();  break;
                            case android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS: eventListener.onPrev(); break;
                        }
                    }
                    break;
                }
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();

        mediaSession = new MediaSessionCompat(this, "AuroraPlayer");
        mediaSession.setActive(true);

        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_PLAY);
        filter.addAction(ACTION_PAUSE);
        filter.addAction(ACTION_NEXT);
        filter.addAction(ACTION_PREV);
        filter.addAction(ACTION_STOP);
        filter.addAction(android.content.Intent.ACTION_MEDIA_BUTTON);
        filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(mediaReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(mediaReceiver, filter);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_UPDATE.equals(intent.getAction())) {
            title     = intent.getStringExtra("title");
            artist    = intent.getStringExtra("artist");
            album     = intent.getStringExtra("album");
            isPlaying = intent.getBooleanExtra("isPlaying", false);

            byte[] artBytes = intent.getByteArrayExtra("artwork");
            if (artBytes != null) {
                artwork = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.length);
            }
            updateNotification();
        }
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Aurora Media Player",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("تحكم في تشغيل الموسيقى");
            channel.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    public void updateNotification() {
        Intent mainIntent = getPackageManager()
            .getLaunchIntentForPackage(getPackageName());
        PendingIntent contentIntent = PendingIntent.getActivity(
            this, 0, mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // أزرار التحكم
        PendingIntent prevIntent  = buildAction(ACTION_PREV, 0);
        PendingIntent playIntent  = buildAction(isPlaying ? ACTION_PAUSE : ACTION_PLAY, 1);
        PendingIntent nextIntent  = buildAction(ACTION_NEXT, 2);

        // تحديث MediaSession metadata
        MediaMetadataCompat.Builder meta = new MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE,  title)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist)
            .putString(MediaMetadataCompat.METADATA_KEY_ALBUM,  album);
        if (artwork != null) {
            meta.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, artwork);
        }
        mediaSession.setMetadata(meta.build());

        PlaybackStateCompat.Builder state = new PlaybackStateCompat.Builder()
            .setActions(PlaybackStateCompat.ACTION_PLAY |
                        PlaybackStateCompat.ACTION_PAUSE |
                        PlaybackStateCompat.ACTION_SKIP_TO_NEXT |
                        PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS)
            .setState(
                isPlaying ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED,
                PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 1f
            );
        mediaSession.setPlaybackState(state.build());

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(getResources().getIdentifier("ic_launcher", "mipmap", getPackageName()))
            .setContentTitle(title)
            .setContentText(artist)
            .setSubText(album)
            .setContentIntent(contentIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOnlyAlertOnce(true)
            .setOngoing(isPlaying)
            .addAction(android.R.drawable.ic_media_previous, "السابق", prevIntent)
            .addAction(
                isPlaying ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                isPlaying ? "إيقاف" : "تشغيل", playIntent
            )
            .addAction(android.R.drawable.ic_media_next, "التالي", nextIntent)
            .setStyle(new MediaStyle()
                .setMediaSession(mediaSession.getSessionToken())
                .setShowActionsInCompactView(0, 1, 2));

        if (artwork != null) builder.setLargeIcon(artwork);

        Notification notification = builder.build();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private PendingIntent buildAction(String action, int requestCode) {
        Intent intent = new Intent(action);
        intent.setPackage(getPackageName());
        return PendingIntent.getBroadcast(
            this, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // عند إغلاق التطبيق من قائمة التطبيقات الأخيرة
        stopForeground(true);
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        stopForeground(true);
        try { unregisterReceiver(mediaReceiver); } catch(Exception e) {}
        if (mediaSession != null) {
            mediaSession.setActive(false);
            mediaSession.release();
            mediaSession = null;
        }
        super.onDestroy();
    }
}

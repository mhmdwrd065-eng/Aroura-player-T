/**
 * Aurora Player – Service Worker (v60)
 * ─────────────────────────────────────────────────────────────────────────────
 * ✅ يعمل في البيئة المحلية (localhost)
 * ✅ يعمل في الإنتاج (HTTPS)
 * ✅ دعم كامل للعمل بدون إنترنت (Offline First)
 * ✅ اختصارات PWA لا تُعيد تحميل الصفحة
 */

'use strict';

const APP_VERSION = 'v60';
const CACHE_SHELL = 'aurora-shell-v60';
const CACHE_ICONS = 'aurora-icons-v60';

// هل نحن في بيئة محلية؟
const IS_LOCAL =
  self.location.hostname === 'localhost' ||
  self.location.hostname === '127.0.0.1' ||
  self.location.hostname === '' ||
  self.location.protocol === 'file:';

const log = (...a) => console.log('[Aurora SW]', ...a);

const SHELL_ASSETS = [
  './', './index.html', './style.css', './manifest.json', './music-metadata.js',
  './js/01-globals.js', './js/02-utils.js', './js/03-file-maps.js',
  './js/04-audio-engine.js', './js/05-file-manager.js', './js/06-player.js',
  './js/07-media-session.js', './js/08-lyrics.js', './js/09-navigation.js',
  './js/10-playlist.js', './js/11-ui.js', './js/12-visualizer.js',
  './js/13-visualizer-controls.js', './js/14-eq.js', './js/15-context-menu.js',
  './js/16-long-press-events.js', './js/17-keyboard.js', './js/18-fullscreen.js',
  './js/19-sleep-timer.js', './js/20-cover-swipe-and-init.js',
  './js/21-playback-speed.js',
];

const ICON_ASSETS = [
  './icons/favicon-16x16.png', './icons/favicon-32x32.png',
  './icons/icon-72x72.png', './icons/icon-96x96.png',
  './icons/icon-128x128.png', './icons/icon-144x144.png',
  './icons/icon-152x152.png', './icons/icon-180x180.png',
  './icons/icon-192x192.png', './icons/icon-256x256.png',
  './icons/icon-384x384.png', './icons/icon-512x512.png',
  './icons/icon-maskable-192x192.png', './icons/icon-maskable-512x512.png',
  './screenshots/screenshot-narrow.png', './screenshots/screenshot-wide.png',
];

async function precacheAll(cacheName, urls) {
  const cache = await caches.open(cacheName);
  await Promise.allSettled(
    urls.map(url =>
      cache.add(url).catch(err => {
        if (!IS_LOCAL) console.warn('[Aurora SW] تعذّر تخزين:', url, err.message);
      })
    )
  );
}

// 1. التثبيت
self.addEventListener('install', event => {
  log('التثبيت –', IS_LOCAL ? 'بيئة محلية' : 'إنتاج');
  event.waitUntil(
    Promise.all([
      precacheAll(CACHE_SHELL, SHELL_ASSETS),
      precacheAll(CACHE_ICONS, ICON_ASSETS),
    ]).then(() => self.skipWaiting())
  );
});

// 2. التفعيل
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys
          .filter(k => k.startsWith('aurora-') && k !== CACHE_SHELL && k !== CACHE_ICONS)
          .map(k => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

// 3. Fetch
self.addEventListener('fetch', event => {
  const { request } = event;
  if (request.method !== 'GET') return;
  if (!request.url.startsWith('http') && !request.url.startsWith('file')) return;

  let url;
  try { url = new URL(request.url); } catch { return; }

  // تجاهل الطلبات الخارجية (Google Fonts, CDN...)
  if (url.origin !== self.location.origin) return;

  // HTML navigation
  if (request.mode === 'navigate' ||
      (request.headers.get('accept') || '').includes('text/html')) {
    event.respondWith(cacheFirstHtml(request));
    return;
  }

  // أيقونات وصور → Cache-First
  if (/\.(png|jpg|jpeg|svg|webp|ico)(\?.*)?$/.test(url.pathname)) {
    event.respondWith(cacheFirst(request, CACHE_ICONS));
    return;
  }

  // JS / CSS / JSON
  if (/\.(js|css|json)(\?.*)?$/.test(url.pathname)) {
    // في المحلي: Cache-First (لا network requests غير ضرورية)
    // في الإنتاج: Stale-While-Revalidate
    event.respondWith(
      IS_LOCAL
        ? cacheFirst(request, CACHE_SHELL)
        : staleWhileRevalidate(request, CACHE_SHELL)
    );
    return;
  }

  event.respondWith(cacheFirst(request, CACHE_SHELL));
});

// Cache-First
async function cacheFirst(request, cacheName) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const res = await fetch(request);
    if (res && res.ok) (await caches.open(cacheName)).put(request, res.clone());
    return res;
  } catch {
    return offlineFallback(false);
  }
}

// Cache-First للـ HTML مع fallback لـ index
async function cacheFirstHtml(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const res = await fetch(request);
    if (res && res.ok) (await caches.open(CACHE_SHELL)).put(request, res.clone());
    return res;
  } catch {
    const fallback = await caches.match('./index.html') || await caches.match('./');
    return fallback ?? offlineFallback(true);
  }
}

// Stale-While-Revalidate
async function staleWhileRevalidate(request, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);
  fetch(request)
    .then(res => { if (res && res.ok) cache.put(request, res.clone()); })
    .catch(() => {});
  if (cached) return cached;
  try { return await fetch(request); } catch { return offlineFallback(false); }
}

// Offline Fallback
function offlineFallback(isHtml) {
  if (!isHtml) return new Response('', { status: 503 });
  return new Response(
    `<!DOCTYPE html><html lang="ar" dir="rtl">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Aurora Player</title>
<style>*{margin:0;padding:0;box-sizing:border-box}
body{background:#0e0d17;color:#c8b8ff;font-family:sans-serif;display:flex;flex-direction:column;
align-items:center;justify-content:center;height:100vh;gap:1.2rem;text-align:center;padding:2rem}
h1{font-size:1.5rem;color:#a78bfa}p{color:#6b6b8a;font-size:.9rem;max-width:300px;line-height:1.6}
button{margin-top:.5rem;padding:.65rem 1.8rem;border:none;border-radius:2rem;
background:linear-gradient(135deg,#7846dc,#3c8ce6);color:#fff;font-size:1rem;cursor:pointer}
</style></head><body>
<div style="font-size:4rem">🎵</div>
<h1>Aurora Player</h1>
<p>تأكد من تشغيل الخادم المحلي أو الاتصال بالإنترنت.</p>
<button onclick="location.reload()">إعادة المحاولة</button>
</body></html>`,
    { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } }
  );
}

// رسائل من العميل
self.addEventListener('message', event => {
  if (!event.data) return;
  if (event.data.type === 'SKIP_WAITING') self.skipWaiting();
  if (event.data.type === 'CLEAR_CACHE') {
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k.startsWith('aurora-')).map(k => caches.delete(k))))
      .then(() => event.source?.postMessage({ type: 'CACHE_CLEARED' }));
  }
  if (event.data.type === 'GET_VERSION')
    event.source?.postMessage({ type: 'VERSION', version: APP_VERSION });
});

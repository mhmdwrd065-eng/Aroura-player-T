// تحسين: بناء خريطة الملفات لدعم الملفات الفردية والصور المتطابقة بالاسم
function buildFileMaps(filesToProcess) {
    const coverBasenames = ['folder', 'cover', 'album', 'albumart', 'front'];
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'];
    const lyricExtensions = ['.lrc', '.srt'];

    for (const file of filesToProcess) {
        const fileNameLower = file.name.toLowerCase();
        const fileExt = fileNameLower.substring(fileNameLower.lastIndexOf('.'));
        const baseName = file.name.substring(0, file.name.lastIndexOf('.')); // اسم الملف بدون الامتداد

        // معالجة الصور (الأغلفة)
        if (imageExtensions.includes(fileExt)) {
            // URI proxy: المسار هو URI أندرويد — نستخدم اسم الملف واسم المجلد الأب فقط
            let directoryPath = 'root_dir';
            if (file.isUriProxy) {
                // استخرج اسم المجلد الأب من URI: content://.../.../FolderName/song.mp3
                const parts = decodeURIComponent(file.uri || '').split('/');
                if (parts.length >= 2) {
                    directoryPath = parts[parts.length - 2] + '/';
                }
            } else {
                const relativePath = file.customPath || file.mozRelativePath || file.relativePath || file.name;
                if (relativePath.includes('/')) {
                    directoryPath = relativePath.substring(0, relativePath.lastIndexOf('/') + 1);
                }
            }

            const fileBasename = fileNameLower.substring(0, fileNameLower.lastIndexOf('.'));

            // ربط الصورة بمسار المجلد
            if (coverBasenames.includes(fileBasename)) {
                coverMap.set(directoryPath, file);
            } else if (!coverMap.has(directoryPath)) {
                coverMap.set(directoryPath, file);
            }

            // ربط الصورة باسم الملف (song.mp3 → song.jpg)
            coverMap.set(baseName, file);
        }

        // معالجة ملفات الكلمات
        if (lyricExtensions.includes(fileExt)) {
            lyricsMap.set(baseName, file);
        }
    }
}

// تحسين: استرجاع الغلاف بدعم المسارات الافتراضية والأسماء المتطابقة
function findFolderCover(mediaFile) {
    // 1. البحث باستخدام اسم الملف المباشر (أولوية قصوى: song.mp3 → song.jpg)
    const baseName = mediaFile.name.substring(0, mediaFile.name.lastIndexOf('.'));
    if (coverMap.has(baseName)) return coverMap.get(baseName);

    // 2. استخراج مسار المجلد حسب النوع
    let directoryPath = 'root_dir';
    if (mediaFile.isUriProxy) {
        // URI proxy: استخرج اسم المجلد الأب من URI
        const parts = decodeURIComponent(mediaFile.uri || '').split('/');
        if (parts.length >= 2) {
            directoryPath = parts[parts.length - 2] + '/';
        }
    } else {
        const relativePath = mediaFile.customPath || mediaFile.mozRelativePath || mediaFile.relativePath || mediaFile.name;
        if (typeof relativePath === 'string' && relativePath.includes('/')) {
            const pathParts = relativePath.split('/');
            directoryPath = pathParts.slice(0, -1).join('/') + '/';
        }
    }

    return coverMap.get(directoryPath) || null;
}

// تحسين: استرجاع الكلمات فوراً من الخريطة (O(1))
function searchForCompanionFile(mediaFile) {
    const baseName = mediaFile.name.substring(0, mediaFile.name.lastIndexOf('.'));
    return lyricsMap.get(baseName) || null;
}

// ===============================================
// دالة قراءة الميتاداتا المحسنة (تعمل بمكتبة music-metadata.js السريعة)
// ===============================================
async function getMetadata(file) {
    try {
        // رُفع الحد من 50MB إلى 500MB لدعم ملفات FLAC الكبيرة (الجودة العالية 24-bit/96kHz)
        // القراءة الفعلية مرفوعة إلى 32MB في music-metadata.js لضمان قراءة صور الغلاف الكاملة
        // القراءة الفعلية محدودة بـ 8MB في music-metadata.js لذا لا تأثير على الأداء
        if (file.size > 500 * 1024 * 1024) return null;
        
        const tags = await id3js.fromFile(file);
        let pictureUrl = null;

        // تحويل بيانات الصورة إلى رابط (Base64) بذكاء وسرعة
        if (tags.images && tags.images.length > 0) {
            const img = tags.images[0];
            const blob = new Blob([img.data], { type: img.mime });
            
            // استخدام FileReader الأصلي لضمان عدم تلف البيانات
            pictureUrl = await new Promise((resolve) => {
                const reader = new FileReader();
                reader.onloadend = () => resolve(reader.result);
                reader.readAsDataURL(blob);
            });
        }

        return {
            tags: {
                title: tags.title,
                artist: tags.artist,
                album: tags.album,
                year: tags.year,
                genre: tags.genre,
                pictureUrl: pictureUrl // نرسل الرابط جاهزاً
            }
        };
    } catch (error) {
        console.warn("Metadata read error:", error);
        return null;
    }
}

// ===============================================
// دوال التلاشي "الآمنة" (Anti-Pop Fading)
// ===============================================

// ═══════════════════════════════════════════════════════
//  18-fullscreen.js — نظام ملء الشاشة + لوحة تحكم كاملة
// ═══════════════════════════════════════════════════════

(function () {
    'use strict';

    // ─── العناصر الأساسية ───
    const container = document.getElementById('mediaContainer');
    const enterBtn  = document.getElementById('fullscreen-enter-btn');
    const exitBtn   = document.getElementById('fullscreen-exit-btn');
    const iconsBar  = document.getElementById('mediaContainerIcons');

    // ─── عناصر لوحة التحكم ───
    const fsPanel       = document.getElementById('fs-controls-panel');
    const fsTitleEl     = document.getElementById('fs-panel-title-text');
    const fsArtistEl    = document.getElementById('fs-panel-artist-text');
    const fsPlayBtn     = document.getElementById('fs-play-btn');
    const fsPlayIcon    = document.getElementById('fs-play-icon');
    const fsPauseIcon   = document.getElementById('fs-pause-icon');
    const fsPrevBtn     = document.getElementById('fs-prev-btn');
    const fsNextBtn     = document.getElementById('fs-next-btn');
    const fsBlossomBtn  = document.getElementById('fs-blossom-btn');
    const fsLyricsBtn   = document.getElementById('fs-lyrics-btn');
    const fsShuffleBtn  = document.getElementById('fs-shuffle-btn');
    const fsExitBtn     = document.getElementById('fs-exit-inline-btn');

    let hideTimer         = null;
    let progressRaf       = null;
    let isFullscreen      = false;
    let panelVisible      = false;
    let lastEnterTime     = 0; // لتجنب تعارض حدث النقر

    // متغيرات كشف النقر المزدوج على زر المؤثرات
    let fsBlossomClickCount = 0;
    let fsBlossomClickTimer = null;

    // ─────────────────────────────────────────────
    //  Wake Lock
    // ─────────────────────────────────────────────
    let wakeLock = null;

    async function requestWakeLock() {
        if (!('wakeLock' in navigator)) return;
        try {
            wakeLock = await navigator.wakeLock.request('screen');
            wakeLock.addEventListener('release', () => { wakeLock = null; });
        } catch (e) {}
    }

    function releaseWakeLock() {
        if (wakeLock) { wakeLock.release().catch(() => {}); wakeLock = null; }
    }

    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible' && isFullscreen && !wakeLock) requestWakeLock();
    });

    // ─────────────────────────────────────────────
    //  Fullscreen API helpers
    // ─────────────────────────────────────────────
    function getFullscreenElement() {
        return document.fullscreenElement || document.webkitFullscreenElement ||
               document.mozFullScreenElement || document.msFullscreenElement || null;
    }

    function getRequestMethod(el) {
        return el.requestFullscreen || el.webkitRequestFullscreen ||
               el.webkitEnterFullscreen || el.mozRequestFullScreen || el.msRequestFullscreen || null;
    }

    function getExitMethod() {
        return document.exitFullscreen || document.webkitExitFullscreen ||
               document.webkitCancelFullScreen || document.mozCancelFullScreen ||
               document.msExitFullscreen || null;
    }

    const isFullscreenAPISupported = !!(
        document.fullscreenEnabled || document.webkitFullscreenEnabled ||
        document.mozFullScreenEnabled || document.msFullscreenEnabled
    );

    // ─────────────────────────────────────────────
    //  Mute for transition (منع الطقطقة المحسّن)
    // ─────────────────────────────────────────────
    function muteForTransition(durationMs = 400) {
        const ctx  = window.audioContext;
        const gain = window.masterGain;
        if (!ctx || !gain) return;

        // إذا كان السياق معلقاً، استأنفه أولاً
        if (ctx.state === 'suspended') {
            ctx.resume().catch(() => {});
            return;
        }
        if (ctx.state !== 'running') return;

        const t   = ctx.currentTime;
        const vol = Math.max(gain.gain.value, 0.001);

        // كتم تدريجي exponential (40ms) ثم استعادة تدريجية (150ms) — أكثر نعومة
        gain.gain.cancelScheduledValues(t);
        gain.gain.setValueAtTime(vol, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);

        setTimeout(() => {
            const ctx2  = window.audioContext;
            const gain2 = window.masterGain;
            if (!ctx2 || !gain2) return;

            // استئناف السياق إذا علّقه المتصفح خلال الانتقال
            if (ctx2.state === 'suspended') ctx2.resume().catch(() => {});

            const t2 = ctx2.currentTime;
            const tv = Math.max(parseFloat(document.getElementById('volumeSlider')?.value ?? vol), 0.001);
            gain2.gain.cancelScheduledValues(t2);
            gain2.gain.setValueAtTime(0.001, t2);
            gain2.gain.exponentialRampToValueAtTime(tv, t2 + 0.15);
        }, durationMs);
    }

    // ─────────────────────────────────────────────
    //  Orientation lock
    // ─────────────────────────────────────────────
    function lockLandscape() {
        try {
            if (screen.orientation?.lock) screen.orientation.lock('landscape').catch(() => {});
        } catch (e) {}
    }

    function unlockOrientation() {
        try { if (screen.orientation?.unlock) screen.orientation.unlock(); } catch (e) {}
    }

    // ─────────────────────────────────────────────
    //  إظهار / إخفاء لوحة التحكم (inline styles مباشرة)
    // ─────────────────────────────────────────────
    function showPanel() {
        if (!fsPanel) return;
        panelVisible = true;
        fsPanel.style.display    = 'flex';
        fsPanel.style.opacity    = '1';
        fsPanel.style.visibility = 'visible';
        updateFsBlossomBtn();
        updateFsLyricsBtn();
        updateFsPlayBtn();
        updateFsShuffleBtn();
    }

    function hidePanel() {
        if (!fsPanel) return;
        panelVisible = false;
        fsPanel.style.opacity    = '0';
        fsPanel.style.visibility = 'hidden';
    }

    function resetPanelState() {
        // إخفاء اللوحة تماماً خارج وضع ملء الشاشة
        if (!fsPanel) return;
        fsPanel.style.display    = 'none';
        fsPanel.style.opacity    = '0';
        fsPanel.style.visibility = 'hidden';
        panelVisible = false;
    }

    function startHideTimer() {
        clearHideTimer();
        showPanel();
        hideTimer = setTimeout(hidePanel, 3500);
    }

    function clearHideTimer() {
        if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
    }

    // ─────────────────────────────────────────────
    //  تحديث معلومات المقطع داخل اللوحة
    // ─────────────────────────────────────────────
    function syncTrackInfo() {
        const title  = document.getElementById('trackTitle')?.textContent  || '';
        const artist = document.getElementById('trackArtist')?.textContent || '';
        if (fsTitleEl)  fsTitleEl.textContent  = title;
        if (fsArtistEl) fsArtistEl.textContent = artist;
    }

    window.updateFsTrackInfo = function () {
        if (isFullscreen) syncTrackInfo();
    };

    // ─────────────────────────────────────────────
    //  تحديث زر التشغيل/الإيقاف
    // ─────────────────────────────────────────────
    function updateFsPlayBtn() {
        if (!fsPlayIcon || !fsPauseIcon) return;
        const paused = audioPlayer ? audioPlayer.paused : true;
        fsPlayIcon.style.display  = paused  ? '' : 'none';
        fsPauseIcon.style.display = !paused ? '' : 'none';
    }

    // ─────────────────────────────────────────────
    //  تحديث زر المؤثرات البصرية
    // ─────────────────────────────────────────────
    function updateFsBlossomBtn() {
        if (!fsBlossomBtn) return;
        const on = typeof visualizerModeIndex !== 'undefined' && visualizerModeIndex !== -1;
        fsBlossomBtn.classList.toggle('blossom-active', on);
    }

    // ─────────────────────────────────────────────
    //  تحديث زر التشغيل العشوائي
    // ─────────────────────────────────────────────
    function updateFsShuffleBtn() {
        if (!fsShuffleBtn) return;
        const on = typeof isRandomPlayback !== 'undefined' && isRandomPlayback;
        fsShuffleBtn.classList.toggle('shuffle-active', on);
    }

    // ─────────────────────────────────────────────
    //  تحديث زر كلمات الأغنية
    // ─────────────────────────────────────────────
    function updateFsLyricsBtn() {
        if (!fsLyricsBtn) return;
        const on = typeof isLyricsVisible !== 'undefined' && isLyricsVisible;
        const hasLyrics = typeof lyricsData !== 'undefined' && lyricsData.length > 0;
        fsLyricsBtn.classList.toggle('lyrics-active', on);
        // إظهار حالة التعطيل بشكل واضح
        fsLyricsBtn.style.opacity = hasLyrics ? '1' : '0.3';
        fsLyricsBtn.style.cursor  = hasLyrics ? 'pointer' : 'default';
        fsLyricsBtn.title = hasLyrics
            ? (on ? 'إخفاء كلمات الأغنية' : 'إظهار كلمات الأغنية')
            : 'لا يوجد ملف كلمات لهذه الأغنية';
    }

    // ─────────────────────────────────────────────
    //  حلقة تحديث شريط التقدم
    // ─────────────────────────────────────────────
    function updateFsProgress() {
        if (!isFullscreen) return;
        const player = audioPlayer;
        if (!player) return;

        const cur = player.currentTime || 0;
        const dur = player.duration    || 0;

        if (!isSeeking && !fsIsSeeking) {
            const pct = dur > 0 ? (cur / dur) * 100 : 0;
            // نفس نهج الشريط العادي: translateX
            if (fsSeekBar)   fsSeekBar.style.transform = `translateX(${pct - 100}%)`;
            if (fsSeekThumb) fsSeekThumb.style.left    = `${pct}%`;
        }

        if (fsCurrentTime) fsCurrentTime.textContent = formatTime(cur);
        if (fsTotalTime)   fsTotalTime.textContent   = formatTime(dur);

        updateFsPlayBtn();
        progressRaf = requestAnimationFrame(updateFsProgress);
    }

    function startProgressLoop() {
        cancelAnimationFrame(progressRaf);
        progressRaf = requestAnimationFrame(updateFsProgress);
    }

    function stopProgressLoop() {
        cancelAnimationFrame(progressRaf);
        progressRaf = null;
    }

    // ─────────────────────────────────────────────
    //  تحديث أزرار الدخول / الخروج
    // ─────────────────────────────────────────────
    function updateUI(active) {
        if (enterBtn) enterBtn.style.display = active ? 'none' : '';
        if (exitBtn)  exitBtn.style.display  = 'none'; // الخروج عبر اللوحة فقط
    }

    // ─────────────────────────────────────────────
    //  تفعيل / إلغاء وضع ملء الشاشة (Fallback CSS)
    // ─────────────────────────────────────────────
    function activateFallback() {
        container.classList.add('fullscreen-active');
        document.body.classList.add('has-fullscreen');
        document.body.style.overflow = 'hidden';
        document.body.style.overscrollBehaviorX = 'none';
        isFullscreen  = true;
        lastEnterTime = Date.now();
        updateUI(true);
        syncTrackInfo();
        startHideTimer();
        startProgressLoop();
        requestWakeLock();
        setTimeout(lockLandscape, 250);

        // ← حل الطقطقة في وضع CSS Fallback
        setTimeout(() => {
            const ctx  = window.audioContext;
            const gain = window.masterGain;
            if (!ctx || !gain) return;
            if (ctx.state === 'suspended') ctx.resume().catch(() => {});
            const t  = ctx.currentTime;
            const tv = parseFloat(document.getElementById('volumeSlider')?.value ?? 1);
            gain.gain.cancelScheduledValues(t);
            gain.gain.setValueAtTime(gain.gain.value, t);
            gain.gain.linearRampToValueAtTime(tv, t + 0.12);
        }, 150);
    }

    function deactivateFallback() {
        container.classList.remove('fullscreen-active');
        document.body.classList.remove('has-fullscreen');
        document.body.style.overflow = '';
        document.body.style.overscrollBehaviorX = '';
        isFullscreen = false;
        updateUI(false);
        clearHideTimer();
        resetPanelState();
        stopProgressLoop();
        unlockOrientation();
        releaseWakeLock();
    }

    // ─────────────────────────────────────────────
    //  دخول / خروج ملء الشاشة
    // ─────────────────────────────────────────────
    function enterFullscreen() {
        if (!container) return;
        if (!isFullscreenAPISupported) {
            muteForTransition(300);
            activateFallback();
            return;
        }
        muteForTransition(350);
        const req = getRequestMethod(container);
        if (req) {
            const promise = req.call(container);
            if (promise && typeof promise.then === 'function') {
                promise
                    .then(() => { requestWakeLock(); setTimeout(lockLandscape, 250); })
                    .catch(() => { activateFallback(); });
            } else {
                requestWakeLock();
                setTimeout(lockLandscape, 250);
            }
        } else {
            activateFallback();
        }
    }

    function exitFullscreen() {
        unlockOrientation();
        releaseWakeLock();
        if (getFullscreenElement()) {
            const exit = getExitMethod();
            if (exit) {
                const p = exit.call(document);
                if (p?.catch) p.catch(() => deactivateFallback());
            }
        } else {
            deactivateFallback();
        }
    }

    // ─────────────────────────────────────────────
    //  مستمعو تغيّر حالة ملء الشاشة
    // ─────────────────────────────────────────────
    function onFullscreenChange() {
        const active = !!getFullscreenElement();
        isFullscreen = active;
        container.classList.toggle('fullscreen-active', active);
        document.body.classList.toggle('has-fullscreen', active);
        updateUI(active);

        if (active) {
            document.body.style.overscrollBehaviorX = 'none';
            lastEnterTime = Date.now();
            syncTrackInfo();
            startHideTimer();
            startProgressLoop();

            // [إصلاح] إعادة ضبط حجم الـ canvas بعد دخول الـ fullscreen
            // (الحاوية تتغير حجمها ولا يضمن حدث resize الوصول في الوقت المناسب)
            setTimeout(() => {
                if (typeof resizeAudioCanvas === 'function') resizeAudioCanvas();
            }, 50);

            // ← حل الطقطقة: استئناف السياق الصوتي واستعادة مستوى الصوت
            setTimeout(() => {
                const ctx  = window.audioContext;
                const gain = window.masterGain;
                if (!ctx || !gain) return;
                if (ctx.state === 'suspended') ctx.resume().catch(() => {});
                const t  = ctx.currentTime;
                const tv = parseFloat(document.getElementById('volumeSlider')?.value ?? 1);
                gain.gain.cancelScheduledValues(t);
                gain.gain.setValueAtTime(gain.gain.value, t);
                gain.gain.linearRampToValueAtTime(tv, t + 0.12);
            }, 120);
        } else {
            document.body.style.overscrollBehaviorX = '';
            clearHideTimer();
            resetPanelState();
            stopProgressLoop();
        }
    }

    ['fullscreenchange', 'webkitfullscreenchange',
     'mozfullscreenchange', 'MSFullscreenChange'].forEach(evt =>
        document.addEventListener(evt, onFullscreenChange)
    );

    // ─────────────────────────────────────────────
    //  ربط أزرار اللوحة
    // ─────────────────────────────────────────────

    // زر الخروج داخل اللوحة
    if (fsExitBtn) {
        fsExitBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            exitFullscreen();
        });
    }

    // زر التشغيل / الإيقاف
    if (fsPlayBtn) {
        fsPlayBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (typeof togglePlayPause === 'function') togglePlayPause();
            setTimeout(updateFsPlayBtn, 80);
            startHideTimer();
        });
    }

    // زر السابق
    if (fsPrevBtn) {
        fsPrevBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (typeof playPrevious === 'function') playPrevious();
            startHideTimer();
        });
    }

    // زر التالي
    if (fsNextBtn) {
        fsNextBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (typeof playNext === 'function') playNext();
            startHideTimer();
        });
    }

    // زر المؤثرات البصرية — نفس سلوك الزر الأصلي تماماً
    // نقرة واحدة: المؤثر التالي | نقرتان: تبديل تلقائي / إيقاف
    // 3 نقرات أو ضغط مطول (500ms): فتح قائمة المؤثرات
    if (fsBlossomBtn) {
        let fsBlossPressTimer = null;
        let isFsBlossLongPress = false;

        const startFsBlossomPress = () => {
            isFsBlossLongPress = false;
            fsBlossPressTimer = setTimeout(() => {
                isFsBlossLongPress = true;
                fsBlossomClickCount = 0;
                clearTimeout(fsBlossomClickTimer);
                if (typeof openVisualizerMenu === 'function') openVisualizerMenu();
                startHideTimer();
            }, 500);
        };

        const cancelFsBlossomPress = () => {
            if (fsBlossPressTimer) { clearTimeout(fsBlossPressTimer); fsBlossPressTimer = null; }
        };

        fsBlossomBtn.addEventListener('touchstart', startFsBlossomPress, { passive: true });
        fsBlossomBtn.addEventListener('mousedown', startFsBlossomPress);
        fsBlossomBtn.addEventListener('touchend', cancelFsBlossomPress);
        fsBlossomBtn.addEventListener('mouseup', cancelFsBlossomPress);
        fsBlossomBtn.addEventListener('mouseleave', cancelFsBlossomPress);
        fsBlossomBtn.addEventListener('touchmove', cancelFsBlossomPress, { passive: true });

        fsBlossomBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (isFsBlossLongPress) { e.preventDefault(); return; }

            fsBlossomClickCount++;
            clearTimeout(fsBlossomClickTimer);

            // 3 نقرات → فتح القائمة فوراً
            if (fsBlossomClickCount >= 3) {
                fsBlossomClickCount = 0;
                if (typeof openVisualizerMenu === 'function') openVisualizerMenu();
                startHideTimer();
                return;
            }

            fsBlossomClickTimer = setTimeout(() => {
                if (fsBlossomClickCount === 1) {
                    // نقرة واحدة → الانتقال للمؤثر التالي (مثل الزر العادي)
                    if (typeof handleBlossomSingleClick === 'function') handleBlossomSingleClick();
                } else {
                    // نقرتان → تبديل تلقائي أو إيقاف (مثل الزر العادي)
                    if (typeof handleBlossomDoubleClick === 'function') handleBlossomDoubleClick();
                }
                fsBlossomClickCount = 0;
                setTimeout(updateFsBlossomBtn, 120);
                startHideTimer();
            }, 260);
        });
    }

    // زر التشغيل العشوائي في ملء الشاشة
    if (fsShuffleBtn) {
        fsShuffleBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (typeof toggleRandomPlayback === 'function') toggleRandomPlayback();
            setTimeout(updateFsShuffleBtn, 80);
            startHideTimer();
        });
    }

    // زر كلمات الأغنية
    if (fsLyricsBtn) {
        fsLyricsBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            // إذا لم تتوفر كلمات، فقط أظهر تلميحاً بصرياً ولا تفعل شيئاً
            const hasLyrics = typeof lyricsData !== 'undefined' && lyricsData.length > 0;
            if (!hasLyrics) {
                // اهتزاز خفيف للزر للإشارة بأنه غير متاح
                fsLyricsBtn.style.animation = 'none';
                fsLyricsBtn.offsetHeight; // reflow
                fsLyricsBtn.style.animation = 'fsLyricsBtnShake 0.35s ease';
                startHideTimer();
                return;
            }
            if (typeof toggleLyricsDisplay === 'function') toggleLyricsDisplay();
            setTimeout(updateFsLyricsBtn, 80);
            startHideTimer();
        });
    }

    // تصدير دالة تحديث زر الكلمات لتستخدمها باقي ملفات الكود
    window.updateFsLyricsBtn = updateFsLyricsBtn;

    // ─────────────────────────────────────────────
    //  شريط تقدم ملء الشاشة — نفس نهج الوضع العادي
    //  seekVisual → تحديث بصري فقط أثناء السحب
    //  applyFsSeek → تطبيق القفز مرة واحدة عند الإفراج
    // ─────────────────────────────────────────────

    const fsSeekWrap  = document.getElementById('fs-seek-wrap');
    const fsSeekBar   = document.getElementById('fs-seek-bar');
    const fsSeekThumb = document.getElementById('fs-seek-thumb');
    const fsCurrentTime = document.getElementById('fs-current-time');
    const fsTotalTime   = document.getElementById('fs-total-time');

    let fsPendingSeek = -1;
    let fsIsSeeking   = false;

    function fsSeekVisual(clientX) {
        if (!audioPlayer || !isFinite(audioPlayer.duration)) return;
        const rect = fsSeekWrap.getBoundingClientRect();
        // direction: ltr دائماً — left = البداية، right = النهاية
        const pct  = Math.max(0, Math.min((clientX - rect.left) / rect.width, 1));
        fsPendingSeek = pct * audioPlayer.duration;
        // تحديث بصري مثل الشريط العادي (translateX)
        fsSeekBar.style.transform   = `translateX(${pct * 100 - 100}%)`;
        fsSeekThumb.style.left      = `${pct * 100}%`;
        if (fsCurrentTime) fsCurrentTime.textContent = formatTime(fsPendingSeek);
    }

    function fsApplySeek() {
        if (fsPendingSeek < 0 || !audioPlayer || !isFinite(audioPlayer.duration)) {
            fsPendingSeek = -1;
            return;
        }
        audioPlayer.currentTime = fsPendingSeek;
        // مزامنة الكلمات إذا كانت الدالة متاحة
        if (typeof updateLyricsDisplay === 'function') updateLyricsDisplay(fsPendingSeek, true);
        fsPendingSeek = -1;
    }

    function fsStartSeeking(e) {
        if (!isFullscreen) return;
        fsIsSeeking = true;
        isSeeking   = true; // إعلام حلقة التقدم بالإيقاف المؤقت
        fsSeekWrap.classList.add('is-dragging');
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        fsSeekVisual(clientX);
        e.preventDefault();
        e.stopPropagation();
    }

    function fsDuringSeeking(e) {
        if (!fsIsSeeking) return;
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        fsSeekVisual(clientX);
        e.preventDefault(); // منع swipe handler من التدخل
        e.stopPropagation();
    }

    function fsStopSeeking(e) {
        if (!fsIsSeeking) return;
        fsIsSeeking = false;
        isSeeking   = false;
        fsSeekWrap.classList.remove('is-dragging');
        fsApplySeek();
        startHideTimer();
    }

    if (fsSeekWrap) {
        fsSeekWrap.addEventListener('mousedown',  fsStartSeeking, { passive: false });
        fsSeekWrap.addEventListener('touchstart', fsStartSeeking, { passive: false });
    }

    // الأحداث على document لضمان التتبع حتى خارج العنصر
    document.addEventListener('mousemove', fsDuringSeeking);
    document.addEventListener('touchmove', fsDuringSeeking, { passive: false });
    document.addEventListener('mouseup',   fsStopSeeking);
    document.addEventListener('touchend',  fsStopSeeking);

    // مزامنة حالة التشغيل
    if (audioPlayer) {
        audioPlayer.addEventListener('play',  updateFsPlayBtn);
        audioPlayer.addEventListener('pause', updateFsPlayBtn);
    }

    // ─────────────────────────────────────────────
    //  التفاعل مع الشاشة: إظهار / إخفاء اللوحة
    //
    //  المشكلة السابقة:
    //    كان pointerdown يُبدّل اللوحة فوراً عند بداية أي لمس،
    //    فكان السحب لتغيير الأغنية يُشغّل إظهار/إخفاء اللوحة
    //    قبل أن يُحدَّد اتجاه الإيماء.
    //
    //  الحل — اكتشاف النقرة الحقيقية:
    //    ① pointerdown → نحفظ الموضع والوقت فقط
    //    ② pointerup   → نتحقق من المسافة والمدة:
    //         إذا تحرّك < TAP_MOVE_THRESHOLD px وخلال < TAP_DURATION_MS
    //         → نقرة حقيقية → نُبدّل اللوحة
    //         وإلا (سحب أو ضغط مطوّل) → نتجاهل تماماً
    //    هكذا لا يؤثر السحب الأفقي أبداً على حالة اللوحة.
    // ─────────────────────────────────────────────

    const TAP_MOVE_THRESHOLD = 12; // بكسل — حد اعتبار الحركة "سحباً"
    const TAP_DURATION_MS    = 300; // مللي ثانية — حد اعتبار اللمس "نقرة"

    let tapStartX    = 0;
    let tapStartY    = 0;
    let tapStartTime = 0;
    let tapOnPanel   = false;

    document.addEventListener('pointerdown', (e) => {
        if (!isFullscreen) return;
        if (Date.now() - lastEnterTime < 600) return;

        tapStartX    = e.clientX;
        tapStartY    = e.clientY;
        tapStartTime = Date.now();
        tapOnPanel   = !!(fsPanel && fsPanel.contains(e.target));
    });

    document.addEventListener('pointerup', (e) => {
        if (!isFullscreen) return;
        if (Date.now() - lastEnterTime < 600) return;

        // إذا كان النقر على اللوحة → أعد ضبط مؤقت الإخفاء فقط
        if (tapOnPanel) {
            clearHideTimer();
            hideTimer = setTimeout(hidePanel, 3500);
            tapOnPanel = false;
            return;
        }

        const movedX = Math.abs(e.clientX - tapStartX);
        const movedY = Math.abs(e.clientY - tapStartY);
        const dt     = Date.now() - tapStartTime;

        // نقرة حقيقية فقط (حركة ضئيلة + مدة قصيرة)
        const isTap = movedX < TAP_MOVE_THRESHOLD &&
                      movedY < TAP_MOVE_THRESHOLD &&
                      dt     < TAP_DURATION_MS;

        if (isTap) {
            if (panelVisible) {
                clearHideTimer();
                hidePanel();
            } else {
                startHideTimer();
            }
        }
        // السحب (movedX ≥ TAP_MOVE_THRESHOLD) → لا نفعل شيئاً هنا
        // نظام السحب في 20-cover-swipe-and-init.js يتكفل بالتنقل بين الأغاني
    });

    // حركة الماوس تُظهر اللوحة دائماً (desktop)
    document.addEventListener('pointermove', (e) => {
        if (!isFullscreen) return;
        if (e.pointerType === 'mouse') startHideTimer();
    });

    // ─────────────────────────────────────────────
    //  ربط أزرار الدخول / الخروج الأصليين
    // ─────────────────────────────────────────────
    if (enterBtn) {
        enterBtn.removeAttribute('href');
        enterBtn.setAttribute('role', 'button');
        enterBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation(); // منع الانتشار للـ container
            enterFullscreen();
        });
    }

    if (exitBtn) {
        exitBtn.removeAttribute('href');
        exitBtn.setAttribute('role', 'button');
        exitBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            exitFullscreen();
        });
    }

    // ESC للـ Fallback
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && isFullscreen && !getFullscreenElement()) {
            deactivateFallback();
        }
    });

    // ─────────────────────────────────────────────
    //  تصدير
    // ─────────────────────────────────────────────
    window.toggleFullscreenMode = function () {
        isFullscreen ? exitFullscreen() : enterFullscreen();
    };
    window.isInFullscreen     = function () { return isFullscreen; };
    window.isFsPanelVisible   = function () { return panelVisible; };
    window.updateFsBlossomBtn = updateFsBlossomBtn;
    window.updateFsShuffleBtn = updateFsShuffleBtn;

    // تهيئة
    updateUI(false);
    resetPanelState();

})();

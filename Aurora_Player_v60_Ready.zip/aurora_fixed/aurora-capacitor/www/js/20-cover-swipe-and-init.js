// ===============================================
// ميزة الإيماء على غلاف الأغنية (Swipe on Cover)
// -----------------------------------------------
// كيف تعمل؟
// ① touchstart → تسجيل نقطة البداية
// ② touchmove  → تطبيق تخميد على الغلاف + إظهار مؤشرات الاتجاه
// ③ touchend   → إذا تجاوز السحب العتبة: تشغيل التالي/السابق مع تأثيرات خفيفة
//
// كل التأثيرات البصرية تعتمد على GPU (transform + opacity فقط)
// وهذا يضمن سلاسة 60fps حتى على الأجهزة المتوسطة.
// ===============================================

/**
 * يُظهر تأثيرات بصرية خفيفة عند تأكيد الإيماء.
 * يُنشئ عنصرَين مؤقتَين فقط ثم يُزيلهما تلقائياً.
 * @param {'fwd'|'back'} dir - اتجاه الانتقال (fwd=التالي, back=السابق)
 */
function playCoverSwipeEffect(dir) {
    const container = document.getElementById('mediaContainer');
    if (!container) return;

    // شريط الضوء الخاطف
    const beam = document.createElement('div');
    beam.className = `swipe-light-beam swipe-beam-${dir}`;
    container.appendChild(beam);

    // تموج دائري في المركز
    const ripple = document.createElement('div');
    ripple.className = 'swipe-center-ripple';
    container.appendChild(ripple);

    // تنظيف بعد انتهاء الحركة (+ ضمان احتياطي بـ setTimeout)
    const cleanAll = () => { beam.remove(); ripple.remove(); };
    beam.addEventListener('animationend', cleanAll, { once: true });
    setTimeout(cleanAll, 550);
}

/**
 * القلب الرئيسي للميزة.
 * يُضاف مرة واحدة فقط عند تحميل الصفحة.
 */
function setupCoverSwipeGesture() {
    const container = document.getElementById('mediaContainer');
    if (!container) return;

    // ── الثوابت ──────────────────────────────
    const SWIPE_THRESHOLD  = 62;    // بكسل - الحد الأدنى لتأكيد الإيماء
    const DAMPING          = 0.40;  // نسبة تخميد الحركة المرئية
    const LOCK_TIMEOUT_MS  = 4000;  // الحد الأقصى لمدة القفل (ضمان ضد التعليق)

    // ── الحالة الداخلية ───────────────────────
    let startX = 0, startY = 0;
    let currentDX = 0;           // مقدار السحب الحالي بالبكسل
    let isHorizSwipe = false;    // هل تم تأكيد أن الحركة أفقية؟
    let swipeLocked = false;     // هل يجري انتقال حالياً؟ (لمنع التداخل)
    let lockSafetyTimer = null;  // مؤقت احتياطي لتحرير القفل تلقائياً
    let mouseHeld = false;       // لدعم الماوس على الكمبيوتر
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // إصلاح تعارض السحب مع تمرير الكلمات (المتزامنة وغير المتزامنة):
    // gestureActive = true فقط إذا أكمل touchstart دون توقف مبكر.
    // touchmove يفحصها أولاً → إذا كانت false يتجاهل الحدث كلياً.
    // هذا يمنع استخدام startX/startY القديمة من لمسة سابقة عند لمس الكلمات.
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    let gestureActive = false;

    /**
     * يُحرِّر قفل الإيماء ويُعيد الحالة الداخلية لوضع الراحة.
     * يُستدعى دائماً عبر finally في doNavigation، وكذلك من touchcancel
     * ومن مؤقت الأمان الذي يمنع بقاء القفل مفتوحاً إلى الأبد.
     */
    function releaseLock() {
        clearTimeout(lockSafetyTimer);
        lockSafetyTimer = null;
        swipeLocked  = false;
        isHorizSwipe = false;
        currentDX    = 0;
        mouseHeld    = false;
        gestureActive = false;
        hideIndicators();
        // إعادة العنصر لوضعه الطبيعي إذا كانت لا تزال هناك إزاحة مرئية
        snapBack();
    }

    // إعادة تعيين كاملة عند عودة التطبيق من الخلفية
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible' && swipeLocked) {
            // نعطي doNavigation فرصة قصيرة لإنهاء عملها قبل الإجبار
            setTimeout(() => { if (swipeLocked) releaseLock(); }, 600);
        }
    });

    // ── إنشاء مؤشرات الاتجاه ────────────────
    // (يُنشأ مرة واحدة وتظل في DOM، يتحكم بها opacity فقط)
    const prevInd = document.createElement('div');
    prevInd.className = 'swipe-dir-indicator swipe-dir-prev';
    prevInd.innerHTML = '⏮';

    const nextInd = document.createElement('div');
    nextInd.className = 'swipe-dir-indicator swipe-dir-next';
    nextInd.innerHTML = '⏭';

    container.appendChild(prevInd);
    container.appendChild(nextInd);

    // ── دوال مساعدة ──────────────────────────

    /** يُعيد العنصر المرئي الحالي: الغلاف أو الأيقونة الافتراضية */
    function getTarget() {
        const cover = document.getElementById('coverArt');
        if (cover && cover.style.display === 'block') return cover;
        const icon  = document.getElementById('defaultIcon');
        if (icon  && icon.style.display  === 'flex')  return icon;
        return null;
    }

    /** يُطبّق التحويل المخمَّد على العنصر المرئي أثناء السحب */
    function applyDrag(dx) {
        const t = getTarget();
        if (!t) return;
        // الحد القصوى للإزاحة: 85px (لمنع الخروج الكامل من الإطار)
        const moved  = Math.sign(dx) * Math.min(Math.abs(dx) * DAMPING, 85);
        const shrink = Math.max(1 - Math.abs(moved) * 0.0006, 0.94); // تصغير طفيف
        t.style.transition = 'none'; // إيقاف CSS transitions أثناء السحب للاستجابة الفورية
        t.style.transform  = `translateX(${moved}px) scale(${shrink})`;
    }

    /**
     * يُعيد العنصر لوضعه الطبيعي بحركة نعمة عند إلغاء الإيماء.
     * ينتبه لحالة المؤثرات البصرية (visualizer) ويُعيد scale الصحيحة.
     */
    function snapBack() {
        const t = getTarget();
        if (!t) return;
        // إذا كانت المؤثرات البصرية نشطة، الغلاف يكون مُكبَّراً قليلاً
        const baseTransform = (t.id === 'coverArt' && visualizerModeIndex !== -1)
            ? 'scale(1.1)'
            : '';
        t.style.transition = 'transform 0.30s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
        t.style.transform  = baseTransform;
        setTimeout(() => { if (t) t.style.transition = ''; }, 320);
    }

    /** يُحدِّث وضوح مؤشرات الاتجاه بناءً على مقدار السحب */
    function updateIndicators(dx) {
        const progress = Math.min(Math.abs(dx) / SWIPE_THRESHOLD, 1);
        if (dx > 8) {
            prevInd.style.opacity = progress;
            nextInd.style.opacity = '0';
        } else if (dx < -8) {
            nextInd.style.opacity = progress;
            prevInd.style.opacity = '0';
        } else {
            prevInd.style.opacity = '0';
            nextInd.style.opacity = '0';
        }
    }

    /** يخفي المؤشرات فوراً */
    function hideIndicators() {
        prevInd.style.opacity = '0';
        nextInd.style.opacity = '0';
    }

    /**
     * يُنفِّذ الانتقال الكامل: حركة خروج ← تأثيرات ← تشغيل الأغنية.
     * @param {boolean} goNext - true = التالي، false = السابق
     */
    async function doNavigation(goNext) {
        if (swipeLocked) return;

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // الإصلاح الجذري #1: التحقق من isTransitioning قبل أي شيء
        // إذا كان التطبيق في منتصف تحميل أغنية، لا نبدأ أنيميشن الخروج
        // أبداً، لأن playFile ستُعيد تعيين الغلاف من تلقاء نفسها.
        // السبب: لو بدأنا أنيميشن الخروج ثم وجد skipFile أن
        // isTransitioning=true فسيعود مبكراً بدون تشغيل أغنية جديدة،
        // مما يترك الغلاف مختفياً والواجهة في حالة خاطئة.
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        if (typeof isTransitioning !== 'undefined' && isTransitioning) {
            snapBack();
            hideIndicators();
            return;
        }

        swipeLocked = true;
        let navigationAttempted = false; // هل وصلنا لمرحلة تشغيل الأغنية؟

        // مؤقت أمان: إذا لم يُكتمل التنقل خلال LOCK_TIMEOUT_MS
        // (مثلاً بسبب تجميد المتصفح أو خطأ صامت)، يُحرَّر القفل تلقائياً
        lockSafetyTimer = setTimeout(() => {
            if (swipeLocked) {
                console.warn('[Swipe] safety timeout: releasing stuck lock');
                releaseLock();
            }
        }, LOCK_TIMEOUT_MS);

        const t = getTarget();

        try {
            // ① حركة الخروج السريعة للغلاف الحالي
            if (t) {
                const exitX = goNext ? -95 : 95;
                t.style.transition = 'transform 0.20s ease-in, opacity 0.20s ease-in';
                t.style.transform  = `translateX(${exitX}px) scale(0.88)`;
                t.style.opacity    = '0.12';
            }

            // انتظر انتهاء حركة الخروج
            await new Promise(r => setTimeout(r, 215));

            // ② تنظيف inline styles (playFile سيُعيد ضبطها)
            if (t) {
                t.style.transition = 'none';
                t.style.transform  = '';
                t.style.opacity    = '';
            }

            // ③ التأثيرات البصرية الخفيفة
            playCoverSwipeEffect(goNext ? 'fwd' : 'back');

            // ④ تشغيل الأغنية (skipFile يعالج العشوائية، قائمة الانتظار، التكرار)
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // الإصلاح #2: نُسجِّل أننا وصلنا لهذه المرحلة
            // حتى يعرف finally أن playFile ستتكفل باستعادة الغلاف
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            navigationAttempted = true;
            if (goNext) {
                if (typeof playNext === 'function') await playNext();
            } else {
                if (typeof playPrevious === 'function') await playPrevious();
            }
        } catch (err) {
            console.warn('[Swipe] خطأ أثناء التنقل:', err);
            if (t) {
                t.style.transition = '';
                t.style.transform  = '';
                t.style.opacity    = '';
            }
        } finally {
            // تحرير القفل ومسح المؤقت الاحتياطي دائماً
            clearTimeout(lockSafetyTimer);
            lockSafetyTimer = null;
            swipeLocked = false;

            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // الإصلاح #3: إذا لم نصل لمرحلة playFile (مثلاً بسبب خطأ
            // في منتصف الطريق)، نُعيد الغلاف لوضعه الطبيعي يدوياً
            // حتى لا يبقى الغلاف مختفياً أو مُزاحاً بدون سبب
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (!navigationAttempted) {
                snapBack();
                hideIndicators();
            }
        }
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // أحداث اللمس (الأجهزة المحمولة)
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    // ── دالة مساعدة: هل قائمة المؤثرات البصرية مفتوحة حالياً؟ ──────────
    // ══════════════════════════════════════════════════════════════════════
    // المشكلة: الـ overlay يستخدم position:fixed ويغطي الشاشة بالكامل،
    // لكنه يبقى في DOM داخل #mediaContainerIcons. عند فتح القائمة:
    //   ① touchstart يُوقَف بواسطة فحص mediaContainerIcons ← صحيح
    //   ② لكن startX/startY تبقى بقيم قديمة من لمسة سابقة
    //   ③ touchmove يقرأ هذه القيم القديمة → dx ضخم خاطئ → isHorizSwipe=true
    //   ④ النتيجة: الغلاف يتحرك أو الأغنية تتغير أثناء تمرير القائمة!
    //
    // الحل: فحص صريح بـ display مباشرةً في كلا المعالجَين
    // ══════════════════════════════════════════════════════════════════════
    function isVisualizerOverlayOpen() {
        const vo = document.getElementById('visualizerOverlay');
        return !!(vo && vo.style.display === 'flex');
    }

    container.addEventListener('touchstart', (e) => {
        // تجاهل اللمس على العناصر التفاعلية الداخلية
        const lyricsEl = document.getElementById('lyricsDisplay');
        // الفحص الصحيح: نعتمد على isLyricsVisible وليس على فحص الأبناء
        // لأن lyricsDisplay قد يحتفظ بأبنائه حتى بعد إخفائه من أغنية سابقة
        // ملاحظة: نتحقق أن isLyricsVisible معرّف (وليس undefined) قبل استخدامه
        // لمنع حظر الإيماءات بشكل خاطئ إذا لم تكن المتغير محمّلاً بعد
        const lyricsVisible = typeof isLyricsVisible !== 'undefined' ? isLyricsVisible : false;
        const lyricsActuallyVisible = lyricsEl && lyricsVisible &&
                                      lyricsEl.style.display !== 'none';
        if (e.target.closest('#lyricsDisplay') ||
            e.target.closest('#mediaContainerIcons') ||
            e.target.closest('#fs-controls-panel') ||
            (typeof isFsPanelVisible === 'function' && isFsPanelVisible()) ||
            isVisualizerOverlayOpen() ||
            lyricsActuallyVisible ||
            swipeLocked || files.length <= 1) {
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            // مهم: إلغاء gestureActive عند أي توقف مبكر
            // يضمن ألا تستخدم touchmove قيم startX/startY قديمة
            // وهو ما كان يسبب تحريك الغلاف عند تمرير نافذة الكلمات
            // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            gestureActive = false;
            return;
        }

        startX        = e.touches[0].clientX;
        startY        = e.touches[0].clientY;
        currentDX     = 0;
        isHorizSwipe  = false;
        gestureActive = true;   // إيماءة بدأت بشكل شرعي من منطقة الغلاف
    }, { passive: true });

    container.addEventListener('touchmove', (e) => {
        if (swipeLocked || files.length <= 1) return;

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // الإصلاح الجذري لتعارض تمرير الكلمات مع السحب:
        // إذا لم تبدأ إيماءة شرعية في touchstart، نتجاهل touchmove كلياً.
        // هذا يحمي نافذة الكلمات (المتزامنة وغير المتزامنة) من الإهتزاز.
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        if (!gestureActive) return;

        // ══════════════════════════════════════════════════════════════════
        // منع تعارض السحب مع شريط التقدم في وضع ملء الشاشة
        // ──────────────────────────────────────────────────────────────────
        // المشكلة: عند ظهور لوحة التحكم (شريط التقدم مرئي)، قد تبقى قيم
        // startX القديمة من لمسة سابقة، فتُحسب dx بشكل خاطئ وتُفعّل
        // isHorizSwipe بالخطأ أثناء سحب شريط التقدم، مما يُزيح الغلاف
        // بصرياً في نفس الوقت.
        //
        // الحل: إذا كانت لوحة التحكم ظاهرة (المستخدم يتفاعل معها)،
        // نوقف معالج السحب كلياً — لوحة التحكم تتكفل بسحبها sendiri.
        // ══════════════════════════════════════════════════════════════════
        if (typeof isFsPanelVisible === 'function' && isFsPanelVisible()) return;

        // ── منع التعارض مع تمرير قائمة المؤثرات البصرية ──────────────────
        // isVisualizerOverlayOpen() معرَّفة أعلاه في نفس النطاق.
        // هذا الفحص يُوقف معالج السحب حتى لو كانت startX بقيم قديمة.
        if (isVisualizerOverlayOpen()) return;

        const dx = e.touches[0].clientX - startX;
        const dy = e.touches[0].clientY - startY;

        if (!isHorizSwipe) {
            // نتجاهل الحركة الصغيرة جداً (أقل من 5px) لتجنب الاهتزاز
            if (Math.abs(dx) < 5) return;

            if (Math.abs(dx) >= Math.abs(dy) && e.cancelable) {
                e.preventDefault();
            }

            isHorizSwipe = Math.abs(dx) > Math.abs(dy) * 1.3;
            if (!isHorizSwipe) return;

            // ═══════════════════════════════════════════════════════════════
            // إصلاح عدم التماثل بين السحب يميناً ويساراً في ملء الشاشة
            // ───────────────────────────────────────────────────────────────
            // السبب: Chrome Android يُأخّر إيصال touchmove بمقدار 30-50px
            // عند السحب من الحافة اليسرى (بينما يقرر إذا كان إيماء رجوع)،
            // فيصل أول حدث لـ JS وdx مُضخَّم مسبقاً. السحب يساراً لا يعاني
            // من هذا التأخير لأنه لا يقترب من حافة الـ Back Gesture.
            //
            // الحل: إعادة تثبيت startX من الموضع الحالي عند لحظة تأكيد
            // الحركة الأفقية. هكذا يبدأ قياس العتبة (SWIPE_THRESHOLD)
            // من نفس النقطة في كلا الاتجاهين ويصبح السحب متساوياً.
            // ═══════════════════════════════════════════════════════════════
            startX    = e.touches[0].clientX;
            startY    = e.touches[0].clientY;
            currentDX = 0;
        }

        if (e.cancelable) e.preventDefault();
        currentDX = dx;
        applyDrag(dx);
        updateIndicators(dx);
    }, { passive: false });

    container.addEventListener('touchend', async () => {
        hideIndicators();

        if (!isHorizSwipe || swipeLocked || !gestureActive) {
            isHorizSwipe  = false;
            currentDX     = 0;
            gestureActive = false;
            return;
        }

        const dx      = currentDX;
        isHorizSwipe  = false;
        currentDX     = 0;
        gestureActive = false;

        if (Math.abs(dx) >= SWIPE_THRESHOLD && files.length > 1) {
            await doNavigation(dx < 0);
        } else {
            snapBack();
        }
    }, { passive: true });

    // ── touchcancel: الحدث الذي كان غائباً ويسبب تعليق swipeLocked ──
    // المتصفح يُطلقه عند مقاطعة اللمس (إشعار، تبديل تطبيقات، التصغير...)
    container.addEventListener('touchcancel', () => {
        isHorizSwipe  = false;
        currentDX     = 0;
        gestureActive = false;
        hideIndicators();
        snapBack();
        // لا نُجبر تحرير swipeLocked هنا لأن doNavigation قد تكون جارية فعلاً؛
        // المؤقت الاحتياطي (lockSafetyTimer) سيتكفل بتحريره تلقائياً
    }, { passive: true });

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // أحداث الماوس (للاختبار على الكمبيوتر)
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    container.addEventListener('mousedown', (e) => {
        if (e.button !== 0 || swipeLocked || files.length <= 1) return;
        if (e.target.closest('#mediaContainerIcons')) return;

        mouseHeld    = true;
        startX       = e.clientX;
        currentDX    = 0;
        isHorizSwipe = true; // الماوس دائماً أفقي
    });

    container.addEventListener('mousemove', (e) => {
        if (!mouseHeld || swipeLocked) return;
        currentDX = e.clientX - startX;
        applyDrag(currentDX);
        updateIndicators(currentDX);
    });

    // دالة مشتركة لنهاية الماوس (mouseup أو مغادرة الحاوية)
    const handleMouseRelease = async () => {
        if (!mouseHeld) return;
        mouseHeld = false;
        hideIndicators();

        if (Math.abs(currentDX) >= SWIPE_THRESHOLD && files.length > 1 && !swipeLocked) {
            await doNavigation(currentDX < 0);
        } else {
            snapBack();
        }
        currentDX    = 0;
        isHorizSwipe = false;
    };

    container.addEventListener('mouseup',    handleMouseRelease);
    container.addEventListener('mouseleave', handleMouseRelease);
}




// ═══════════════════════════════════════════════════════════
// البرنامج التعليمي — نسخة v3: شرح تفصيلي كامل للمؤثرات البصرية
// ═══════════════════════════════════════════════════════════
(function initTutorial() {

    // ─────────────────────────────────────────────────────────
    // دالة مساعدة: تُنتج HTML بطاقة مؤثر واحدة.
    // name     : الاسم العربي
    // desc     : وصف قصير جداً (3-4 كلمات)
    // mpClass  : فئات CSS للمعاينة المتحركة (mp-bars، mp-circle…)
    // inner    : عدد الـ <s> داخل المعاينة (0 = يُستخدم pseudo-elements)
    // light    : true → تظهر شارة 📱 (مناسب للهواتف الضعيفة)
    // ─────────────────────────────────────────────────────────
    function effCard(name, desc, mpClass, inner, light) {
        const badge = light ? ' lw' : '';
        const spans = inner > 0 ? '<s></s>'.repeat(inner) : '';
        return `
        <div class="tut-eff-card${badge}">
            <div class="mp ${mpClass}">${spans}</div>
            <span class="tut-eff-name">${name}</span>
            <span class="tut-eff-desc">${desc}</span>
        </div>`;
    }

    // ─────────────────────────────────────────────────────────
    // بيانات الشرائح العشر
    // ─────────────────────────────────────────────────────────
    const STEPS = [

        // ══ 1: ترحيب ══════════════════════════════════════════
        {
            icon: '🎵',
            title: 'مرحباً في Aurora Player!',
            text: 'مشغّل موسيقى سريع وخفيف يعمل بشكل كامل من متصفحك.\nهذا الدليل سيعرّفك على جميع الميزات خطوة بخطوة.'
        },

        // ══ 2: إضافة الموسيقى ═════════════════════════════════
        {
            icon: '📂',
            title: 'كيف تُضيف موسيقاك؟',
            text: 'اضغط زر ▶ في المنتصف لاختيار ملفات أو مجلد كامل،\nأو اسحب الملفات مباشرة وأفلتها على الشاشة.\nيدعم المشغّل الصوت وصور الألبوم وملفات الكلمات.'
        },

        // ══ 3: أزرار التحكم ═══════════════════════════════════
        {
            icon: '🎮',
            title: 'أزرار التحكم الرئيسية',
            text: '⏮ السابق   ▶❚❚ تشغيل/إيقاف   ⏭ التالي\n\nمرّر شريط التقدم لتقديم الأغنية أو ترجيعها،\nواضغط أيقونة الصوت للتحكم في مستوى الصوت.'
        },

        // ══ 4: إيماءات السحب ══════════════════════════════════
        {
            icon: '👆',
            title: 'إيماءات السحب',
            text: 'اسحب غلاف الأغنية يساراً ← للأغنية التالية،\nأو يميناً → للأغنية السابقة.\n\nاضغط مطوّلاً على أغنية في القائمة لخيارات إضافية.'
        },

        // ══ 5: تفعيل المؤثرات البصرية (شرح خطوة بخطوة مع رسم توضيحي) ══
        {
            icon: '🌸',
            title: 'المؤثرات البصرية — كيف تُفعّلها؟',
            html: `
            <div class="tut-ui-diagram">
                <div class="tut-ui-canvas">🎵 غلاف الأغنية والمؤثر هنا</div>
                <div class="tut-ui-ctrl-row">
                    <span class="tut-ui-btn">⏮</span>
                    <span class="tut-ui-btn tut-ui-btn-main">▶</span>
                    <span class="tut-ui-btn">⏭</span>
                </div>
                <div class="tut-ui-tools-row">
                    <span class="tut-ui-tool">🔀</span>
                    <span class="tut-ui-tool tut-ui-tool-active">🌸</span>
                    <span class="tut-ui-tool">📜</span>
                    <span class="tut-ui-tool">🔁</span>
                    <span class="tut-ui-tool">📋</span>
                </div>
                <div class="tut-ui-arrow">
                    <span class="tut-ui-arrow-line"></span>
                    <span class="tut-ui-arrow-label">↑ اضغط هذا الزر!</span>
                </div>
            </div>
            <div class="tut-vis-steps">
                <div class="tut-step-row">
                    <span class="tut-step-num">١</span>
                    <span class="tut-step-txt">شغّل أغنية أولاً — المؤثرات تستجيب للصوت مباشرةً</span>
                </div>
                <div class="tut-step-row">
                    <span class="tut-step-num">٢</span>
                    <span class="tut-step-txt">اضغط <span class="tut-badge">🌸</span> من شريط الأدوات السفلي لفتح قائمة المؤثرات</span>
                </div>
                <div class="tut-step-row">
                    <span class="tut-step-num">٣</span>
                    <span class="tut-step-txt">اختر أي مؤثر — يبدأ فوراً فوق غلاف الأغنية</span>
                </div>
                <div class="tut-step-row">
                    <span class="tut-step-num">٤</span>
                    <span class="tut-step-txt">اضغط <span class="tut-badge">🌸</span> مجدداً للتنقل السريع بين المؤثرات دون فتح القائمة</span>
                </div>
            </div>
            <p class="tut-tip">✨ المؤثرات تستجيب تلقائياً للبيت والأصوات الحادة والهادئة</p>`
        },

        // ══ 6: موجات وأعمدة كلاسيكية (9 مؤثرات) ══════════════
        {
            icon: '🌊',
            title: 'موجات وأعمدة كلاسيكية',
            html: `
            <div class="tut-cat-header">
                <div class="tut-cat-subtitle">الأخف وزناً — تعمل بسلاسة على جميع الهواتف</div>
            </div>
            <div class="tut-eff-grid">
                ${effCard('أعمدة التردد',   'ترتفع مع كل نغمة',       'mp-bars',                       5, true)}
                ${effCard('موجة الصوت',     'رسم دقيق للصوت',          'mp-wave',                       7, true)}
                ${effCard('انعكاس مرآوي',   'أعمدة للأعلى والأسفل',   'mp-bars mp-bars-mirror',        5, true)}
                ${effCard('أعمدة معكوسة',   'تنمو نحو الأسفل',         'mp-bars mp-bars-dn',            5, true)}
                ${effCard('شريط مموج',      'شريط ثلاثي يتموج',        'mp-wave mp-wave-ribbon',        7, false)}
                ${effCard('معادل 3D',       'أعمدة بعمق ثلاثي',        'mp-bars mp-bars-3d',            5, false)}
                ${effCard('أشعة شمسية',     'تمتد من المركز',           'mp-circle mp-radial',           0, false)}
                ${effCard('شمس صوتية',      'تنبض مع الإيقاع',          'mp-circle mp-sun',              0, false)}
                ${effCard('مصفوفة نقاط',    'نقاط تضيء بالتتابع',      'mp-bars mp-dots',               5, true)}
            </div>
            <p class="tut-tip">📱 البطاقات بعلامة <strong>📱</strong> هي الأنسب للهواتف الضعيفة</p>`
        },

        // ══ 7: فضاء وكون (9 مؤثرات) ══════════════════════════
        {
            icon: '🚀',
            title: 'فضاء وكون',
            html: `
            <div class="tut-cat-header">
                <div class="tut-cat-subtitle">انغمس في الفضاء — رائعة مع الموسيقى الإلكترونية</div>
            </div>
            <div class="tut-eff-grid">
                ${effCard('حقل النجوم',     'نجوم تطير نحوك',          'mp-stars',                      5, true)}
                ${effCard('مجرة',           'درب التبانة يتحرك',       'mp-stars mp-galaxy',            5, false)}
                ${effCard('دوامة',          'تمتصك للمركز',             'mp-tunnel',                     0, false)}
                ${effCard('نفق فضائي',      'سفر بسرعة الضوء',         'mp-tunnel mp-tunnel-fast',      0, false)}
                ${effCard('لولب مزدوج',     'حلزون DNA يدور',           'mp-tunnel mp-helix',            0, false)}
                ${effCard('نفق بلازما',     'ألوان متوهجة ساخنة',      'mp-tunnel mp-plasma',           0, false)}
                ${effCard('كرة متوهجة',     'تتوهج بالإيقاع',           'mp-circle mp-sphere',           0, false)}
                ${effCard('نجم نابض',       'نجم يتوهج بالنبض',        'mp-circle mp-pulsar',           0, false)}
                ${effCard('مسارات النجوم',  'مسارات نجمية ساطعة',      'mp-stars mp-trails',            5, false)}
            </div>
            <p class="tut-tip">🎸 تبدو أجمل مع الموسيقى الآمبيانت والإلكترونية</p>`
        },

        // ══ 8: احتفالية وحيّة (12 مؤثراً) ═════════════════════
        {
            icon: '🎉',
            title: 'احتفالية وحيّة',
            html: `
            <div class="tut-cat-header">
                <div class="tut-cat-subtitle">للحفلات والأغاني ذات البيتس القوية — 12 مؤثراً</div>
            </div>
            <div class="tut-eff-grid">
                ${effCard('ألعاب نارية',    'صواريخ وانفجارات ضخمة',   'mp-burst',                      4, false)}
                ${effCard('انفجار قصاصات', 'قصاصات ملونة تتساقط',     'mp-burst mp-confetti',          4, false)}
                ${effCard('تموجات الماء',   'موجات دائرية تنتشر',      'mp-circle mp-ripple',           0, true)}
                ${effCard('فقاعات ليزر',    'فقاعات تطفو وتنفجر',      'mp-burst mp-bubbles',           4, false)}
                ${effCard('جزيئات متناثرة','تتطاير عند الضربات',       'mp-stars mp-scatter',           5, false)}
                ${effCard('قطرات المطر',    'تسقط وتتفجر بالأسفل',     'mp-stars mp-rain',              5, true)}
                ${effCard('حلقة الطاقة',    'حلقة مضيئة متوهجة',       'mp-circle mp-energy',           0, false)}
                ${effCard('حلقة قوس قزح',   'ألوان تدور باستمرار',     'mp-circle mp-rainbow',          0, false)}
                ${effCard('حلقات ديناميكية','حلقات متداخلة تتحرك',     'mp-circle mp-dynrings',         0, false)}
                ${effCard('شفق قطبي',       'ستائر ضوئية خيالية',      'mp-tunnel mp-plasma',           0, false)}
                ${effCard('مطر الصوت',      'قطرات ملونة تتناثر',      'mp-stars mp-rain',              5, true)}
                ${effCard('موجة الصدمة',    'انفجار دائري من المركز',  'mp-circle mp-ripple',           0, false)}
            </div>
            <p class="tut-tip">🎶 تزداد حيويةً كلما كانت الأغنية أكثر إيقاعاً</p>`
        },

        // ══ 9: تقنية وهندسية (10 مؤثرات — شبكة 5 أعمدة) ═════
        {
            icon: '⚡',
            title: 'تقنية وهندسية',
            html: `
            <div class="tut-cat-header">
                <div class="tut-cat-subtitle">للموسيقى الإلكترونية والروك والهيب هوب</div>
            </div>
            <div class="tut-eff-grid tut-eff-grid-5">
                ${effCard('تشويش رقمي',    'تشويش مع البيتس',         'mp-glitch',                     3, true)}
                ${effCard('شبكة نيون',     'شبكة خضراء تضيء',         'mp-glitch mp-neon',             3, false)}
                ${effCard('شلال رقمي',     'بيانات تتساقط',            'mp-glitch mp-waterfall',        3, false)}
                ${effCard('شبكة عنكبوتية', 'خيوط تتحرك',               'mp-web',                        0, false)}
                ${effCard('مربعات متزامنة','تنبض معاً',                 'mp-glitch mp-squares',          3, true)}
                ${effCard('خطوط دوارة',    'تدور بالإيقاع',            'mp-web mp-lines',               0, true)}
                ${effCard('أشكال هندسية',  'تتحول مع الصوت',           'mp-web mp-geo',                 0, false)}
                ${effCard('معدن سائل',     'يتموج كالمعدن',            'mp-wave mp-wave-liquid',        7, false)}
                ${effCard('توهج الحواف',   'حواف الشاشة تتوهج',        'mp-circle mp-edge-glow',        0, true)}
                ${effCard('نبض دائري',     'الأبسط والأجمل',           'mp-circle',                     0, true)}
            </div>
            <p class="tut-tip">📱 المؤثرات بعلامة <strong>📱</strong> تعمل بسلاسة على أي جهاز</p>`
        },

        // ══ 10: التحكم الكامل في المؤثرات ═════════════════════
        {
            icon: '🔄',
            title: 'التحكم الكامل في المؤثرات',
            html: `
            <div class="tut-vis-steps">
                <div class="tut-step-row tut-highlight">
                    <span class="tut-step-num">★</span>
                    <span class="tut-step-txt"><strong>تبديل تلقائي:</strong> أول خيار في القائمة — يُغيّر المؤثر تلقائياً كل 10 ثوانٍ، مثالي للاستماع الطويل</span>
                </div>
                <div class="tut-step-row">
                    <span class="tut-step-num">🔀</span>
                    <span class="tut-step-txt">اضغط <span class="tut-badge">🌸</span> مباشرةً (بدون القائمة) للقفز للمؤثر التالي فوراً</span>
                </div>
                <div class="tut-step-row">
                    <span class="tut-step-num">⏹</span>
                    <span class="tut-step-txt">لإيقاف المؤثر: افتح القائمة واضغط زر <span class="tut-badge tut-badge-red">⏹ إيقاف</span> في أعلى القائمة</span>
                </div>
                <div class="tut-step-row">
                    <span class="tut-step-num">🖼️</span>
                    <span class="tut-step-txt">المؤثر يعمل فوق غلاف الأغنية مباشرةً — يمكنك مشاهدة الاثنين معاً</span>
                </div>
            </div>
            <div class="tut-perf-box">
                <span class="tut-perf-icon">📱</span>
                <span class="tut-perf-txt">للهواتف الضعيفة: فضّل <strong>أعمدة التردد</strong> أو <strong>موجة الصوت</strong> أو <strong>تشويش رقمي</strong> — تعطي أداءً سلساً على أي جهاز</span>
            </div>
            <div class="tut-perf-box" style="margin-top:10px; border-color: #e0943a; background: rgba(224,148,58,0.10);">
                <span class="tut-perf-icon">⚡</span>
                <span class="tut-perf-txt"><strong>ملاحظة:</strong> أداء المؤثرات يختلف من هاتف لآخر حسب قوة المعالج — الهواتف القوية تُشغِّل جميع المؤثرات بسلاسة، والهواتف الضعيفة تستفيد من المؤثرات المُوسَمة بـ 📱</span>
            </div>`
        },

        // ══ 11: مميزات أخرى ════════════════════════════════════
        {
            icon: '🎛️',
            title: 'مميزات إضافية رائعة',
            text: '📜 كلمات الأغاني المتزامنة مع الوقت\n🎛️ معادل صوتي (EQ) مع قوالب جاهزة\n😴 مؤقت النوم الذكي\n📋 قائمة تشغيل مع بحث وفرز\n\nاستمتع بتجربتك الموسيقية! 🎶'
        }
    ];

    // v5 → يُضاف 3 مؤثرات جديدة (شفق قطبي + مطر الصوت + موجة الصدمة) والمجموع 40
    const STORAGE_KEY = 'aurora_tutorial_done_v5';

    try { if (localStorage.getItem(STORAGE_KEY)) return; } catch(e) {}

    // ─── مراجع DOM ───────────────────────────────────────────
    const overlay  = document.getElementById('tutorialOverlay');
    const dotsWrap = document.getElementById('tutDots');
    const iconEl   = document.getElementById('tutIcon');
    const titleEl  = document.getElementById('tutTitle');
    const textEl   = document.getElementById('tutText');
    const prevBtn  = document.getElementById('tutPrevBtn');
    const nextBtn  = document.getElementById('tutNextBtn');
    const skipBtn  = document.getElementById('tutSkipBtn');
    if (!overlay) return;

    let step = 0;

    // بناء نقاط التقدم بعدد الشرائح
    STEPS.forEach(() => {
        const d = document.createElement('div');
        d.className = 'tut-dot';
        dotsWrap.appendChild(d);
    });

    // ─── عرض شريحة بمؤشر معيّن ──────────────────────────────
    function render(i) {
        const s = STEPS[i];
        iconEl.textContent  = s.icon;
        titleEl.textContent = s.title;

        if (s.html) {
            // شريحة غنية: HTML مباشر
            textEl.innerHTML = s.html;
        } else {
            // شريحة نصية: نحوّل أسطر النص إلى HTML
            textEl.innerHTML = s.text
                .split('\n')
                .map(l => `<span>${l}</span>`)
                .join('<br>');
        }

        // تحديث نقاط التقدم
        dotsWrap.querySelectorAll('.tut-dot').forEach((d, j) => {
            d.classList.toggle('on', j === i);
        });

        // أزرار التنقل
        prevBtn.style.visibility = i === 0 ? 'hidden' : 'visible';
        nextBtn.textContent = i === STEPS.length - 1 ? 'ابدأ الآن 🎶' : 'التالي';

        // إعادة التمرير للأعلى عند الانتقال
        overlay.querySelector('.tut-card').scrollTop = 0;
    }

    // ─── إظهار التعليمي بعد ثانيتين ─────────────────────────
    setTimeout(() => { render(0); overlay.classList.add('active'); }, 1800);

    // ─── التنقل ───────────────────────────────────────────────
    function goNext() {
        if (step < STEPS.length - 1) { step++; render(step); }
        else closeTutorial();
    }
    function goPrev() {
        if (step > 0) { step--; render(step); }
    }
    function closeTutorial() {
        overlay.classList.remove('active');
        try { localStorage.setItem(STORAGE_KEY, '1'); } catch(e) {}
    }

    nextBtn.addEventListener('click', goNext);
    prevBtn.addEventListener('click', goPrev);
    skipBtn.addEventListener('click', closeTutorial);

    // دعم لوحة المفاتيح (التنقل فقط — الإغلاق عبر زر تخطي أو إكمال الدليل)
    overlay.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight') goNext();  // RTL: اليمين = التالي
        if (e.key === 'ArrowLeft')  goPrev();  // RTL: اليسار = السابق
    });

})();

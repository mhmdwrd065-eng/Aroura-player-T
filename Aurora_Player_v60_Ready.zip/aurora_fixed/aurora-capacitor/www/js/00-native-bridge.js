// ═══════════════════════════════════════════════════════════════
//  00-native-bridge.js  —  v3.0
//  جسر Aurora الأصلي لأندرويد
//  ✅ إشعارات المشغل مع أزرار تحكم حقيقية
//  ✅ وصول دائم للمجلدات بدون نسخ الملفات
// ═══════════════════════════════════════════════════════════════

const AuroraBridge = (() => {

    let _native = false;
    let _MediaPlugin = null;
    let _FilesPlugin = null;
    const URI_STORE_KEY = 'aurora_uri_files_v1';

    // ── تهيئة ──────────────────────────────────────────────────
    async function init() {
        if (!window.Capacitor?.isNativePlatform()) return;
        try {
            const cap = window.Capacitor.Plugins;
            _MediaPlugin = cap.AuroraMedia || null;
            _FilesPlugin = cap.AuroraFiles || null;
            _native = true;

            if (_MediaPlugin) {
                await _MediaPlugin.addListener('mediaControl', ({ action }) => {
                    switch (action) {
                        case 'play':
                        case 'pause': typeof togglePlayPause==='function' && togglePlayPause(); break;
                        case 'next':  typeof playNext        ==='function' && playNext();       break;
                        case 'prev':  typeof playPrevious    ==='function' && playPrevious();   break;
                    }
                });
            }
            console.log('[AuroraBridge] Plugins الأصلية جاهزة ✅');
            // استعادة المجلد المحفوظ تلقائياً
            await _restoreSavedFolder();
        } catch(e) {
            console.warn('[AuroraBridge] خطأ تهيئة:', e);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  إشعارات المشغل
    // ══════════════════════════════════════════════════════════

    async function updateNotification(info) {
        if (!_native || !_MediaPlugin) return;
        try {
            await _MediaPlugin.updateNotification({
                title:     info.title     || 'Aurora Player',
                artist:    info.artist    || '',
                album:     info.album     || '',
                isPlaying: info.isPlaying !== false,
                artwork:   info.artwork   || null
            });
        } catch(e) {}
    }

    async function destroyNotification() {
        if (!_native || !_MediaPlugin) return;
        try { await _MediaPlugin.destroy(); } catch(e) {}
    }

    function _hookMediaSession() {
        const origApply = window.msApply;
        window.msApply = function() {
            origApply?.apply(this, arguments);
            const player = typeof getActivePlayer==='function' ? getActivePlayer() : null;
            updateNotification({
                title:     window._msTitle          || '',
                artist:    window._msArtist         || '',
                album:     window._msAlbum          || '',
                isPlaying: player ? !player.paused  : false,
                artwork:   window._msArtworkDataUrl || null
            });
        };
        const origClear = window.msClear;
        window.msClear = function() {
            origClear?.apply(this, arguments);
            destroyNotification();
        };
    }

    // ══════════════════════════════════════════════════════════
    //  وصول دائم للملفات — URI proxy بدون نسخ
    // ══════════════════════════════════════════════════════════

    async function pickMusicFolder() {
        if (!_native || !_FilesPlugin) {
            document.getElementById('folderInput')?._origClick?.();
            return;
        }
        try {
            showToast('اختر مجلد الموسيقى...', 'info', 2000);
            const result = await _FilesPlugin.pickFolder();
            if (!result?.uri) return;
            showToast('جاري قراءة الملفات...', 'info', 3000);
            await _loadFromFolderUri(result.uri, true);
        } catch(e) {
            if (e?.message !== 'USER_CANCELLED') showToast('لم يتم اختيار مجلد', 'info');
        }
    }

    async function _restoreSavedFolder() {
        if (!_native || !_FilesPlugin) return;
        try {
            const saved = await _FilesPlugin.getSavedFolder();
            if (!saved?.uri) return;
            if (typeof files !== 'undefined' && files.length > 0) return;
            console.log('[AuroraBridge] استعادة المجلد المحفوظ...');
            await _loadFromFolderUri(saved.uri, false);
        } catch(e) {
            console.warn('[AuroraBridge] خطأ استعادة:', e);
        }
    }

    async function _loadFromFolderUri(folderUri, showMsg) {
        try {
            const { files: fileList } = await _FilesPlugin.listAudioFiles({ uri: folderUri });
            if (!fileList?.length) {
                if (showMsg) showToast('لا توجد ملفات مدعومة في هذا المجلد', 'warning');
                return;
            }

            // ── تصنيف الملفات: صوتيات + مرافقة (صور أغلفة + كلمات) ────────
            const audioRaw     = fileList.filter(f => _isAudio(f.name, f.mime));
            const companionRaw = fileList.filter(f => !_isAudio(f.name, f.mime));

            if (!audioRaw.length) {
                if (showMsg) showToast('لا توجد ملفات صوتية مدعومة', 'warning');
                return;
            }

            // ── URI proxies للصوتيات ──────────────────────────────────────
            const uriAudioFiles = audioRaw.map(f => {
                const playUrl = window.Capacitor.convertFileSrc(f.uri);
                return {
                    name:         f.name,
                    size:         f.size || 0,
                    type:         f.mime || _mimeFromName(f.name),
                    uri:          f.uri,
                    playUrl:      playUrl,
                    isUriProxy:   true,
                    customPath:   f.uri,
                    timeAdded:    Date.now(),
                    lastModified: Date.now(),
                    arrayBuffer: async () => {
                        const r = await fetch(playUrl);
                        if (!r.ok) throw new Error('فشل تحميل الملف');
                        return r.arrayBuffer();
                    }
                };
            });

            // ── URI proxies للملفات المرافقة (صور + كلمات) ───────────────
            // تُمرَّر لـ buildFileMaps فقط ولا تُضاف لقائمة التشغيل
            const uriCompanionFiles = companionRaw.map(f => {
                const playUrl = window.Capacitor.convertFileSrc(f.uri);
                const mime    = f.mime || _mimeFromName(f.name);
                return {
                    name:         f.name,
                    size:         f.size || 0,
                    type:         mime,
                    uri:          f.uri,
                    playUrl:      playUrl,
                    isUriProxy:   true,
                    customPath:   f.uri,
                    // لقراءة نص الكلمات (lrc/srt) عبر fetch بدلاً من FileReader
                    text: async () => {
                        const r = await fetch(playUrl);
                        if (!r.ok) throw new Error('فشل قراءة الملف');
                        return r.text();
                    },
                    arrayBuffer: async () => {
                        const r = await fetch(playUrl);
                        if (!r.ok) throw new Error('فشل تحميل الملف');
                        return r.arrayBuffer();
                    }
                };
            });

            await _injectFiles(uriAudioFiles, uriCompanionFiles, showMsg);

        } catch(e) {
            console.warn('[AuroraBridge] خطأ تحميل:', e);
            if (showMsg) showToast('خطأ في قراءة الملفات: ' + e.message, 'error');
        }
    }

    async function _injectFiles(uriAudioFiles, uriCompanionFiles, showMsg) {
        const existing = new Set((window.files||[]).map(f => f.name+'_'+f.size));
        const newFiles = uriAudioFiles.filter(f => !existing.has(f.name+'_'+f.size));

        if (!newFiles.length && showMsg) {
            showToast('جميع الملفات محملة بالفعل', 'info');
            return;
        }

        if (!window.files?.length) {
            window.files = uriAudioFiles;
        } else {
            window.files = [...window.files, ...newFiles];
        }

        // buildFileMaps تحتاج الكل: صوتيات + صور + كلمات
        if (typeof buildFileMaps === 'function') {
            buildFileMaps([...uriAudioFiles, ...uriCompanionFiles]);
        }
        if (typeof renderPlaylist === 'function') renderPlaylist();

        if (showMsg) {
            // اختيار جديد: شغّل أول ملف
            if (typeof playFile === 'function') playFile(window.files[0]);
        } else {
            // استعادة: أعد الحالة المحفوظة
            try {
                const playlistData = await dbManager.load('auroraPlaylist');
                if (playlistData?.lastPlayed?.path) {
                    const idx = window.files.findIndex(f => f.customPath === playlistData.lastPlayed.path);
                    if (idx !== -1) {
                        window.currentIndex  = idx;
                        window.restoredSeekTime = playlistData.lastPlayed.time || 0;
                    }
                }
                if (playlistData?.isRandom  !== undefined) window.isRandomPlayback = playlistData.isRandom;
                if (playlistData?.loopMode  !== undefined) window.isLoopMode       = playlistData.loopMode;
                if (playlistData?.sortMode  !== undefined) window.currentSortMode  = playlistData.sortMode;
            } catch(_) {}
            if (typeof updateTrackInfo       === 'function' && window.files[window.currentIndex])
                updateTrackInfo(window.files[window.currentIndex]);
            if (typeof renderPlaylist        === 'function') renderPlaylist();
            if (typeof updatePlaylistHighlight === 'function') updatePlaylistHighlight();
            if (typeof updateButtonStates    === 'function') updateButtonStates();
        }

        if (showMsg) showToast(`✅ تم تحميل ${uriAudioFiles.length} أغنية — الوصول مباشر`, 'success', 4000);
    }

    // ── دوال مساعدة ─────────────────────────────────────────
    function _mimeFromName(name) {
        const ext = (name||'').split('.').pop().toLowerCase();
        const map = {
            mp3:'audio/mpeg', flac:'audio/flac', ogg:'audio/ogg',
            m4a:'audio/mp4',  aac:'audio/aac',  wav:'audio/wav',
            wma:'audio/x-ms-wma', opus:'audio/opus',
            jpg:'image/jpeg', jpeg:'image/jpeg', png:'image/png',
            webp:'image/webp', bmp:'image/bmp',
            lrc:'text/lrc',   srt:'text/srt'
        };
        return map[ext] || 'audio/mpeg';
    }
    function _isAudio(name, mime) {
        if (mime?.startsWith('audio/')) return true;
        return /\.(mp3|flac|ogg|m4a|aac|wav|wma|opus|weba)$/i.test(name||'');
    }
    return { init, pickMusicFolder, updateNotification, destroyNotification,
             isNative: () => _native, _hookMediaSession };
})();

// ══════════════════════════════════════════════════════════════
//  تهيئة عند تحميل الصفحة
// ══════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
    await AuroraBridge.init();
    AuroraBridge._hookMediaSession();

    if (!AuroraBridge.isNative()) return;

    // اعتراض folderInput.click() واستبداله بالوصول الدائم
    const folderInput = document.getElementById('folderInput');
    if (folderInput) {
        folderInput._origClick = () => HTMLElement.prototype.click.call(folderInput);
        Object.defineProperty(folderInput, 'click', {
            value: function() { AuroraBridge.pickMusicFolder(); },
            writable: true, configurable: true
        });
    }
});

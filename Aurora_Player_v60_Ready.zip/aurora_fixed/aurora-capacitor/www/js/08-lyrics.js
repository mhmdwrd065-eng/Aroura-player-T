// ===============================================

function parseLrc(content) {
    if (!content) return [];
    const lines = content.split(/\r?\n/);
    const lyrics = [];
    
    // Regex قوي يلتقط التوقيتات بدقة (يدعم الدقائق الطويلة وأجزاء الثانية المختلفة)
    // النمط: [mm:ss.xx] أو [mm:ss:xx]
    const timeRegexGlobal = /\[(\d+):(\d+)[.:](\d+)\]/g;
    const timeRegexSingle = /\[(\d+):(\d+)[.:](\d+)\]/;

    let hasTimestamps = false;

    lines.forEach(line => {
        line = line.trim();
        // تجاهل الميتاداتا (مثل [ar:Artist]) والأسطر الفارغة
        if (!line || (line.startsWith('[') && !timeRegexSingle.test(line) && line.includes(':'))) {
            return; 
        }

        // استخراج جميع التوقيتات الموجودة في السطر
        const matches = [...line.matchAll(timeRegexGlobal)];
        
        if (matches.length > 0) {
            hasTimestamps = true;
            // استخراج النص الصافي بإزالة كل التوقيتات من السطر
            const text = line.replace(timeRegexGlobal, '').trim();

            // إضافة إدخال لكل توقيت تم العثور عليه (لنفس النص)
            matches.forEach(match => {
                const minutes = parseInt(match[1]);
                const seconds = parseInt(match[2]);
                // معالجة الميلي ثانية بدقة (تكملة الرقم إلى 3 خانات)
                const milliseconds = parseInt(match[3].padEnd(3, '0'));
                
                const time = minutes * 60 + seconds + milliseconds / 1000;
                
                // داخل دالة parseLrc ...
if (text) { 
    // التعديل هنا: تعقيم النص قبل إضافته للمصفوفة
    const safeText = escapeHTML(text); 
    lyrics.push({ time, text: safeText });
}

            });
        } else if (!hasTimestamps && line) {
            // تجميع الأسطر للنصوص الثابتة مؤقتاً
            lyrics.push({ time: -1, text: line });
        }
    });

    // إذا لم نجد أي توقيت في الملف بالكامل، نعتبره نصاً ثابتاً
    if (!hasTimestamps) {
        return lyrics.map(l => ({ ...l, time: -1 }));
    }

    // ترتيب الكلمات زمنياً (مهم جداً في حالة التوقيتات المتكررة)
    return lyrics.filter(l => l.time !== -1).sort((a, b) => a.time - b.time);
}

function parseSrt(content) {
    if (!content) return [];
    
    // تقسيم الملف إلى كتل بناءً على الأسطر الفارغة المزدوجة
    const blocks = content.trim().split(/\r?\n\r?\n/);
    const subtitles = [];

    // دالة مساعدة لتحويل صيغة SRT الزمنية إلى ثواني
    // الصيغة: 00:00:20,500
    function timeToSeconds(timeStr) {
        if (!timeStr) return 0;
        const parts = timeStr.split(/[:,]/).map(parseFloat);
        // التأكد من وجود 4 أجزاء (ساعة، دقيقة، ثانية، ميلي)
        if (parts.length < 4) return 0;
        return (parts[0] * 3600) + (parts[1] * 60) + parts[2] + (parts[3] / 1000);
    }

    blocks.forEach(block => {
        const lines = block.split(/\r?\n/);
        
        // البحث عن السطر الذي يحتوي على السهم المميز للتوقيت
        const timeLineIndex = lines.findIndex(line => line.includes('-->'));
        
        if (timeLineIndex !== -1) {
            const timeStr = lines[timeLineIndex];
            const [startTimeStr] = timeStr.split('-->').map(s => s.trim());
            
            // النص هو كل ما يأتي بعد سطر التوقيت
            let textLines = lines.slice(timeLineIndex + 1);
            
            // تنظيف النص: إزالة أكواد HTML وتجميع الأسطر
            let text = textLines
                .join(' ') // يمكنك استخدام '\n' إذا أردت الحفاظ على الأسطر المتعددة
                .replace(/<[^>]*>?/gm, '') // حذف التاجات مثل <i> <b>
                .trim();

            // داخل دالة parseSrt ...
if (text) {
    // التعديل هنا: تعقيم النص
    const safeText = escapeHTML(text);
    subtitles.push({
        time: timeToSeconds(startTimeStr),
        text: safeText
    });
}

        }
    });

    return subtitles.sort((a, b) => a.time - b.time);
}

function toggleLyricsDisplay() {
    if (lyricsData.length === 0) {
        showToast('لا يوجد ملف كلمات متزامن.', 'error');
        return;
    }
    isLyricsVisible = !isLyricsVisible;
    lyricsDisplay.style.display = isLyricsVisible ? 'block' : 'none';
    lyricsToggleBtn.classList.toggle('active', isLyricsVisible);
    if (isLyricsVisible) {
        const player = getActivePlayer();
        updateLyricsDisplay(player.currentTime, true); // تحديث فوري
    }
    // مزامنة زر الكلمات في وضع ملء الشاشة
    if (typeof window.updateFsLyricsBtn === 'function') window.updateFsLyricsBtn();
}

// تحسين: البحث الثنائي للكلمات عند التقديم/التأخير (Seek)
function findLyricIndex(time) {
    let low = 0, high = lyricsData.length - 1;
    while (low <= high) {
        const mid = Math.floor((low + high) / 2);
        if (lyricsData[mid].time <= time) {
            if (mid + 1 >= lyricsData.length || lyricsData[mid + 1].time > time) {
                return mid;
            }
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }
    return -1;
}

// تحسين: دالة عرض الكلمات باستخدام المؤشر لتقليل استهلاك المعالج
function updateLyricsDisplay(currentTime, forceSeek = false) {
    if (!isLyricsVisible || lyricsData.length === 0) return;

    // === الحالة الجديدة: كلمات بدون توقيت ===
    if (lyricsData[0].time === -1) {
        // التحقق مما إذا كنا قد عرضنا النص بالفعل لتجنب إعادة الرسم المتكرر
        if (lyricsDisplay.getAttribute('data-mode') !== 'static') {
            
            // في updateLyricsDisplay (الوضع الثابت)
const allTextHTML = lyricsData
    .map(item => `<p>${item.text}</p>`) // item.text الآن آمن لأنه تم تعقيمه مسبقاً
    .join('');
            
            // وضع النص داخل حاوية بالتنسيق الجديد
            lyricsDisplay.innerHTML = `<div class="static-lyrics-content">${allTextHTML}</div>`;
            
            // وضع علامة أننا في الوضع الثابت
            lyricsDisplay.setAttribute('data-mode', 'static');
        }
        return; // نخرج من الدالة ولا نقوم بحساب التوقيت
    }

    // === الحالة العادية: كلمات متزامنة (الكود القديم) ===
    
    // إعادة ضبط الوضع إذا انتقلنا من أغنية ثابتة إلى متزامنة
    if (lyricsDisplay.getAttribute('data-mode') === 'static') {
        lyricsDisplay.removeAttribute('data-mode');
        lyricsDisplay.innerHTML = '';
    }

    // (باقي الكود الأصلي للدالة كما هو)
    if (forceSeek) {
        currentLyricIndex = findLyricIndex(currentTime);
    } else {
        while (currentLyricIndex + 1 < lyricsData.length && currentTime >= lyricsData[currentLyricIndex + 1].time) {
            currentLyricIndex++;
        }
    }

    if (currentLyricIndex >= 0 && currentLyricIndex < lyricsData.length) {
        const currentLyric = lyricsData[currentLyricIndex];
        const nextLyric = lyricsData[currentLyricIndex + 1];
        lyricsDisplay.innerHTML = `<span class="highlighted-lyric">${currentLyric.text}</span>` + (nextLyric ? `<br>${nextLyric.text}` : '');
    } else {
        // لتجنب عرض "..." إذا كنا في البداية
        lyricsDisplay.innerHTML = lyricsData[0] ? `<span class="highlighted-lyric">${lyricsData[0].text}</span>` : '...';
    }
}

function toggleLoopMode() {
    isLoopMode = (isLoopMode + 1) % 3;
    
    const modes = [
        { icon: svgs.loopAll, title: 'تكرار القائمة', message: 'تكرار القائمة' },
        { icon: svgs.loopOne, title: 'تكرار الأغنية', message: 'تكرار المقطع الحالي' },
        { icon: svgs.loopOff, title: 'إلغاء التكرار', message: 'تم إيقاف التكرار' }
    ];

    const mode = modes[isLoopMode];
    
    loopBtn.innerHTML = mode.icon;
    loopBtn.title = mode.title;
    loopBtn.classList.toggle('active', isLoopMode !== 2);
    // إزالة التركيز بعد الضغط لمنع بقاء حالة التمييز
    loopBtn.blur();
    
    getActivePlayer().loop = isLoopMode === 1;
    
    if (files.length > 0) {
        showToast(mode.message, 'info');
    }
    
    savePlaylistState();
}

// ===============================================
// **ملاحظة: تم دمج الدالة المكررة toggleRandomPlayback**
// ===============================================


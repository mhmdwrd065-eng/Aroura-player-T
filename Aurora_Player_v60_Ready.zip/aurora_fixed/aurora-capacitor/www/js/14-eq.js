// ===============================================

// [تحسين] دالة مؤجّلة لحفظ إعدادات المعادل (Debounced)
// تمنع الكتابة المتكررة في localStorage أثناء سحب الشريط المستمر
let _eqSaveTimer = null;
function saveEqSettingsDebounced() {
    clearTimeout(_eqSaveTimer);
    _eqSaveTimer = setTimeout(saveEqSettings, 300);
}

// **جديد: دالة لحفظ إعدادات المعادل**
function saveEqSettings() {
    if (!isEqSetup) return; // لا تحفظ إذا لم يتم إعداد المعادل بعد
    try {
        const preampSlider = document.getElementById('preampSlider');
        const eqSliders = document.querySelectorAll('.eq-slider[data-index]');
        
        const settings = {
            preamp: preampSlider ? parseFloat(preampSlider.value) : 1.0,
            bands: Array.from(eqSliders)
                        .sort((a, b) => a.dataset.index - b.dataset.index) // ضمان الترتيب الصحيح
                        .map(slider => parseFloat(slider.value)),
            preset: currentEqPreset
        };
        
        localStorage.setItem('auroraEqSettings', JSON.stringify(settings));
    } catch (err) {
        console.error("Failed to save EQ settings:", err);
    }
}

// **جديد: دالة لتحميل إعدادات المعادل (للواجهة فقط)**
function loadEqSettings() {
    const savedSettings = localStorage.getItem('auroraEqSettings');
    if (!savedSettings) return;

    try {
        const settings = JSON.parse(savedSettings);
        
        // تطبيق المضخم
        const preampSlider = document.getElementById('preampSlider');
        if (preampSlider && settings.preamp !== undefined) {
            preampSlider.value = settings.preamp;
        }
        
        // تطبيق الشرائط
        if (settings.bands && settings.bands.length === eqFrequencies.length) {
            settings.bands.forEach((value, index) => {
                const slider = document.querySelector(`.eq-slider[data-index="${index}"]`);
                if (slider) {
                    slider.value = value;
                }
            });
        }
        
        // تطبيق القائمة المنسدلة للإعدادات
        if (settings.preset && settings.preset !== 'custom') {
    selectPreset(settings.preset, settings.preset === 'default' ? 'الافتراضي (Default)' : `${settings.preset}`);
} else if (settings.preset === 'custom') {
    currentEqPreset = 'custom';
    const selectedSpan = document.getElementById('eqPresetsSelected');
    if (selectedSpan) selectedSpan.textContent = 'مخصص (Custom)';
}
        
        

    } catch (err) {
        console.error('Failed to load EQ settings:', err);
    }
}

function createEqUI() {
    const eqContainer = document.getElementById('eqContainer');
    if (!eqContainer) return;
    
    eqContainer.innerHTML = '';
    
    // إنشاء شريط المضخم الأولي (Preamp)
    const preampContainer = document.createElement('div');
    preampContainer.className = 'eq-band';
    preampContainer.id = 'preamp-band';
    
    const preampLabel = document.createElement('label');
    preampLabel.textContent = 'Preamp';
    
    const preampSlider = document.createElement('input');
    preampSlider.type = 'range';
    preampSlider.min = 0;
    preampSlider.max = 2;
    preampSlider.value = 1;
    preampSlider.step = 0.1;
    preampSlider.className = 'eq-slider';
    preampSlider.id = 'preampSlider';
    preampSlider.setAttribute('orient', 'vertical');

    preampSlider.addEventListener('input', function(e) {
        if (typeof window.paintEqSlider === 'function') window.paintEqSlider(e.target);
        handlePreampChange(e);
    });
    preampSlider.addEventListener('dblclick', (e) => {
        e.target.value = 1;
        if (typeof window.paintEqSlider === 'function') window.paintEqSlider(e.target);
        handlePreampChange(e);
    });
    
    preampContainer.appendChild(preampSlider); 
    preampContainer.appendChild(preampLabel);
    eqContainer.appendChild(preampContainer);
    
    // إنشاء شرائط المعادل (EQ)
    eqFrequencies.forEach((freq, index) => {
        const bandContainer = document.createElement('div');
        bandContainer.className = 'eq-band';
        
        const label = document.createElement('label');
        label.textContent = freq < 1000 ? `${freq} Hz` : `${freq/1000} kHz`;
        
        const slider = document.createElement('input');
        slider.type = 'range';
        slider.min = -12;
        slider.max = 12;
        slider.value = 0;
        slider.step = 0.1;
        slider.className = 'eq-slider';
        slider.dataset.index = index;
        slider.setAttribute('orient', 'vertical');

        slider.addEventListener('input', function(e) {
            if (typeof window.paintEqSlider === 'function') window.paintEqSlider(e.target);
            handleEqChange(e);
        });
        slider.addEventListener('dblclick', function(e) { resetEqSlider(e); if (typeof window.paintEqSlider === 'function') window.paintEqSlider(e.target); }); 
        
        bandContainer.appendChild(slider); 
        bandContainer.appendChild(label);
        eqContainer.appendChild(bandContainer);
    });
    // تلوين جميع الشرائط بعد الإنشاء
    setTimeout(function() {
        eqContainer.querySelectorAll('.eq-slider').forEach(function(s) {
            if (typeof window.paintEqSlider === 'function') window.paintEqSlider(s);
        });
    }, 0);
}

function createPresetsUI() {
    const list = document.getElementById('eqPresetsList');
    const header = document.getElementById('eqPresetsHeader');
    if (!list || !header) return;
    
    list.innerHTML = '';
    
    // أيقونة SVG للإعداد الافتراضي
    const eqDefaultSvg = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>`;
    const eqPresetSvg  = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>`;

    // إضافة الخيار الافتراضي
    const defaultItem = document.createElement('li');
    defaultItem.className = 'dropdown-item selected';
    defaultItem.dataset.value = 'default';
    defaultItem.innerHTML = `<span class="eq-item-icon">${eqDefaultSvg}</span> الافتراضي (Default)`;
    defaultItem.onclick = () => selectPreset('default', 'الافتراضي (Default)');
    list.appendChild(defaultItem);

    // إضافة باقي الإعدادات من كائن eqPresets
    for (const presetName in eqPresets) {
        const item = document.createElement('li');
        item.className = 'dropdown-item';
        item.dataset.value = presetName;
        item.innerHTML = `<span class="eq-item-icon">${eqPresetSvg}</span> ${presetName}`;
        item.onclick = () => selectPreset(presetName, `${presetName}`);
        list.appendChild(item);
    }

    // تفعيل فتح وإغلاق القائمة عند الضغط على الرأس
    header.onclick = (e) => {
        e.stopPropagation();
        header.classList.toggle('active');
        list.classList.toggle('show');
    };

    // إغلاق القائمة عند النقر في أي مكان خارجها
    document.addEventListener('click', (e) => {
        if (!header.contains(e.target) && !list.contains(e.target)) {
            header.classList.remove('active');
            list.classList.remove('show');
        }
    });
}

function selectPreset(presetName, displayText) {
    currentEqPreset = presetName;
    
    // تحديث النص الظاهر وإغلاق القائمة
    const selectedSpan = document.getElementById('eqPresetsSelected');
    if (selectedSpan) selectedSpan.textContent = displayText || presetName;
    
    document.getElementById('eqPresetsHeader')?.classList.remove('active');
    document.getElementById('eqPresetsList')?.classList.remove('show');
    
    // تحديث التحديد البصري في القائمة (العنصر المختار)
    document.querySelectorAll('.dropdown-item').forEach(item => {
        item.classList.toggle('selected', item.dataset.value === presetName);
    });

    if (presetName === 'default') {
        resetAllEq(false); // false لمنع حلقة التكرار بين الدالتين
        return;
    }
    
    const gains = eqPresets[presetName];
    if (!gains || !audioContext) return;
    
    try {
        // ── تطبيق ناعم للإعداد: رمبة 50ms لكل النطاقات دفعة واحدة ──
        const t = audioContext.currentTime;
        gains.forEach((value, index) => {
            if (eqBands[index]) {
                eqBands[index].gain.cancelScheduledValues(t);
                eqBands[index].gain.setValueAtTime(eqBands[index].gain.value, t);
                eqBands[index].gain.linearRampToValueAtTime(value, t + 0.05);
                const slider = document.querySelector(`.eq-slider[data-index="${index}"]`);
                if (slider) slider.value = value;
            }
        });
        
        const preampSlider = document.getElementById('preampSlider');
        if (preampSlider) {
            preampSlider.value = 1;
            handlePreampChange({ target: preampSlider });
        }
        
        showToast(`تم تطبيق: ${presetName}`, 'info');
        saveEqSettings();
        // إعادة تلوين جميع الشرائط
        document.querySelectorAll('.eq-slider').forEach(function(s) {
            if (typeof window.paintEqSlider === 'function') window.paintEqSlider(s);
        });
    } catch (error) {
        console.error('Error applying EQ preset:', error);
        showToast('حدث خطأ في تطبيق الإعداد', 'error');
    }
}

function handlePreampChange(e) {
    if (!audioContext || !preampGain) return;
    try {
        const value = parseFloat(e.target.value);
        // ── تغيير ناعم بدون فرقعة: رمبة خطية 25ms بدلاً من تغيير فوري ──
        const t = audioContext.currentTime;
        preampGain.gain.cancelScheduledValues(t);
        preampGain.gain.setValueAtTime(preampGain.gain.value, t);
        preampGain.gain.linearRampToValueAtTime(value, t + 0.025);
        saveEqSettingsDebounced(); // [تحسين] مؤجّل
    } catch (error) {
        console.error('Error handling preamp change:', error);
    }
}

function handleEqChange(e) {
    if (!audioContext || eqBands.length === 0) return;
    
    try {
        const index = parseInt(e.target.dataset.index);
        const value = parseFloat(e.target.value);
        
        if (eqBands[index]) {
            // ── تغيير ناعم بدون فرقعة: رمبة خطية 20ms بدلاً من تغيير فوري ──
            const t = audioContext.currentTime;
            eqBands[index].gain.cancelScheduledValues(t);
            eqBands[index].gain.setValueAtTime(eqBands[index].gain.value, t);
            eqBands[index].gain.linearRampToValueAtTime(value, t + 0.020);
        }
        currentEqPreset = 'custom';
        const selectedSpan = document.getElementById('eqPresetsSelected');
        if (selectedSpan) selectedSpan.textContent = 'مخصص (Custom)';
        document.querySelectorAll('.dropdown-item').forEach(item => item.classList.remove('selected'));
        saveEqSettingsDebounced(); // [تحسين] مؤجّل لتجنب كتابة متكررة أثناء السحب
    } catch (error) {
        console.error('Error handling EQ change:', error);
    }
}

function resetEqSlider(e) {
    e.target.value = 0;
    handleEqChange(e);
}

function resetAllEq(updateUIOnly = true) {
    try {
        // ── إعادة ضبط ناعمة: رمبة 40ms لكل النطاقات دفعة واحدة ──
        if (audioContext && eqBands.length > 0) {
            const t = audioContext.currentTime;
            eqBands.forEach(band => {
                band.gain.cancelScheduledValues(t);
                band.gain.setValueAtTime(band.gain.value, t);
                band.gain.linearRampToValueAtTime(0, t + 0.04);
            });
        }
        if (audioContext && preampGain) {
            const t = audioContext.currentTime;
            preampGain.gain.cancelScheduledValues(t);
            preampGain.gain.setValueAtTime(preampGain.gain.value, t);
            preampGain.gain.linearRampToValueAtTime(1.0, t + 0.04);
        }

        // تحديث واجهة الشرائط دون إطلاق أحداث صوتية
        document.querySelectorAll('.eq-slider[data-index]').forEach(slider => {
            slider.value = 0;
        });
        const preampSlider = document.getElementById('preampSlider');
        if (preampSlider) preampSlider.value = 1;
        
        // تحديث واجهة القائمة المخصصة
        currentEqPreset = 'default';
        const selectedSpan = document.getElementById('eqPresetsSelected');
        if (selectedSpan) selectedSpan.textContent = 'الافتراضي (Default)';
        document.querySelectorAll('.dropdown-item').forEach(item => {
            item.classList.toggle('selected', item.dataset.value === 'default');
        });
        
        if (updateUIOnly) {
            showToast('تم إعادة ضبط المعادل', 'info');
            saveEqSettings();
        }
        // إعادة تلوين جميع الشرائط
        document.querySelectorAll('.eq-slider').forEach(function(s) {
            if (typeof window.paintEqSlider === 'function') window.paintEqSlider(s);
        });
    } catch (error) {
        console.error('Error resetting EQ:', error);
    }
}

// ملاحظة: تمت إزالة نظام Wake Lock من هذا الملف (كان مكرراً).
// Wake Lock تُديره 18-fullscreen.js بشكل صحيح داخل IIFE معزول.

// ===============================================
// دوال إدارة قائمة السياق
// ===============================================


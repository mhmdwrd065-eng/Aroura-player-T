// دالة استعادة القائمة (من الذاكرة الدائمة) - المعدلة
// ===============================================
async function loadAndRestorePlaylist() {
    // في وضع أندرويد الأصلي: AuroraBridge يتولى استعادة الملفات من المجلد المحفوظ
    // لا نحتاج لتحميل الملفات من IndexedDB (لأنها لا تُحفظ هناك في وضع URI proxy)
    if (typeof AuroraBridge !== 'undefined' && AuroraBridge.isNative()) {
        console.log('[Playlist] وضع Native — الاستعادة تتم عبر AuroraBridge');
        return false;
    }

    try {

        // 1. تحميل *كل* الملفات المحفوظة (صوت + صور)
        const allStoredFiles = await dbManager.getAllAudioFiles();

        if (!allStoredFiles || allStoredFiles.length === 0) {
            return false;
        }

        // 2. فصل الصوتيات عن الصور
        const audioFilesOnly = allStoredFiles.filter(f => f.type.startsWith('audio/'));
        
        // (هام) بناء خريطة الصور والكلمات باستخدام *كل* الملفات
        buildFileMaps(allStoredFiles);

        // تحميل إعدادات القائمة
        let playlistData = await dbManager.load('auroraPlaylist');
        
        // تعيين الصوتيات فقط للمتغير العام للقائمة
        files = audioFilesOnly;
        allUploadedFiles = allStoredFiles; // حفظ الكل هنا للمرجع

        // 3. استعادة الحالة (الترتيب، آخر أغنية...)
        if (playlistData) {
            isRandomPlayback = playlistData.isRandom || false;
            isLoopMode = (playlistData.loopMode !== undefined) ? playlistData.loopMode : 2;
            currentSortMode = (playlistData.sortMode !== undefined) ? playlistData.sortMode : 2;

            if (playlistData.fileRefs && playlistData.fileRefs.length > 0) {
                const fileMap = new Map(files.map(f => [f.customPath || f.name, f]));
                const sortedFiles = [];
                
                playlistData.fileRefs.forEach(ref => {
                    const file = fileMap.get(ref.path);
                    if (file) sortedFiles.push(file);
                });

                // إضافة أي ملفات جديدة قد لا تكون في الريفرنس
                files.forEach(f => {
                    if (!sortedFiles.includes(f)) sortedFiles.push(f);
                });

                if(sortedFiles.length > 0) files = sortedFiles;
            }

        if (playlistData.lastPlayed && playlistData.lastPlayed.path) {
                const lastPath = playlistData.lastPlayed.path;
                const idx = files.findIndex(f => (f.customPath || f.name) === lastPath);
                currentIndex = (idx !== -1) ? idx : 0;
                restoredSeekTime = playlistData.lastPlayed.time || 0;
                
                // لا إشعار عند استئناف الموضع — المستخدم يرى الوقت في الواجهة مباشرة
            }

            if (playlistData.queueRefs) {
                const queueSet = new Set(playlistData.queueRefs);
                fileQueue = [];
                files.forEach((f, i) => {
                    if (queueSet.has(f.customPath || f.name)) fileQueue.push(i);
                });
            }

            // ── استعادة حالة العشوائية الكاملة ──────────────────────────
            if (isRandomPlayback && playlistData.shuffleState) {
                const ss = playlistData.shuffleState;
                const pathToIndex = new Map(files.map((f, i) => [f.customPath || f.name, i]));

                // إعادة بناء قائمة العشوائية بنفس الترتيب المحفوظ
                const restoredIndices = ss.indices
                    .map(path => pathToIndex.get(path))
                    .filter(i => i !== undefined);

                if (restoredIndices.length > 0) {
                    shuffledIndices = restoredIndices;
                    // استعادة موضع المؤشر وتصحيحه إذا خرج عن الحدود
                    shufflePointer = Math.min(ss.pointer || 0, shuffledIndices.length - 1);
                    // التأكد من أن المؤشر يشير للأغنية الحالية الصحيحة
                    const currentInShuffle = shuffledIndices.indexOf(currentIndex);
                    if (currentInShuffle !== -1) shufflePointer = currentInShuffle;

                    // استعادة سجل التاريخ
                    shuffleHistory = (ss.history || [])
                        .map(path => pathToIndex.get(path))
                        .filter(i => i !== undefined);
                } else {
                    // القائمة المحفوظة لا تطابق الملفات الحالية — إعادة توليد
                    generateShuffledList();
                    shuffleHistory = [];
                }
            } else if (isRandomPlayback) {
                // العشوائية مفعّلة لكن لا يوجد حالة محفوظة — توليد جديد
                generateShuffledList();
                shuffleHistory = [];
            }
        } else {
            sortPlaylist(true);
        }

        renderPlaylist();
        updateQueueIndicator();
        updatePlaylistHighlight();
        updateButtonStates();

        if (files[currentIndex]) {
            updateTrackInfo(files[currentIndex]);
            currentTimeEl.textContent = formatTime(restoredSeekTime);
            
            // (هام) محاولة تحميل صورة الغلاف للأغنية المستعادة فوراً
            // نحاول أولاً من الكاش (صورة مضمّنة في ID3)، ثم من الغلاف المجلدي
            const fileKey = `${files[currentIndex].name}_${files[currentIndex].size}`;
            dbManager.loadMeta(fileKey).then(cachedMeta => {
                if (cachedMeta && cachedMeta.imageUrl) {
                    // صورة مُخزَّنة من الكاش (base64) — نعرضها فوراً
                    if (coverArt.dataset.blobUrl) {
                        URL.revokeObjectURL(coverArt.dataset.blobUrl);
                        coverArt.dataset.blobUrl = '';
                    }
                    coverArt.src = cachedMeta.imageUrl;
                    coverArt.style.display = 'block';
                    defaultIcon.style.display = 'none';
                    extractDominantColor(coverArt, (r, g, b) => applyThemeColor(r, g, b));
                } else {
                    // البحث عن صورة في المجلد
                    const folderCover = findFolderCover(files[currentIndex]);
                    if (folderCover) {
                        const coverUrl = (folderCover.isUriProxy && folderCover.playUrl) ? folderCover.playUrl : URL.createObjectURL(folderCover);
                        if (coverArt.dataset.blobUrl) {
                            URL.revokeObjectURL(coverArt.dataset.blobUrl);
                        }
                        coverArt.dataset.blobUrl = coverUrl;
                        coverArt.src = coverUrl;
                        coverArt.style.display = 'block';
                        defaultIcon.style.display = 'none';
                        extractDominantColor(coverArt, (r, g, b) => applyThemeColor(r, g, b));
                    } else {
                        [audioPlayer, audioCanvas, coverArt].forEach(el => el.style.display = 'none');
                        defaultIcon.style.display = 'flex';
                        resetThemeColor();
                    }
                }
            }).catch(() => {
                // في حالة فشل الكاش، نحاول غلاف المجلد
                const folderCover = findFolderCover(files[currentIndex]);
                if (folderCover) {
                    const coverUrl = (folderCover.isUriProxy && folderCover.playUrl) ? folderCover.playUrl : URL.createObjectURL(folderCover);
                    if (coverArt.dataset.blobUrl) URL.revokeObjectURL(coverArt.dataset.blobUrl);
                    coverArt.dataset.blobUrl = coverUrl;
                    coverArt.src = coverUrl;
                    coverArt.style.display = 'block';
                    defaultIcon.style.display = 'none';
                    extractDominantColor(coverArt, (r, g, b) => applyThemeColor(r, g, b));
                } else {
                    [audioPlayer, audioCanvas, coverArt].forEach(el => el.style.display = 'none');
                    defaultIcon.style.display = 'flex';
                    resetThemeColor();
                }
            });
        }

        return true;

    } catch (err) {
        console.error('Failed to restore permanently:', err);
        showToast('فشل استعادة المكتبة الصوتية', 'error');
        return false;
    }
}

function sortPlaylist(initialSort = false) {
    // تغيير وضع الفرز إذا لم يكن تحميل أولي
    if (!initialSort) currentSortMode = (currentSortMode + 1) % 3;

    if (files.length === 0) {
        currentSortMode = 2;
        renderPlaylist();
        return;
    }

    // حفظ مرجع الملف الحالي قبل إعادة الترتيب
    const currentFile = files[currentIndex];

    // حفظ كائنات الانتظار (لإعادة بناء فهارسها بعد الفرز)
    const queuedFilesObjects = fileQueue.map(idx => files[idx]);

    let newFiles = [...files];

    // ── تعريف أوضاع الفرز ──
    const modes = [
        {
            name: 'أبجدي',
            btn: '🔠 فرز أبجدي',
            sort: (a, b) => {
                // تنظيف الاسم: إزالة الامتداد والأرقام التسلسلية مثل "01 - " أو "03. "
                const clean = name =>
                    name.replace(/\.[^/.]+$/, '')          // حذف الامتداد
                        .replace(/^\d+[\s.\-_]+/, '')       // حذف رقم البداية
                        .trim();
                return clean(a.name).localeCompare(clean(b.name), 'ar', {
                    sensitivity: 'base',
                    numeric: true,      // 2 قبل 10
                    ignorePunctuation: true
                });
            }
        },
        {
            name: 'عشوائي',
            btn: '🔀 فرز عشوائي',
            sort: null   // نستخدم Fisher-Yates بدل sort() للحصول على عشوائية حقيقية
        },
        {
            name: 'وقت الإضافة',
            btn: '⏱️ فرز حسب الإضافة',
            sort: (a, b) => (a.timeAdded || 0) - (b.timeAdded || 0)
        }
    ];

    const mode = modes[currentSortMode];

    if (mode.sort) {
        // فرز عادي (أبجدي أو حسب وقت الإضافة)
        newFiles.sort(mode.sort);
    } else {
        // خوارزمية Fisher-Yates للخلط العشوائي الحقيقي
        // (Array.sort مع Math.random() منحازة إحصائياً)
        for (let i = newFiles.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [newFiles[i], newFiles[j]] = [newFiles[j], newFiles[i]];
        }
    }

    // تحديث نصوص الواجهة
    sortButton.textContent   = mode.btn;
    sortModeDisplay.textContent = `(${mode.name})`;

    files = newFiles;

    // إعادة تحديد موضع الأغنية الحالية بعد إعادة الترتيب
    currentIndex = files.indexOf(currentFile);
    if (currentIndex === -1) currentIndex = 0;

    // إعادة بناء فهارس الانتظار بالأرقام الجديدة
    fileQueue = queuedFilesObjects
        .map(file => files.indexOf(file))
        .filter(idx => idx !== -1);

    updateQueueIndicator();
    renderPlaylist();
    savePlaylistState();
}

// استبدل دالة renderPlaylist الحالية بهذا المنطق
function filterPlaylistOnly(searchTerm) {
    const items = document.querySelectorAll('.playlist-item');
    const lowerTerm = searchTerm.toLowerCase();
    let hasResults = false;

    items.forEach(item => {
        // نفترض أن الاسم موجود داخل span بداخل العنصر
        const text = item.querySelector('.playlist-item-name').textContent.toLowerCase();
        
        if (text.includes(lowerTerm)) {
            item.style.display = ''; // إظهار
            hasResults = true;
        } else {
            item.style.display = 'none'; // إخفاء
        }
    });

    // إظهار رسالة "لا توجد نتائج" إذا لزم الأمر
    let noResultMsg = document.getElementById('no-results-msg');
    if (!hasResults) {
        if (!noResultMsg) {
            noResultMsg = document.createElement('li');
            noResultMsg.id = 'no-results-msg';
            noResultMsg.textContent = 'لا توجد نتائج.';
            noResultMsg.style.textAlign = 'center';
            playlistElement.appendChild(noResultMsg);
        }
        noResultMsg.style.display = 'block';
    } else if (noResultMsg) {
        noResultMsg.style.display = 'none';
    }
}

// تحسين: إزالة مستمعي الأحداث الفردية واستخدام Event Delegation
function renderPlaylist(searchTerm = '') {
    const fragment = document.createDocumentFragment();
    playlistElement.innerHTML = ''; // تفريغ القائمة القديمة
    
    const filteredFiles = files.filter(file => file.name.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (filteredFiles.length === 0) {
        playlistElement.innerHTML = `<li style="color:var(--accent-color);text-align:center;padding:20px;">${files.length > 0 ? 'لا توجد نتائج.' : 'اختر ملف أو مجلد.'}</li>`;
        return;
    }
    
    filteredFiles.forEach(file => {
        const index = files.indexOf(file);
        const listItem = document.createElement('li');
        listItem.className = `playlist-item ${fileQueue.includes(index) ? 'queued' : ''}`;
        listItem.dataset.index = index;
        
        const nameSpan = document.createElement('span');
        nameSpan.className = 'playlist-item-name';
        nameSpan.textContent = `${index + 1}. ${file.name}`;
        
        const queueButton = document.createElement('button');
        queueButton.className = 'queue-btn';
        
        if (index === currentIndex) {
            // الأغنية الحالية — زر معطّل مع تلميح واضح
            queueButton.textContent = '▶️ يعمل الآن';
            queueButton.title = 'لا يمكن إضافة الأغنية الحالية للانتظار';
            queueButton.disabled = true;
            queueButton.classList.add('queue-btn-disabled');
        } else {
            const queuePosition = fileQueue.indexOf(index);
            if (queuePosition === 0) {
                queueButton.textContent = `[ التالي ]`;
                queueButton.title = 'إزالة (أول الانتظار)';
            } else if (queuePosition > 0) {
                queueButton.textContent = `#${queuePosition + 1} -`;
                queueButton.title = 'إزالة';
            } else {
                queueButton.textContent = '➕ انتظار';
                queueButton.title = 'إضافة للانتظار';
            }
        }
        
        listItem.append(nameSpan, queueButton);
        fragment.appendChild(listItem);
    });
    
    playlistElement.appendChild(fragment);
    updatePlaylistHighlight();
    
    // **إضافة: تمرير تلقائي عند عرض القائمة (إذا كانت مفتوحة)**
    if (playlistOverlay.style.display === 'flex') {
        setTimeout(() => {
            scrollToCurrentSong();
        }, 50);
    }
}

async function selectTrack(index) {
    currentIndex = index;
    
    // ** مزامنة المؤشر العشوائي إذا كان التشغيل عشوائياً **
    if (isRandomPlayback && shuffledIndices.length > 0) {
        const posInShuffle = shuffledIndices.indexOf(currentIndex);
        if (posInShuffle !== -1) {
            // الأغنية موجودة في القائمة — فقط نقل المؤشر إليها
            shufflePointer = posInShuffle;
        } else {
            // الأغنية خارج القائمة (جُمب مباشر) — إدراجها بعد المؤشر الحالي
            // هذا يحافظ على باقي ترتيب القائمة العشوائية
            const insertAt = shufflePointer + 1;
            shuffledIndices.splice(insertAt, 0, currentIndex);
            shufflePointer = insertAt;
        }
    }
    
    // **تعديل: تنظيف قائمة الانتظار من الأغنية الحالية فقط**
    const queueIndex = fileQueue.indexOf(index);
    if (queueIndex > -1) {
        fileQueue.splice(queueIndex, 1);
    }
    
    searchInput.value = '';
    renderPlaylist(); 
    savePlaylistState();
    await playFile(files[currentIndex]); 
    hideOverlay('playlistOverlay');
}

function updatePlaylistHighlight() {
    const previousActive = playlistElement.querySelector('.playlist-item.active');
    if (previousActive) previousActive.classList.remove('active');
    
    const currentActive = playlistElement.querySelector(`.playlist-item[data-index="${currentIndex}"]`);
    if (currentActive) {
        currentActive.classList.add('active');
        
        // **إضافة: إزالة حالة "في الانتظار" إذا كانت الأغنية تعمل**
        currentActive.classList.remove('queued');
        const queueBtn = currentActive.querySelector('.queue-btn');
        if (queueBtn) {
            queueBtn.textContent = '➕ انتظار';
            queueBtn.title = 'إضافة للانتظار';
        }
    }
}

function showOverlay(overlayId) {
    const overlay = document.getElementById(overlayId);
    if (!overlay) return;
    overlay.style.display = 'flex';
    
    // **إضافة: تمرير إلى الأغنية الحالية عند فتح قائمة التشغيل**
    if (overlayId === 'playlistOverlay') {
        setTimeout(() => {
            scrollToCurrentSong();
        }, 100); // تأخير بسيط لضمان تحميل القائمة
    }
    
    // نضيف Hash فقط إذا لم يكن موجوداً لمنع التكرار
    if (window.location.hash !== '#' + overlayId) {
        history.pushState({ overlay: overlayId }, '', '#' + overlayId);
    }
}

function clearSearch() {
    searchInput.value = '';
    renderPlaylist();
}

// ===============================================
// نظام إدارة تاريخ التنقل (History API)
// ملاحظة: يوجد مستمع popstate واحد موحَّد في قسم الأحداث الرئيسية أدناه
// ===============================================

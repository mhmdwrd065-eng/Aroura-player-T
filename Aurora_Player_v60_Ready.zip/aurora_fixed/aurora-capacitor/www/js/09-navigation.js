async function skipFile(direction) {
    if (isTransitioning) {
        showToast('...لحظة...', 'info', 500);
        return;
    }
    
    if (files.length === 0) return;
    
    let newIndex;
    
    // ── قائمة الانتظار تأخذ الأولوية دائماً عند التقديم ──
    if (direction === 1 && fileQueue.length > 0) {
        // في وضع العشوائية: نسجّل الأغنية الحالية في التاريخ قبل مغادرتها
        // حتى يعمل زر السابق بشكل صحيح حتى بعد استهلاك قائمة الانتظار
        if (isRandomPlayback) {
            shuffleHistory.push(currentIndex);
            if (shuffleHistory.length > MAX_SHUFFLE_HISTORY) shuffleHistory.shift();
        }

        newIndex = fileQueue.shift(); // سحب أول عنصر من قائمة الانتظار
        renderPlaylist();

        // مزامنة مؤشر العشوائية مع الأغنية المسحوبة من القائمة:
        // إذا كانت الأغنية موجودة في قائمة العشوائية المولّدة، ننقل المؤشر إليها
        // حتى لا تُعاد من جديد عند انتهاء قائمة الانتظار
        if (isRandomPlayback && shuffledIndices.length > 0) {
            const posInShuffle = shuffledIndices.indexOf(newIndex);
            if (posInShuffle !== -1) {
                shufflePointer = posInShuffle; // نحرّك المؤشر لهذه الأغنية
            } else {
                // الأغنية لم تكن في قائمة العشوائية (مثلاً أُضيفت للأول يدوياً)
                // ندرجها بعد الموضع الحالي حتى تكمل العشوائية من هنا بشكل سلس
                shufflePointer++;
                if (shufflePointer < shuffledIndices.length) {
                    shuffledIndices.splice(shufflePointer, 0, newIndex);
                } else {
                    shuffledIndices.push(newIndex);
                    shufflePointer = shuffledIndices.length - 1;
                }
            }
        }

    } else if (isRandomPlayback) {
        if (direction === 1) {
            // حفظ الأغنية الحالية في سجل التاريخ قبل الانتقال
            shuffleHistory.push(currentIndex);
            if (shuffleHistory.length > MAX_SHUFFLE_HISTORY) {
                shuffleHistory.shift(); // إزالة القديم للحفاظ على الذاكرة
            }

            shufflePointer++;
            if (shufflePointer >= shuffledIndices.length) {
                // انتهت جولة العشوائية — توليد جولة جديدة ذكية تتجنب تكرار الأغنية الأخيرة
                const lastPlayed = shuffledIndices[shuffledIndices.length - 1];
                generateShuffledList();
                // إذا بدأت الجولة الجديدة بالأغنية التي انتهينا منها للتو، قم بمبادلتها
                if (shuffledIndices.length > 1 && shuffledIndices[0] === lastPlayed) {
                    const swapIdx = 1 + Math.floor(Math.random() * (shuffledIndices.length - 1));
                    [shuffledIndices[0], shuffledIndices[swapIdx]] = [shuffledIndices[swapIdx], shuffledIndices[0]];
                }
                shufflePointer = 1; // تخطي index 0 (الأغنية الحالية التي تم وضعها أولاً)
                showToast('جولة عشوائية جديدة', 'info', 2000);
            }
            newIndex = shuffledIndices[shufflePointer];

        } else {
            // زر "السابق" — العودة للأغنية المشغّلة فعلاً قبلها
            if (shuffleHistory.length > 0) {
                newIndex = shuffleHistory.pop();
                // ضبط المؤشر ليشير للأغنية المستعادة في القائمة المخلوطة
                const historyPointer = shuffledIndices.indexOf(newIndex);
                if (historyPointer !== -1) shufflePointer = historyPointer;
            } else {
                // لا يوجد سجل — الذهاب لآخر عنصر في القائمة المخلوطة
                shufflePointer = shuffledIndices.length - 1;
                newIndex = shuffledIndices[shufflePointer];
            }
        }
    
    } else if (direction === 1) { 
        newIndex = currentIndex + 1;
        if (newIndex >= files.length) {
            if (isLoopMode === 0) {
                newIndex = 0;
            } else {
                await fadeOut(getActivePlayer()); 
                updateTrackInfo(files[files.length-1]);
                trackArtistEl.textContent = "انتهت القائمة";
                return;
            }
        }
    } else { 
        newIndex = (currentIndex - 1 + files.length) % files.length;
    }
    
    currentIndex = newIndex;
    savePlaylistState();
    
    // تنظيف الأغنية الجديدة من قائمة الانتظار (إن كانت فيها) وتحديث الواجهة
    cleanCurrentFromQueue();
    const queueIndex = fileQueue.indexOf(newIndex);
    if (queueIndex > -1) {
        fileQueue.splice(queueIndex, 1);
        renderPlaylist();
    }
    
    // ══════════════════════════════════════════════════════════════════
    // إصلاح: مسح وقت الاستئناف المحفوظ عند الانتقال الطوعي لأغنية جديدة
    // السبب: restoredSeekTime يُضبط عند فتح التطبيق ليستأنف من آخر موضع،
    // لكن إذا انتقل المستخدم لأغنية مختلفة بدون أن يضغط تشغيل أولاً،
    // كانت الأغنية الجديدة تبدأ من نفس الوقت القديم بالخطأ.
    // الحل: مسحه هنا لأن هذا انتقال طوعي وليس استئنافاً للجلسة السابقة.
    // ══════════════════════════════════════════════════════════════════
    restoredSeekTime = 0;
    localStorage.removeItem('aurora_exact_time');

    await playFile(files[currentIndex]);
}

async function playNext() { 
    await skipFile(1); 
}

async function playPrevious() { 
    await skipFile(-1); 
}

function toggleQueueState(index) {
    if (index === currentIndex) {
        showToast('هذه الأغنية تعمل الآن — لا يمكن إضافتها للانتظار', 'info', 2500);
        return;
    }
    
    const queueIndex = fileQueue.indexOf(index);
    
    // تحديث UI العنصر المحدد فقط بدلاً من إعادة رسم القائمة كاملة
    const itemElement = playlistElement.querySelector(`.playlist-item[data-index="${index}"]`);
    
    if (queueIndex > -1) {
        // إزالة الأغنية من الانتظار
        fileQueue.splice(queueIndex, 1);
        if (itemElement) {
            itemElement.classList.remove('queued');
            const queueBtn = itemElement.querySelector('.queue-btn');
            if (queueBtn) {
                queueBtn.textContent = '+ انتظار';
                queueBtn.title = 'إضافة للانتظار';
            }
        }
        // تحديث أرقام الانتظار للأزرار الأخرى
        fileQueue.forEach((queuedIndex, newOrder) => {
             const otherItem = playlistElement.querySelector(`.playlist-item[data-index="${queuedIndex}"] .queue-btn`);
             if (otherItem) otherItem.textContent = `#${newOrder + 1} -`;
        });
        showToast('تمت الإزالة من قائمة الانتظار', 'info');
        
    } else {
        // إضافة الأغنية لآخر قائمة الانتظار
        fileQueue.push(index);
        if (itemElement) {
            itemElement.classList.add('queued');
            const queueBtn = itemElement.querySelector('.queue-btn');
            if (queueBtn) {
                queueBtn.textContent = `#${fileQueue.length} -`;
                queueBtn.title = 'إزالة';
            }
        }
        showToast(`تمت الإضافة (#${fileQueue.length} في الانتظار)`, 'success');
    }
    
    updateQueueIndicator();
    savePlaylistState();
}

function updateQueueIndicator() {
    if (fileQueue.length > 0) {
        // نُظهر اسم الأغنية الأولى في القائمة كتلميح للمستخدم
        const firstInQueue = files[fileQueue[0]];
        const firstName = firstInQueue
            ? firstInQueue.name.substring(0, firstInQueue.name.lastIndexOf('.')) || firstInQueue.name
            : '';
        const shortName = firstName.length > 20 ? firstName.substring(0, 20) + '…' : firstName;
        queueIndicator.textContent = `[ التالي: ${shortName}  (${fileQueue.length} في الانتظار) ]`;
        queueIndicator.style.display = 'block';
    } else {
        queueIndicator.style.display = 'none';
    }
}

// دالة مستقلة لتنظيف الأغنية الحالية من قائمة الانتظار
// تُستدعى فقط عند بدء تشغيل أغنية جديدة (في skipFile وplayFile)
function cleanCurrentFromQueue() {
    const currentQueueIndex = fileQueue.indexOf(currentIndex);
    if (currentQueueIndex > -1) {
        fileQueue.splice(currentQueueIndex, 1);
    }
}

async function savePlaylistState() {
    // 1. التعامل السليم مع القائمة الفارغة (عند المسح)
    if (files.length === 0) {
        await dbManager.clear(); 
        localStorage.removeItem('aurora_exact_time'); // تنظيف التوقيت المحفوظ حتى لا يُطبق على أغنية جديدة بالخطأ
        return;
    }
    
    try {
        let lastPlayedData = null;
        const currentPlayer = getActivePlayer();
        
        // 2. التحقق الآمن من وجود الأغنية الحالية فعلياً لتجنب أخطاء (undefined)
        if (files[currentIndex] && currentPlayer) {
            let exactTime = currentPlayer.currentTime;
            const quickTime = localStorage.getItem('aurora_exact_time');
            
            if (quickTime && (!isFinite(exactTime) || currentPlayer.paused)) {
                 exactTime = parseFloat(quickTime);
            }

            // التأكد من أن الوقت رقم صحيح وليس NaN
            if (isNaN(exactTime) || exactTime < 0) {
                exactTime = 0;
            }

            lastPlayedData = {
                path: files[currentIndex].customPath || files[currentIndex].name,
                time: exactTime
            };
        }

        // 3. فلترة قائمة الانتظار (Queue) لحذف أي فهارس لأغاني تم مسحها
        const safeQueueRefs = fileQueue
            .filter(index => files[index]) // يتأكد أن الملف لا يزال موجوداً في المصفوفة
            .map(index => files[index].customPath || files[index].name);

        const playlistData = {
            fileRefs: files.map(f => ({ 
                path: f.customPath || f.name 
            })),
            queueRefs: safeQueueRefs,
            currentIndex: (currentIndex >= 0 && currentIndex < files.length) ? currentIndex : 0, 
            isRandom: isRandomPlayback,
            loopMode: isLoopMode,
            sortMode: currentSortMode,
            lastPlayed: lastPlayedData,
            // حفظ حالة العشوائية الكاملة للاستعادة عند إعادة فتح التطبيق
            shuffleState: isRandomPlayback && shuffledIndices.length > 0 ? {
                // نحفظ مسارات الملفات بدلاً من الأرقام لأن الأرقام قد تتغير بعد إعادة الترتيب
                indices: shuffledIndices.map(i => files[i] ? (files[i].customPath || files[i].name) : null).filter(Boolean),
                pointer: shufflePointer,
                history: shuffleHistory.map(i => files[i] ? (files[i].customPath || files[i].name) : null).filter(Boolean)
            } : null
        };

        await dbManager.save('auroraPlaylist', playlistData);

    } catch (err) {
        console.error("Failed to save playlist state to DB:", err);
    }
}

// ===============================================

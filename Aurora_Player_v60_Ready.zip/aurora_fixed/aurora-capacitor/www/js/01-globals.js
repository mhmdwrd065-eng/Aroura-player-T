// منع القائمة الافتراضية (Right Click / Long Press Menu) في كامل الصفحة
document.addEventListener('contextmenu', (event) => {
    event.preventDefault();
}, { passive: false });

// ===============================================
// دوال مساعدة عامة (Utility Functions)
// ===============================================

/**
 * دالة التأخير (Debounce) — تمنع تكرار الاستدعاء السريع لدالة ما.
 * تُستخدم مثلاً عند البحث الفوري لتجنب إعادة الفلترة عند كل ضغطة.
 * @param {Function} func - الدالة المراد تأخيرها
 * @param {number} delay - زمن التأخير بالملي ثانية
 */
function debounce(func, delay) {
    let timeoutId;
    return function (...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
            func.apply(this, args);
        }, delay);
    };
}

// ===============================================
// مكتبة الأيقونات (SVG Icons Library)
// ===============================================
const svgs = {
    play: `<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`,
    pause: `<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`,
    
    volumeHigh: `<svg viewBox="0 0 24 24"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>`,
    volumeLow: `<svg viewBox="0 0 24 24"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>`,
    volumeMute: `<svg viewBox="0 0 24 24"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>`,
    
    loopAll: `<svg viewBox="0 0 24 24"><polyline points="17 1 21 5 17 9"></polyline><path d="M3 11V9a4 4 0 0 1 4-4h14"></path><polyline points="7 23 3 19 7 15"></polyline><path d="M21 13v2a4 4 0 0 1-4 4H3"></path></svg>`,
    
    // (تم التعديل) جعل الرقم 1 في المنتصف تماماً مع استخدام خط عريض
        loopOne: `<svg viewBox="0 0 24 24">
                <polyline points="17 1 21 5 17 9"></polyline>
                <path d="M3 11V9a4 4 0 0 1 4-4h14"></path>
                <polyline points="7 23 3 19 7 15"></polyline>
                <path d="M21 13v2a4 4 0 0 1-4 4H3"></path>
                <text x="12" y="14" font-size="9" font-family="sans-serif" font-weight="900" fill="currentColor" text-anchor="middle">1</text>
              </svg>`,
              
    loopOff: `<svg viewBox="0 0 24 24" style="opacity: 0.5"><polyline points="17 1 21 5 17 9"></polyline><path d="M3 11V9a4 4 0 0 1 4-4h14"></path><polyline points="7 23 3 19 7 15"></polyline><path d="M21 13v2a4 4 0 0 1-4 4H3"></path></svg>`
};

// ===============================================
// المتغيرات العالمية المُدمجة والمُحسَّنة
// ===============================================
let files = [];
let allUploadedFiles = [];
let currentIndex = 0;
// --- إضافة جديدة (حل المشكلة 4) ---
let currentAudioBlobUrl = null; // متغير لتخزين رابط الملف الحالي
//
let isLoopMode = 2; // 0: loop all, 1: loop one, 2: no loop
let isRandomPlayback = false;
let isLyricsVisible = false;
let lyricsData = [];
let currentLyricIndex = 0; // تحسين: مؤشر لتتبع سطر الكلمات الحالي
let currentSortMode = 2;
let fileQueue = []; 
let isSeeking = false; 

// متغيرات العشوائية الذكية (Smart Shuffle)
let shuffledIndices = [];
let shufflePointer = 0;
let shuffleHistory = []; // سجل الأغاني المشغّلة للتنقل للخلف بشكل صحيح
const MAX_SHUFFLE_HISTORY = 50; // حد أقصى لتوفير الذاكرة

let isTransitioning = false;
let previousVolume = 1.0;
let restoredSeekTime = 0; // **جديد: لحفظ وقت الاستعادة**

// تحسين: خرائط للوصول السريع للملفات (O(1)) بدلاً من البحث المتكرر
let coverMap = new Map();   // مسار المجلد -> ملف الصورة
let lyricsMap = new Map();  // اسم الملف الأساسي -> ملف الكلمات (lrc/srt)

var audioContext = null, analyser = null, mediaSource = null, animationFrameId = null;
var freqDataArray = null, timeDataArray = null;


const visualizerModes = ['auto-cycle', 'freq-bars', 'oval-pulse', 'time-wave', 'mirror-bars', 'scatter', 'v-bars', 'dot-matrix', 'energy-ring', 'helix', 'tunnel', 'rain-drops', 'sphere', 'digital-glitch', 'ripple', 'fireworks', 'wave-ribbon', 'pulsar', 'starfield', 'vortex', 'geometric', 'galaxy-matrix', 'laser-bubbles', 'digital-waterfall', 'edge-glow', 'plasma-tunnel', 'equalizer-3d', 'sound-web', 'rainbow-ring', 'radial-bars', 'spinning-lines', 'confetti-burst', 'neon-grid', 'audio-sun', 'liquid-metal', 'sync-squares', 'star-trails', 'dynamic-rings', 'aurora-curtain', 'sound-drops', 'shockwave'];
let visualizerModeIndex = -1;
let confettiParticles = [], starTrailsParticles = [], lastBassHit = 0;
let liveRipples = [], lastBeat = 0;

let autoCycleTimer = null;
const AUTO_CYCLE_DELAY = 10000;

let tapTimer = null;
let longPressTimer = null;
let isLongPressing = false;
let isDragging = false;
let touchStartX = 0;
let touchStartY = 0;
const tapDelay = 300;
const longPressDelay = 500;

let searchTimeout = null;

// متغيرات زر المؤثرات البصرية
let blossomClickCount = 0;
let blossomClickActionTimer = null;
let blossomPressTimer = null;
let isBlossomLongPress = false;

// ===============================================
// متغيرات قائمة السياق (أضف مع المتغيرات العالمية)
// ===============================================
let contextMenuVisible = false;
let currentContextIndex = -1;
let contextLongPressTimer = null;
const LONG_PRESS_DURATION = 500; // 0.5 ثانية

// == متغيرات المعادل الصوتي الاحترافي ==
let preampGain;
let eqBands = [];
// ترددات المعادل (9 ترددات)
const eqFrequencies = [60, 170, 310, 600, 1000, 3000, 6000, 12000, 16000];
let masterGain;
let isEqSetup = false; 

// إعداد V-Shape — معادلات محسّنة بقيم مدروسة موسيقياً
const eqPresets = {
    'Pop':                    [ -1,  2,  4,  5,  3, -1, -2, -2, -1 ],
    'Rock':                   [  5,  4,  2, -2, -1,  1,  4,  5,  5 ],
    'Jazz':                   [  3,  2,  1,  2, -1, -1,  0,  2,  3 ],
    'Classical':              [  4,  3,  2,  0, -2, -2,  0,  3,  4 ],
    'Hip-Hop':                [  7,  6,  3,  2, -1, -1,  2,  3,  2 ],
    'Electronic':             [  5,  4,  1, -2, -2,  2,  4,  5,  6 ],
    'R&B / Soul':             [  6,  4,  2,  3,  2, -1, -1,  2,  3 ],
    'Bass Boost':             [  8,  7,  5,  2,  0,  0,  0,  0, -2 ],
    'Vocal':                  [ -2, -1,  0,  3,  5,  5,  3,  1, -1 ],
    'Treble Boost':           [ -2,  0,  0,  0,  1,  3,  5,  7,  8 ],
    'V-Shape (Bass & Treble)': [  7,  5,  2, -2, -3, -1,  3,  6,  8 ],
    'Acoustic':               [  4,  3,  2,  4,  2,  1,  2,  3,  3 ],
    'Podcast / Speech':       [ -3, -2,  0,  4,  6,  5,  3,  0, -2 ],
    'Late Night':             [  3,  5,  4,  2,  0,  0,  1,  3,  4 ]
};

// ===============================================
// مدير الذاكرة (Blob Memory Manager) - جديد 🛠️
// ===============================================
const BlobManager = {
    audioUrl: null,
    coverUrl: null,

    /**
     * إنشاء رابط Blob لملف الصوت.
     * ملاحظة: تتولى دالة playFile تدمير الرابط القديم بعد فترة التلاشي (Fade-Out).
     * يُخزَّن الرابط هنا أيضاً ليتمكن cleanupAll من تدميره عند مسح القائمة.
     */
    createAudioUrl(file) {
        // إذا كان الملف URI proxy (من نظام الوصول الدائم) — استخدم playUrl مباشرة
        if (file.isUriProxy && file.playUrl) {
            this.audioUrl = file.playUrl;
            return file.playUrl;
        }
        this.audioUrl = URL.createObjectURL(file);
        return this.audioUrl;
    },

    /** تنظيف رابط صورة الغلاف القديم وإنشاء رابط جديد
     * ملاحظة: هذه الدالة محتفظ بها للاستخدام المستقبلي.
     * الإدارة الفعلية لروابط الغلاف تتم حالياً عبر coverArt.dataset.blobUrl في setCover (06-player.js).
     */
    createCoverUrl(blob) {
        if (this.coverUrl) {
            URL.revokeObjectURL(this.coverUrl);
            this.coverUrl = null;
        }
        this.coverUrl = URL.createObjectURL(blob);
        return this.coverUrl;
    },

    /** تنظيف جميع روابط Blob (يُستدعى عند مسح القائمة) */
    cleanupAll() {
        // URI proxies (capacitor://) لا تحتاج revokeObjectURL
        if (this.audioUrl && !this.audioUrl.startsWith('https://capacitor') && !this.audioUrl.startsWith('capacitor://')) {
            URL.revokeObjectURL(this.audioUrl);
        }
        if (this.coverUrl && !this.coverUrl.startsWith('https://capacitor') && !this.coverUrl.startsWith('capacitor://')) {
            URL.revokeObjectURL(this.coverUrl);
        }
        this.audioUrl = null;
        this.coverUrl = null;
    }
};

// ===============================================
// مدير قاعدة البيانات (IndexedDB Manager)
// بديل قوي لـ localStorage
// ===============================================
// ===============================================
// مدير قاعدة البيانات (IndexedDB Manager) - محدث
// ===============================================
const dbManager = {
    dbName: 'AuroraAudioDB',
    storeName: 'playlistStore',
    metaStoreName: 'metadataStore',
    audioStoreName: 'audioFilesStore',
    dbVersion: 3,

    open() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);
            request.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains(this.storeName)) db.createObjectStore(this.storeName);
                if (!db.objectStoreNames.contains(this.metaStoreName)) db.createObjectStore(this.metaStoreName);
                if (!db.objectStoreNames.contains(this.audioStoreName)) db.createObjectStore(this.audioStoreName, { keyPath: 'id' });
            };
            request.onsuccess = (e) => resolve(e.target.result);
            request.onerror = (e) => reject(e.target.error);
        });
    },

    // --- التعديل هنا: الحفظ بنظام الدفعات لمنع التجميد ---
    async saveAudioFiles(filesList, onProgress) {
        // حجم الدفعة: 10 ملفات في المرة الواحدة (رقم آمن للأداء)
        const BATCH_SIZE = 10; 
        const totalFiles = filesList.length;
        let savedCount = 0;

        // تحويل القائمة لمصفوفة عادية
        const filesArray = Array.from(filesList);

        // حلقة تكرارية للدفعات
        for (let i = 0; i < totalFiles; i += BATCH_SIZE) {
            const batch = filesArray.slice(i, i + BATCH_SIZE);
            
            // فتح اتصال جديد لكل دفعة (يمنع امتلاء الذاكرة)
            const db = await this.open();
            
            await new Promise((resolve, reject) => {
                const tx = db.transaction(this.audioStoreName, 'readwrite');
                const store = tx.objectStore(this.audioStoreName);

                batch.forEach(file => {
                    const uniqueId = (file.customPath || file.name) + '_' + file.size;
                    store.put({
                        id: uniqueId,
                        fileObj: file,
                        path: file.customPath || file.name,
                        added: Date.now()
                    });
                });

                tx.oncomplete = () => {
                    db.close();
                    savedCount += batch.length;
                    // تحديث شريط التقدم إذا وجد
                    if (onProgress) onProgress(savedCount, totalFiles);
                    resolve();
                };
                
                tx.onerror = (e) => {
                    db.close();
                    // نتجاهل أخطاء الملفات المكررة ونستمر
                    console.warn("Skip batch error:", e);
                    resolve(); 
                };
            });

            // (مهم جداً) راحة للمتصفح لمدة 10 ملي ثانية لتحديث الواجهة ومنع التجميد
            await new Promise(r => setTimeout(r, 10));
        }
        
        return savedCount;
    },

    async getAllAudioFiles() {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.audioStoreName, 'readonly');
            const store = tx.objectStore(this.audioStoreName);
            const request = store.getAll();

            request.onsuccess = () => {
                db.close();
                const storedFiles = request.result.map(item => {
                    const file = item.fileObj;
                    file.customPath = item.path;
                    file.timeAdded = item.added;
                    return file;
                });
                resolve(storedFiles);
            };
            request.onerror = (e) => { db.close(); reject(e.target.error); };
        });
    },

    // (باقي الدوال كما هي...)
    async save(key, data) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, 'readwrite');
            const store = tx.objectStore(this.storeName);
            store.put(data, key);
            tx.oncomplete = () => { db.close(); resolve(); };
            tx.onerror = (e) => { db.close(); reject(e.target.error); };
        });
    },

// دالة جديدة لحذف ملف من قاعدة البيانات
    async deleteAudioFile(id) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.audioStoreName, 'readwrite');
            const store = tx.objectStore(this.audioStoreName);
            store.delete(id); // حذف العنصر باستخدام المعرف
            
            tx.oncomplete = () => {
                db.close();
                resolve();
            };
            tx.onerror = (e) => {
                db.close();
                reject(e.target.error);
            };
        });
    },

    async load(key) {
        try {
            const db = await this.open();
            return new Promise((resolve) => {
                const tx = db.transaction(this.storeName, 'readonly');
                const req = tx.objectStore(this.storeName).get(key);
                tx.oncomplete = () => { db.close(); resolve(req.result); };
                tx.onerror = () => { db.close(); resolve(null); };
            });
        } catch (e) { return null; }
    },
    async clear() {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction([this.storeName, this.audioStoreName, this.metaStoreName], 'readwrite');
            tx.objectStore(this.storeName).clear();
            tx.objectStore(this.audioStoreName).clear();
            tx.objectStore(this.metaStoreName).clear();
            tx.oncomplete = () => { db.close(); resolve(); };
            tx.onerror = (e) => { db.close(); reject(e.target.error); };
        });
    },
    async saveMeta(key, data) {
        try {
            const db = await this.open();
            return new Promise((resolve, reject) => {
                const tx = db.transaction(this.metaStoreName, 'readwrite');
                tx.objectStore(this.metaStoreName).put(data, key);
                tx.oncomplete = () => { db.close(); resolve(); };
                tx.onerror = (e) => { db.close(); console.warn('saveMeta error:', e); resolve(); };
            });
        } catch (e) { console.warn(e); }
    },
    async loadMeta(key) {
        try {
            const db = await this.open();
            return new Promise((resolve) => {
                const tx = db.transaction(this.metaStoreName, 'readonly');
                const req = tx.objectStore(this.metaStoreName).get(key);
                tx.oncomplete = () => { db.close(); resolve(req.result ?? null); };
                tx.onerror   = () => { db.close(); resolve(null); };
            });
        } catch (e) { return null; }
    }
};

// ================================================

const audioPlayer = document.getElementById('audioPlayer');
const mediaContainer = document.getElementById('mediaContainer');
const audioCanvas = document.getElementById('audioCanvas');
const canvasCtx = audioCanvas.getContext('2d');
const bar = document.getElementById('bar');
const blossomToggle = document.getElementById('blossomToggle');
const playlistToggle = document.getElementById('playlistToggle');
const infoBtn = document.getElementById('infoBtn');
const playlistElement = document.getElementById('playlist');
const playlistOverlay = document.getElementById('playlistOverlay');
const infoOverlay = document.getElementById('infoOverlay');
const progressContainer = document.getElementById('progressContainer');
const playPauseBtn = document.getElementById('playPauseBtn');
const loopBtn = document.getElementById('loopBtn');
const randomBtn = document.getElementById('randomBtn');
const trackTitleEl = document.getElementById('trackTitle');
const trackArtistEl = document.getElementById('trackArtist');
const currentTimeEl = document.getElementById('currentTime');
const durationTimeEl = document.getElementById('durationTime');
const lyricsDisplay = document.getElementById('lyricsDisplay');
const searchInput = document.getElementById('searchInput');
const listTitle = document.getElementById('listTitle');
const sortButton = document.getElementById('sortButton');
const sortModeDisplay = document.getElementById('sortModeDisplay');
const lyricsToggleBtn = document.getElementById('lyricsToggleBtn');
const queueIndicator = document.getElementById('queueIndicator');
const coverArt = document.getElementById('coverArt');
const defaultIcon = document.getElementById('defaultIcon');
const mainContent = document.getElementById('mainContent');
const mainControls = document.getElementById('mainControls');
const bottomSection = document.getElementById('bottomSection');
const volumeContainer = document.getElementById('volumeContainer');
const volumeBtn = document.getElementById('volumeBtn');
const volumeSlider = document.getElementById('volumeSlider');
// عناصر المعادل
let currentEqPreset = 'default';

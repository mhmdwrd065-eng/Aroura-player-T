// ===============================================

function fadeOut(player, duration = DevicePerf && DevicePerf.isLowEnd ? 0.18 : 0.3) { 
    return new Promise(resolve => {
        // [التعديل الجديد]: إذا كانت الشاشة مقفلة، أوقف الصوت فوراً وتخطى المؤقت
        if (document.visibilityState === 'hidden') {
            player.pause();
            resolve();
            return;
        }

        if (!audioContext || !masterGain) {
            player.pause();
            resolve();
            return;
        }

        try {
            const currentTime = audioContext.currentTime;
            const currentGain = masterGain.gain.value;
            masterGain.gain.cancelScheduledValues(currentTime);
            masterGain.gain.setValueAtTime(currentGain, currentTime);
            // استخدام exponentialRampToValueAtTime للتلاشي الطبيعي (أكثر نعومة للأذن)
            // مع قيمة هدف 0.001 بدلاً من 0 لتجنب الفرقعة في نهاية الـ ramp
            masterGain.gain.exponentialRampToValueAtTime(0.001, currentTime + duration);

            setTimeout(() => {
                player.pause();
                // إعادة الـ gain لصفر بعد الإيقاف مباشرةً لضمان نقاء البداية التالية
                if (audioContext && masterGain) {
                    masterGain.gain.cancelScheduledValues(audioContext.currentTime);
                    masterGain.gain.setValueAtTime(0, audioContext.currentTime);
                }
                resolve();
            }, (duration * 1000) + 50); 

        } catch (e) {
            console.error("FadeOut Error:", e);
            player.pause();
            resolve();
        }
    });
}

function fadeIn(player, duration = DevicePerf && DevicePerf.isLowEnd ? 0.22 : 0.4) {
    return new Promise(resolve => {
        // [إصلاح]: استئناف السياق أولاً، ثم متابعة التشغيل بعد الاستئناف
        const resumeAndPlay = () => {
            if (!masterGain) setupAudioContext();

            const targetVolume = parseFloat(document.getElementById('volumeSlider').value);
            player.volume = 1; 

            // [التعديل الجديد]: إذا كانت الشاشة مقفلة، شغل فوراً بدون انتظار التلاشي
            if (document.visibilityState === 'hidden') {
                if (masterGain) {
                    masterGain.gain.cancelScheduledValues(audioContext.currentTime);
                    masterGain.gain.setValueAtTime(targetVolume, audioContext.currentTime);
                } else {
                    player.volume = targetVolume;
                }
                player.play().then(resolve).catch(e => {
                    updatePlayPauseBtn();
                    resolve();
                });
                return;
            }
            
            if (masterGain) {
                const currentTime = audioContext.currentTime;
                masterGain.gain.cancelScheduledValues(currentTime);
                // نبدأ من 0.001 بدلاً من 0 لتجنب بداية مفاجئة
                masterGain.gain.setValueAtTime(0.001, currentTime);
                
                player.play().then(() => {
                    // exponentialRamp لتلاشٍ دخول طبيعي (مثل السمع البشري)
                    masterGain.gain.exponentialRampToValueAtTime(
                        Math.max(targetVolume, 0.001),
                        currentTime + duration
                    );
                    resolve();
                }).catch(e => {
                    updatePlayPauseBtn();
                    showToast('يرجى النقر على زر التشغيل للبدء', 'info');
                    resolve();
                });
            } else {
                player.volume = targetVolume;
                player.play().then(resolve).catch(resolve);
            }
        };

        // استئناف سياق الصوت إن كان متوقفاً، ثم تشغيل الصوت
        if (audioContext && audioContext.state === 'suspended') {
            audioContext.resume()
                .then(resumeAndPlay)
                .catch(e => { console.warn('AudioContext resume failed:', e); resumeAndPlay(); });
        } else {
            resumeAndPlay();
        }
    });
}

function updatePlayPauseBtn() {
    const player = getActivePlayer();
    // استخدام innerHTML بدلاً من textContent لإدراج الـ SVG
    playPauseBtn.innerHTML = (!player || player.paused) ? svgs.play : svgs.pause;
}

async function togglePlayPause() {
    // === التعديل الجديد يبدأ هنا ===
    // إذا لم تكن هناك ملفات محملة، اجعل الزر يفتح نافذة اختيار المجلد
    if (files.length === 0) {
        document.getElementById('folderInput').click();
        return;
    }
    // === انتهى التعديل ===

    if (isTransitioning) {
        showToast('...لحظة...', 'info', 500);
        return;
    }

    const player = getActivePlayer();
    
    // هذا الجزء لم يعد ضرورياً بشكله القديم لأننا عالجنا حالة القائمة الفارغة بالأعلى
    if (!player) { 
        return; 
    }
    
    if (!player.src) { 
        await playFile(files[currentIndex]); 
        return; 
    }
    
    isTransitioning = true;
    try {
        if (player.paused) {
            await fadeIn(player);
        } else {
            await fadeOut(player);
        }
    } catch (err) {
        console.error("Error in togglePlayPause:", err);
        showToast('حدث خطأ أثناء التحكم بالتشغيل', 'error');
    } finally {
        isTransitioning = false;
        updatePlayPauseBtn(); // [إصلاح]: ضمان تحديث الزر دائماً حتى عند الخطأ
    }
}

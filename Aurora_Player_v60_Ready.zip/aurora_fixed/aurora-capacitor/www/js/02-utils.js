// ===============================================
// العشوائية الذكية — Smart Shuffle Core
// ===============================================

/**
 * توليد قائمة عشوائية جديدة من الصفر.
 * يُستدعى فقط عند عدم وجود قائمة صالحة.
 */
function generateShuffledList() {
    shuffledIndices = Array.from({length: files.length}, (_, i) => i);
    // خوارزمية Fisher-Yates للخلط العشوائي المتساوي
    for (let i = shuffledIndices.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffledIndices[i], shuffledIndices[j]] = [shuffledIndices[j], shuffledIndices[i]];
    }
    // ضمان أن الأغنية الحالية تكون الأولى في القائمة حتى لا تتكرر فوراً
    const currentInShuffle = shuffledIndices.indexOf(currentIndex);
    if (currentInShuffle > -1) {
        [shuffledIndices[0], shuffledIndices[currentInShuffle]] = [shuffledIndices[currentInShuffle], shuffledIndices[0]];
    }
    shufflePointer = 0;
    shuffleHistory = [];
}

/**
 * التحقق من أن قائمة العشوائية الحالية صالحة ومطابقة لقائمة الملفات.
 * @returns {boolean} true إذا كانت القائمة صالحة ولا تحتاج إعادة توليد.
 */
function isShuffleListValid() {
    if (!shuffledIndices || shuffledIndices.length !== files.length) return false;
    if (files.length === 0) return false; // [إصلاح] القائمة الفارغة ليست صالحة
    // تحقق سريع: جميع الفهارس ضمن المدى المطلوب وبدون تكرار
    const seen = new Set(shuffledIndices);
    if (seen.size !== files.length) return false;
    for (const idx of seen) {
        if (idx < 0 || idx >= files.length) return false;
    }
    return true;
}

/**
 * إدراج فهارس ملفات جديدة في القائمة العشوائية الحالية
 * عند إضافة أغانٍ جديدة دون إعادة توليد القائمة بالكامل.
 * تُدرج الفهارس الجديدة في مواضع عشوائية بعد المؤشر الحالي فقط.
 * @param {number[]} newIndices - فهارس الأغاني الجديدة في مصفوفة files
 */
function insertNewFilesIntoShuffleList(newIndices) {
    if (!newIndices || newIndices.length === 0) return;
    if (!isShuffleListValid()) {
        // القائمة القديمة غير صالحة — توليد جديد يشمل الكل
        generateShuffledList();
        return;
    }
    // إدراج كل فهرس جديد في موضع عشوائي بعد المؤشر الحالي
    for (const idx of newIndices) {
        const insertPos = shufflePointer + 1 +
            Math.floor(Math.random() * (shuffledIndices.length - shufflePointer));
        shuffledIndices.splice(insertPos, 0, idx);
        // تعديل المؤشر إذا كان الإدراج قبله (لن يحدث هنا، لكن للسلامة)
        if (insertPos <= shufflePointer) shufflePointer++;
    }
}

/**
 * تبديل وضع التشغيل العشوائي.
 * إذا كانت قائمة عشوائية صالحة موجودة مسبقاً، تُستعاد بدلاً من إنشاء قائمة جديدة.
 */
function toggleRandomPlayback() {
    isRandomPlayback = !isRandomPlayback;
    randomBtn.classList.toggle('active', isRandomPlayback);
    // إزالة التركيز بعد الضغط لمنع بقاء حالة التمييز على الهاتف
    randomBtn.blur();

    if (isRandomPlayback) {
        if (isShuffleListValid()) {
            const currentPos = shuffledIndices.indexOf(currentIndex);
            if (currentPos !== -1) {
                shufflePointer = currentPos;
                showToast('تم استعادة قائمة العشوائية', 'success', 2000);
            } else {
                generateShuffledList();
                showToast('قائمة عشوائية جديدة', 'info', 2000);
            }
        } else {
            generateShuffledList();
            showToast('قائمة عشوائية جديدة', 'info', 2000);
        }
    } else {
        showToast('الترتيب الأصلي', 'info', 1500);
    }

    savePlaylistState();
    // تحديث زر العشوائية في ملء الشاشة إن كان مفعلاً
    if (typeof window.updateFsShuffleBtn === 'function') window.updateFsShuffleBtn();
}

// ===============================================
// وظائف مساعدة عامة
// ===============================================
function showToast(message, type = 'info', duration = 3000) {
    const container = document.getElementById('notification-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    setTimeout(() => {
        toast.classList.remove('show');
        // [إصلاح] استخدام { once: true } لضمان إزالة المستمع تلقائياً
        // + مهلة احتياطية بحال لم يُطلَق حدث transitionend (هواتف ضعيفة)
        const removeToast = () => toast.remove();
        toast.addEventListener('transitionend', removeToast, { once: true });
        setTimeout(removeToast, 600); // fallback بعد 0.6 ثانية
    }, duration);
}

function formatTime(seconds) {
    if (isNaN(seconds) || seconds < 0) return "0:00";
    const totalSeconds = Math.floor(seconds);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    const paddedSecs = secs < 10 ? `0${secs}` : secs;
    const paddedMins = minutes < 10 ? `0${minutes}` : minutes;
    if (hours > 0) {
        return `${hours}:${paddedMins}:${paddedSecs}`;
    } else {
        return `${minutes}:${paddedSecs}`;
    }
}

function getActivePlayer() {
    return audioPlayer; 
}

// ===============================================
// نظام استخراج الألوان من غلاف الأغنية (Color Extraction)
// ===============================================
function extractDominantColor(imgEl, callback) {
    // التأكد من تحميل الصورة بالكامل قبل محاولة استخراج اللون
    if (!imgEl.complete || imgEl.naturalWidth === 0) {
        imgEl.onload = () => extractColor(imgEl, callback);
    } else {
        extractColor(imgEl, callback);
    }
}

function extractColor(imgEl, callback) {
    try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        // تصغير الصورة جداً لتسريع العملية (أخذ عينة)
        canvas.width = 32; 
        canvas.height = 32;
        ctx.drawImage(imgEl, 0, 0, 32, 32);

        const data = ctx.getImageData(0, 0, 32, 32).data;
        let r = 0, g = 0, b = 0, count = 0;

        for (let i = 0; i < data.length; i += 16) { 
            const max = Math.max(data[i], data[i+1], data[i+2]);
            const min = Math.min(data[i], data[i+1], data[i+2]);
            
            // تجاهل البيكسلات الشفافة، والبيكسلات شديدة السواد أو البياض للحصول على لون زاهٍ
            if (data[i+3] > 128 && (max - min > 20) && max > 50 && max < 250) {
                r += data[i];
                g += data[i+1];
                b += data[i+2];
                count++;
            }
        }

        // إذا كانت الصورة باهتة جداً ولم يجد ألواناً زاهية، نأخذ المتوسط العام
        if (count === 0) { 
            for (let i = 0; i < data.length; i += 16) {
                if (data[i+3] > 128) {
                    r += data[i]; g += data[i+1]; b += data[i+2]; count++;
                }
            }
        }

        if (count > 0) {
            r = Math.floor(r / count);
            g = Math.floor(g / count);
            b = Math.floor(b / count);

            // تفتيح اللون قليلاً إذا كان داكناً جداً (ليتناسب مع الثيم المظلم للمشغل)
            const brightness = (r * 299 + g * 587 + b * 114) / 1000;
            if (brightness < 120) {
                const factor = 120 / Math.max(brightness, 1);
                r = Math.min(255, Math.floor(r * factor));
                g = Math.min(255, Math.floor(g * factor));
                b = Math.min(255, Math.floor(b * factor));
            }
            callback(r, g, b);
        } else {
            callback(233, 30, 99); // اللون الوردي الافتراضي في حال الفشل
        }
    } catch (e) {
        console.warn('Color extraction failed', e);
        callback(233, 30, 99);
    }
}

function applyThemeColor(r, g, b) {
    document.documentElement.style.setProperty('--accent-color', `rgb(${r}, ${g}, ${b})`);
    document.documentElement.style.setProperty('--accent-color-light', `rgba(${r}, ${g}, ${b}, 0.2)`);
}

function resetThemeColor() {
    // العودة للون المشغل الافتراضي (Pinkish-red)
    applyThemeColor(233, 30, 99);
}

// دالة لتحويل الرموز الخاصة إلى كيانات HTML آمنة
function escapeHTML(str) {
    if (!str) return "";
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


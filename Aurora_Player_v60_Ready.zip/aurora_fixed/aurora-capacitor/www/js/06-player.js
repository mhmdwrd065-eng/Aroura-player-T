async function updateTrackInfo(file) {
    let artist = "فنان غير معروف";
    let title = file.name.substring(0, file.name.lastIndexOf('.')) || file.name;
    let album  = '';

    try {
        const fileKey = `${file.name}_${file.size}`;
        const cachedMeta = await dbManager.loadMeta(fileKey);
        
        if (cachedMeta && (cachedMeta.title || cachedMeta.artist)) {
            if (cachedMeta.artist) artist = cachedMeta.artist;
            if (cachedMeta.title)  title  = cachedMeta.title;
            if (cachedMeta.album)  album  = cachedMeta.album;
        } else {
            const tag = await getMetadata(file);
            if (tag && tag.tags) {
                if (tag.tags.artist) artist = tag.tags.artist;
                if (tag.tags.title)  title  = tag.tags.title;
                if (tag.tags.album)  album  = tag.tags.album;
                // إصلاح: حفظ الميتاداتا في قاعدة البيانات لتجنب إعادة التحليل في كل مرة
                // (كانت تُحفظ فقط عبر processCoverArt إذا وُجدت صورة مدمجة)
                const metaToSave = await dbManager.loadMeta(fileKey) || {};
                if (!metaToSave.title && !metaToSave.artist) {
                    dbManager.saveMeta(fileKey, {
                        ...metaToSave,
                        title:  tag.tags.title  || null,
                        artist: tag.tags.artist || null,
                        album:  tag.tags.album  || null,
                        year:   tag.tags.year   || null,
                        genre:  tag.tags.genre  || null,
                    });
                }
            } else {
                const parts = title.split(' - ');
                if (parts.length > 1) {
                    artist = parts[0].trim();
                    title  = parts[1].trim();
                }
            }
        }
    } catch (e) {
        // استخدام اسم الملف كـ fallback
    }

    // تحديث الواجهة
    handleSmoothMarquee(trackTitleEl, title);
    handleSmoothMarquee(trackArtistEl, artist);

    // ── تحديث الإشعار بالبيانات الحقيقية ──
    msSetText(title, artist, album);
}

   // دالة مساعدة لاكتشاف ما إذا كان النص يحتوي على حروف عربية/RTL
function isRtlLanguage(text) {
    // هذا التعبير النمطي يتحقق من وجود حروف عربية، فارسية، أو عبرية
    const rtlRegex = /[\u0591-\u07FF\uFB1D-\uFDFD\uFE70-\uFEFC]/;
    return rtlRegex.test(text);
}

function handleSmoothMarquee(element, text) {
    // 1. التجهيز وإيقاف أي حركة سابقة
    element.classList.remove('marquee-active');
    element.style.transform = 'translateX(0)';
    element.style.whiteSpace = 'nowrap';
    
    // 2. معالجة النص وتحديد الاتجاه الصحيح
    element.textContent = text;
    element.title = text; // إضافة title لظهور النص بالكامل عند تمرير الماوس (Hover)
    
    // اكتشاف لغة النص لتصحيح الأقواس والرموز (مثل: "Song Name (Remix)")
    const isRtl = isRtlLanguage(text);
    element.dir = isRtl ? 'rtl' : 'ltr';

    const parent = element.parentElement;

    // 3. استخدام requestAnimationFrame بدلاً من setTimeout لضمان الدقة وتجنب التقطيع
    requestAnimationFrame(() => {
        // قراءة الأبعاد بعد أن يقوم المتصفح برسم العنصر بالاتجاه الجديد
        const textWidth = element.scrollWidth;
        const containerWidth = parent.clientWidth;
        const overflow = textWidth - containerWidth;

        // إذا كان النص أطول من الحاوية
        if (overflow > 0) {
            // بما أن النص يتوسط الحاوية عبر الـ CSS، فإن الفائض مقسم على الجانبين
            const dist = overflow / 2;
            const safeDist = dist + 15; // هامش أمان بسبب التدرج اللوني (Mask)

            // 4. تحديد اتجاه الحركة بناءً على لغة النص الفعلية
            // الإنجليزي (LTR): يبدأ من اليمين (موجب) ويتحرك لليسار (سالب)
            // العربي (RTL): يبدأ من اليسار (سالب) ويتحرك لليمين (موجب)
            const startX = isRtl ? -safeDist : safeDist;
            const endX = isRtl ? safeDist : -safeDist;

            // 5. حساب السرعة: جعل السرعة متناسبة مع طول النص (حد أدنى 3.5 ثانية)
            const duration = Math.max((overflow / 25) + 1.5, 3.5);

            // تطبيق المتغيرات
            element.style.setProperty('--start-x', `${startX}px`);
            element.style.setProperty('--end-x', `${endX}px`);
            element.style.setProperty('--marquee-duration', `${duration}s`);

            // تفعيل الحركة
            element.classList.add('marquee-active');
        }
    });
}

// ===============================================
// دالة عرض صورة الغلاف (module-level — نُقلت من closure داخل playFile)
// ===============================================
function setCover(imageUrl, isBlob = false) {
    if (coverArt.dataset.blobUrl) {
        const old = coverArt.dataset.blobUrl;
        // لا نُلغي روابط capacitor:// — هي مسارات أندرويد، ليست Blob objects
        if (!old.startsWith('capacitor://') && !old.startsWith('https://capacitor')) {
            URL.revokeObjectURL(old);
        }
        coverArt.dataset.blobUrl = '';
    }

    coverArt.src = imageUrl;

    if (isBlob) {
        coverArt.dataset.blobUrl = imageUrl;
    }

    coverArt.style.display = 'block';
    defaultIcon.style.display = 'none';

    if (visualizerModeIndex !== -1) {
        coverArt.style.filter = 'blur(8px) brightness(0.7)';
        coverArt.style.transform = 'scale(1.1)';
    }

    extractDominantColor(coverArt, (r, g, b) => {
        applyThemeColor(r, g, b);
    });

    // ── تحديث صورة الغلاف في الإشعار بعد كل تحميل ──
    msSetArtwork(imageUrl);
}

async function playFile(file) {
    if (!file) return;

    if (isTransitioning) {
        // تحميل المقطع...
        return; 
    }
    isTransitioning = true;

    try {
        localStorage.removeItem('aurora_exact_time');
        const currentPlayer = getActivePlayer();
        if (currentPlayer && currentPlayer.src && !currentPlayer.paused) {
            await fadeOut(currentPlayer); 
        } else {
            audioPlayer.pause();
        }

       // === التعديل الجوهري لمنع الطقطقة ===
        // تأكد من أن الصوت صفر تماماً قبل تغيير المصدر
        if (audioContext && masterGain) {
            masterGain.gain.cancelScheduledValues(audioContext.currentTime);
            masterGain.gain.setValueAtTime(0, audioContext.currentTime);
        }

        // === إدارة روابط Blob الصوتية ===
        // نحتفظ بالرابط القديم مؤقتاً لإتاحة وقت لإنهاء التلاشي (FadeOut) بسلام
        const oldAudioUrl = currentAudioBlobUrl;

        // إنشاء رابط جديد للملف الحالي وتحديث المتغير العام
        const fileURL = BlobManager.createAudioUrl(file);
        currentAudioBlobUrl = fileURL;

        // تدمير الرابط القديم بعد ثانية لإعطاء FadeOut فرصة الإنهاء
        if (oldAudioUrl) {
            setTimeout(() => URL.revokeObjectURL(oldAudioUrl), 1000);
        }
        
        let playerToUse = audioPlayer;
        
        // (يمكنك حذف الكود القديم الذي يفحص oldURL من هنا لأنه لم يعد ضرورياً)

        playerToUse.controls = false; 

        [audioPlayer, audioCanvas, coverArt, defaultIcon].forEach(el => el.style.display = 'none');
        lyricsDisplay.style.display = 'none'; isLyricsVisible = false;
        
        playerToUse.src = fileURL;
        playerToUse.load();

        // **تصحيح: تطبيق وقت الاستعادة بشكل موثوق**
        if (restoredSeekTime > 0) {
            const savedTime = restoredSeekTime; // نسخة محلية
            restoredSeekTime = 0; // تصفير المتغير العام فوراً
            
            // مستمع لمرة واحدة يطبق الوقت بمجرد تحميل الميتاداتا
            const seekHandler = () => {
                playerToUse.currentTime = savedTime;
                // تحديث الواجهة فوراً
                currentTimeEl.textContent = formatTime(savedTime);
                const progressPercent = (savedTime / playerToUse.duration) * 100;
                if(isFinite(progressPercent)) {
                     bar.style.transform = `translateX(${progressPercent - 100}%)`;
                }
                // لا إشعار عند الاستئناف — الواجهة تعكس الموضع تلقائياً
            };
            
            playerToUse.addEventListener('loadedmetadata', seekHandler, { once: true });
        }

        playerToUse.volume = parseFloat(volumeSlider.value);
        updateVolumeIcon(); 
        
        playerToUse.style.display = 'block';

        // ** منطق الصور والمؤثرات البصرية **
        defaultIcon.style.display = 'flex';
        coverArt.src = ''; 
        coverArt.style.filter = 'none'; 
        coverArt.style.transform = 'scale(1)';


        const processCoverArt = async () => {
            const fileKey = `${file.name}_${file.size}`;
            let imageFound = false;

            // 1. محاولة التحميل من الكاش (IndexedDB)
            try {
                const cachedData = await dbManager.loadMeta(fileKey);
                if (cachedData && cachedData.imageUrl) {
                    setCover(cachedData.imageUrl, false);
                    return;
                }
            } catch (err) {}

            // 2. قراءة البيانات من الملف
            const tag = await getMetadata(file);

            // 3. عرض الصورة إذا وُجدت في الـ tags
            if (tag && tag.tags && tag.tags.pictureUrl) {
                setCover(tag.tags.pictureUrl, false);
                imageFound = true;
                // حفظ البيانات الكاملة (ليس فقط الصورة) لمنع الكتابة فوق الميتاداتا
                // ملاحظة: fileKey مُعرَّف في الـ scope الخارجي ومتاح هنا كـ closure
                const existingMeta = await dbManager.loadMeta(fileKey) || {};
                dbManager.saveMeta(fileKey, {
                    ...existingMeta,
                    title:    tag.tags.title    || existingMeta.title,
                    artist:   tag.tags.artist   || existingMeta.artist,
                    album:    tag.tags.album    || existingMeta.album,
                    year:     tag.tags.year     || existingMeta.year,
                    genre:    tag.tags.genre    || existingMeta.genre,
                    imageUrl: tag.tags.pictureUrl
                });
            }

            // 4. البحث عن صورة داخل المجلد إذا لم نجد صورة داخل الأغنية
            if (!imageFound) {
                const folderCoverFile = findFolderCover(file);
                if (folderCoverFile) {
                    // URI proxy: استخدم playUrl مباشرة بدون createObjectURL
                    const coverUrl = (folderCoverFile.isUriProxy && folderCoverFile.playUrl)
                        ? folderCoverFile.playUrl
                        : URL.createObjectURL(folderCoverFile);
                    setCover(coverUrl, !folderCoverFile.isUriProxy);
                } else {
                    coverArt.style.display = 'none';
                    defaultIcon.style.display = 'flex';
                    resetThemeColor();
                    // مسح صورة الغلاف من إشعار الهاتف عند غيابها في الأغنية الحالية
                    msSetArtwork(null);
                }
            }
        };

        // تشغيل معالجة الصور دون انتظارها (لعدم تأخير تشغيل الصوت)
        processCoverArt();
        
        playerToUse.loop = (isLoopMode === 1);
        await updateTrackInfo(file);
        updatePlaylistHighlight();
        updateQueueIndicator();
        
        // إعادة ضبط الكلمات والمؤشر عند تغيير الأغنية
        lyricsData = [];
        currentLyricIndex = 0;
        const companionFile = searchForCompanionFile(file);

        lyricsToggleBtn.classList.remove('active');
        // تحديث زر الكلمات في ملء الشاشة فوراً عند التحول للأغنية الجديدة
        if (typeof window.updateFsLyricsBtn === 'function') window.updateFsLyricsBtn();

        if (companionFile) {
            // تعطيل الزر مؤقتاً حتى ينتهي تحليل الكلمات (لتجنب حالة التسابق)
            lyricsToggleBtn.disabled = true;

            const _parseLyricsContent = (text) => {
                lyricsData = companionFile.name.endsWith('.lrc') ? parseLrc(text) : parseSrt(text);
                lyricsToggleBtn.disabled = false;
                if (typeof window.updateFsLyricsBtn === 'function') window.updateFsLyricsBtn();
            };
            const _onLyricsError = () => {
                lyricsToggleBtn.disabled = false;
                if (typeof window.updateFsLyricsBtn === 'function') window.updateFsLyricsBtn();
            };

            // URI proxy (أندرويد) → fetch نصي
            if (companionFile.isUriProxy && companionFile.text) {
                companionFile.text().then(_parseLyricsContent).catch(_onLyricsError);
            } else {
                // ملف عادي → FileReader
                const reader = new FileReader();
                reader.onload  = (e) => _parseLyricsContent(e.target.result);
                reader.onerror = _onLyricsError;
                reader.readAsText(companionFile);
            }
        } else {
            lyricsToggleBtn.disabled = false;
        }
        
        setupAudioContext(); 
        if (visualizerModeIndex !== -1) {
            audioCanvas.style.display = 'block';
            // إعادة ربط المحلّل بالصوت عند تغيير الأغنية والمؤثرات مفعلة
            if (masterGain && analyser) {
                try { masterGain.connect(analyser); } catch (_) {}
            }
            if (animationFrameId === null) visualize();
        }

        await fadeIn(playerToUse);

        // استعادة سرعة التشغيل المختارة
        if (typeof restorePlaybackSpeed === 'function') restorePlaybackSpeed();

        // تحديث معلومات المقطع في ملء الشاشة إن كان نشطاً
        if (typeof updateFsTrackInfo === 'function') updateFsTrackInfo();

        // تحديث حالة التشغيل في الإشعار فور بدء الصوت
        // (النص والصورة يُحدَّثان بشكل مستقل عبر updateTrackInfo و setCover)
        updatePositionState();

    } catch (error) {
        console.error("Error during playFile transition:", error);
        showToast('حدث خطأ أثناء تشغيل الملف', 'error');
    } finally {
        isTransitioning = false;
    }
}

// ===============================================
// == إعداد سياق الصوت والمعادل (محسن للأداء)
// ===============================================
// متغير عالمي للضاغط الديناميكي
var compressorNode = null;
// (تمت إزالة toneFilter — السلسلة الصوتية: masterGain → compressorNode مباشرةً)

function setupAudioContext() {
    try {
        if (getActivePlayer() !== audioPlayer || !audioPlayer.src) return;
        
        if (!audioContext) {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }

        // FFT تكيفي: 512 للأجهزة الضعيفة — 1024 للأجهزة القوية
        if (!analyser) {
            analyser = audioContext.createAnalyser();
            analyser.fftSize = (typeof DevicePerf !== 'undefined') ? DevicePerf.fftSize : 1024;
            // [تحسين] تنعيم أقل على الأجهزة الضعيفة (0.75) لتقليل الحسابات الداخلية للمحلّل
            // ويُعوَّض بالتنعيم الخارجي في _smoothedFreq
            analyser.smoothingTimeConstant = (typeof DevicePerf !== 'undefined' && DevicePerf.isLowEnd) ? 0.75 : 0.82;
            analyser.minDecibels = -90;
            analyser.maxDecibels = -10;
            freqDataArray = new Uint8Array(analyser.frequencyBinCount);
            timeDataArray = new Uint8Array(analyser.fftSize);
        }

        if (!mediaSource) {
            mediaSource = audioContext.createMediaElementSource(audioPlayer);
        }

        // بناء الرسم البياني (Graph) مرة واحدة فقط
        if (!isEqSetup) {
            preampGain = audioContext.createGain();
            preampGain.gain.value = 1.0;

            masterGain = audioContext.createGain();

            // ── ضاغط ديناميكي احترافي لمنع التشويه والقطع ──
            // يضمن صوتاً نظيفاً حتى عند تعزيز الباص بقوة في المعادل
            compressorNode = audioContext.createDynamicsCompressor();
            compressorNode.threshold.value = -18;   // يبدأ الضغط عند -18 dBFS
            compressorNode.knee.value      = 20;    // انتقال ناعم جداً (Soft Knee واسع)
            compressorNode.ratio.value     = (typeof DevicePerf !== 'undefined' && DevicePerf.isLowEnd) ? 2 : 3; // [تحسين] نسبة أخف للأجهزة الضعيفة (أقل معالجة)
            compressorNode.attack.value    = 0.005; // استجابة 5ms
            compressorNode.release.value   = 0.35;  // إفراج 350ms

            eqBands = eqFrequencies.map((freq, index) => {
                const filter = audioContext.createBiquadFilter();
                if (index === 0) {
                    filter.type = 'lowshelf';
                } else if (index === eqFrequencies.length - 1) {
                    filter.type = 'highshelf';
                } else {
                    filter.type = 'peaking';
                    // Q مضبوط لكل نطاق: ضيّق للترددات العالية، واسع للمنخفضة
                    // 7 قيم للنطاقات 1-7 (بما يتطابق عدد الفلاتر peaking تماماً)
                    const qValues = [1.0, 1.2, 1.2, 1.4, 1.4, 1.6, 1.8];
                    filter.Q.value = qValues[index - 1] ?? 1.4;
                }
                filter.frequency.value = freq;
                filter.gain.value = 0;
                return filter;
            });

            // تطبيق إعدادات المعادل المحفوظة من الواجهة على السياق
            const preampSlider = document.getElementById('preampSlider');
            if (preampSlider) preampGain.gain.value = parseFloat(preampSlider.value);
            eqBands.forEach((filter, index) => {
                const slider = document.querySelector(`.eq-slider[data-index="${index}"]`);
                if (slider) filter.gain.value = parseFloat(slider.value);
            });

            // ── ربط السلسلة الصوتية الاحترافية ──
            // المصدر → مضخم → فلاتر EQ → تحكم بالصوت → ضاغط → مكبّر
            mediaSource.connect(preampGain);
            let lastNode = preampGain;
            eqBands.forEach(filter => {
                lastNode.connect(filter);
                lastNode = filter;
            });
            lastNode.connect(masterGain);

            // السلسلة الصوتية المباشرة: masterGain → compressorNode
            masterGain.connect(compressorNode);
            compressorNode.connect(audioContext.destination);

            // ملاحظة: ربط المحلّل (analyser) يتم عبر toggleBlossomInternal فقط
            // حتى لا يستهلك موارد الجهاز إلا عند تفعيل المؤثرات البصرية فعلاً

            isEqSetup = true;
        }

        if (audioContext.state === 'suspended') {
            audioContext.resume().catch(e => console.warn('Error resuming audio context:', e));
        }

        // [تحسين] ضبط حجم الـ canvas بدقة بكسل صحيحة لمنع الضبابية
        // يُستدعى مرة واحدة فقط لأن isEqSetup يمنع التكرار
        if (typeof resizeAudioCanvas === 'function') resizeAudioCanvas();

    } catch (error) {
        console.error('Error setting up audio context:', error);
    }
}

// ===============================================
// وظائف التحكم بالصوت ومعالجة الأخطاء
// ===============================================

function handleVolumeChange() {
    const newVolume = parseFloat(volumeSlider.value);
    
    // التحديث البصري
    updateVolumeIcon();
    const percent = newVolume * 100;
    volumeSlider.style.background = `linear-gradient(to right, var(--accent-color) ${percent}%, rgba(255, 255, 255, 0.1) ${percent}%)`;

    // التطبيق الصوتي الناعم
    if (audioContext && masterGain) {
        const currentTime = audioContext.currentTime;
        masterGain.gain.cancelScheduledValues(currentTime);
        masterGain.gain.setValueAtTime(masterGain.gain.value, currentTime);
        // [تحسين] 50ms لاستجابة أسرع مع تجنب الخشخشة
        masterGain.gain.linearRampToValueAtTime(newVolume, currentTime + 0.05);
    } else {
        // Fallback
        audioPlayer.volume = newVolume;
    }
    
    if (newVolume > 0) {
        previousVolume = newVolume;
    }
}

function updateVolumeIcon() {
    const volume = parseFloat(volumeSlider.value);
    // مسح المحتوى القديم وإضافة الـ SVG المناسب
    volumeBtn.innerHTML = ''; 
    if (volume === 0) {
        volumeBtn.innerHTML = svgs.volumeMute;
    } else if (volume < 0.5) {
        volumeBtn.innerHTML = svgs.volumeLow;
    } else {
        volumeBtn.innerHTML = svgs.volumeHigh;
    }
}

function toggleMute() {
    const currentVolume = parseFloat(volumeSlider.value);
    if (currentVolume > 0) {
        volumeSlider.value = 0;
    } else {
        volumeSlider.value = previousVolume;
    }
    handleVolumeChange();
}

function handleMediaError(e) {
    // تجاهل الخطأ إذا كانت القائمة فارغة (يحدث طبيعياً عند مسح القائمة) أو إذا لم يكن هناك مسار
    if (files.length === 0 || !audioPlayer.src || audioPlayer.currentSrc === "") {
        return;
    }
    
    console.error('Media Playback Error:', e);
    
    // إنشاء عداد للأخطاء المتتالية لمنع الحلقة اللانهائية
    if (typeof window.playbackErrorCount === 'undefined') {
        window.playbackErrorCount = 0;
    }
    window.playbackErrorCount++;

    if (files.length > 0 && files[currentIndex]) {
        showToast(`تعذر تشغيل الملف: ${files[currentIndex].name} (قد يكون الملف غير مدعوم أو تالف)`, 'error');
    }

    // إذا فشلت 3 أغانٍ متتالية، أوقف المحاولة
    if (window.playbackErrorCount >= 3) {
        showToast('تم إيقاف التشغيل التلقائي لوجود عدة ملفات غير قابلة للتشغيل.', 'error');
        window.playbackErrorCount = 0; // تصفير العداد
        updatePlayPauseBtn();
        return;
    }
    
    setTimeout(() => {
        playNext();
    }, 1000); // زيادة وقت الانتظار قليلاً لعدم إرهاق المتصفح
}

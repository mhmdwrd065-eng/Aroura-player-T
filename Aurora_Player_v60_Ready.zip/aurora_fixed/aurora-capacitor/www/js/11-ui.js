function hideOverlay(overlayId) {
    const overlay = document.getElementById(overlayId);
    if (overlay) {
        overlay.style.display = 'none';
    }
    
    // مسح البحث عند إخفاء قائمة التشغيل
    if (overlayId === 'playlistOverlay') {
        clearSearch();
    }

    // === الإصلاح الجوهري هنا ===
    // إذا تم إخفاء القائمة برمجياً (عند اختيار أغنية مثلاً) والرابط لا يزال يحمل اسمها، نعود خطوة للخلف لتنظيف السجل
    if (window.location.hash === '#' + overlayId) {
        history.back();
    }
}

// متغير لتخزين آخر ثانية تم عرضها (يوضع خارج الدالة)
let lastSecond = -1;

// إعادة ضبط العداد عند بدء تشغيل أغنية جديدة لتجنب خلل عرض الوقت
// إذا بدأت الأغنية الجديدة عند نفس الثانية التي توقفت عندها السابقة
audioPlayer.addEventListener('emptied', () => { lastSecond = -1; });

function handleTimeUpdate() {
    // 1. الخروج إذا كنا نقوم بالسحب (Seeking)
    if (isSeeking) return;

    const player = getActivePlayer();
    if (!player || !isFinite(player.duration)) return;
    
    const { currentTime, duration } = player;

    // 2. تحديث شريط التقدم مباشرة (GPU سيتولى النعومة)
    const percent = (currentTime / duration) * 100;
    bar.style.transform = `translateX(${percent - 100}%)`;

    // 3. تحديث النصوص (الوقت) فقط إذا تغيرت الثانية فعلياً
    const currentSecFloor = Math.floor(currentTime);
    if (currentSecFloor !== lastSecond) {
        lastSecond = currentSecFloor;
        currentTimeEl.textContent = formatTime(currentTime);
        durationTimeEl.textContent = formatTime(duration);
        
        // حفظ التوقيت الدقيق كل ثانية (كل 3 ثواني سابقاً)
        // لا نحفظ إذا كنا في البداية تماماً لتجنب الكتابة الزائدة
        if (currentSecFloor > 0) {
            localStorage.setItem('aurora_exact_time', currentTime);
        }
    }

    // 4. تحديث الكلمات (نتركها كما هي للدقة)
    updateLyricsDisplay(currentTime);
}

// ── متغير مؤقت لحفظ موضع السحب حتى يُطبَّق على الصوت عند الإفراج ──
let pendingSeekTime = -1;

/**
 * seekVisual(e)
 * يُحدّث شريط التقدم والوقت المعروض فقط دون المساس بـ currentTime.
 * يُستدعى أثناء السحب (mousemove / touchmove) لضمان بصريات سلسة وصوت خالٍ من التقطيع.
 */
function seekVisual(e) {
    const player = getActivePlayer();
    if (!player || !isFinite(player.duration)) return;
    const rect = progressContainer.getBoundingClientRect();
    const touch = e.changedTouches
        ? (e.touches && e.touches.length > 0 ? e.touches[0] : e.changedTouches[0])
        : null;
    const clickX = touch ? touch.clientX : e.clientX;
    const clickPosition = Math.max(0, Math.min(clickX - rect.left, rect.width));
    pendingSeekTime = (clickPosition / rect.width) * player.duration;
    // تحديث بصري فقط — بدون أي تغيير على الصوت
    bar.style.transform = `translateX(${(pendingSeekTime / player.duration) * 100 - 100}%)`;
    currentTimeEl.textContent = formatTime(pendingSeekTime);
}

/**
 * applySeek()
 * يُطبّق موضع السحب المحفوظ (pendingSeekTime) على المشغّل فعلياً.
 * يُستدعى مرة واحدة فقط عند رفع الإصبع أو الماوس (mouseup / touchend)
 * مما يمنع التقطيع الصوتي الناتج عن إعادة المزامنة المتكررة.
 */
function applySeek() {
    if (pendingSeekTime < 0) return;
    const player = getActivePlayer();
    if (!player || !isFinite(player.duration)) { pendingSeekTime = -1; return; }
    player.currentTime = pendingSeekTime;
    updatePositionState();
    updateLyricsDisplay(pendingSeekTime, true);
    pendingSeekTime = -1;
}

function scrollToCurrentSong() {
    const activeItem = playlistElement.querySelector('.playlist-item.active');
    if (activeItem) {
        activeItem.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });
    }
}

function showCustomConfirm(message, onConfirmCallback) {
    const modal = document.getElementById('customConfirmModal');
    const messageEl = document.getElementById('confirmMessage');
    const yesBtn = document.getElementById('confirmYesBtn');
    const noBtn = document.getElementById('confirmNoBtn');

    messageEl.textContent = message;
    
    // استخدام دالتك الحالية لإظهار الـ Overlay مع التعديل على مسار التاريخ
    modal.style.display = 'flex';
    if (window.location.hash !== '#customConfirmModal') {
        history.pushState({ overlay: 'customConfirmModal' }, '', '#customConfirmModal');
    }

    // إزالة الأحداث السابقة لمنع تكرار تنفيذ دالة الحذف بالخطأ
    const newYesBtn = yesBtn.cloneNode(true);
    const newNoBtn = noBtn.cloneNode(true);
    yesBtn.parentNode.replaceChild(newYesBtn, yesBtn);
    noBtn.parentNode.replaceChild(newNoBtn, noBtn);

    newYesBtn.onclick = () => {
        hideOverlay('customConfirmModal');
        onConfirmCallback();
    };

    newNoBtn.onclick = () => {
        hideOverlay('customConfirmModal');
    };
}


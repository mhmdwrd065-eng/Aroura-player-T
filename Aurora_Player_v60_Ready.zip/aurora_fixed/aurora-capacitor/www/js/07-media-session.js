
// ===============================================
// وظائف التحكم بالتشغيل والواجهة
// ===============================================

// ═══════════════════════════════════════════════════════════════════════
//  نظام الإشعارات الموسيقية الاحترافي (Media Session API)
//
//  التدفق الصحيح:
//  ① عند بدء تشغيل أغنية → updateTrackInfo() تقرأ العنوان/الفنان/الألبوم
//    الحقيقيين من ID3 tags ثم تستدعي msApply() لتطبيق الإشعار فوراً
//  ② عند تحميل صورة الغلاف → setCover() تستدعي msSetArtwork()
//    التي تحوّل blob: → data: URL (لأن أندرويد وiOS يرفضان blob في الإشعارات)
//    ثم تستدعي msApply() لتحديث الصورة في الإشعار
//  ③ أثناء التشغيل → updatePositionState() تحدّث شريط التقدم وحالة التشغيل
// ═══════════════════════════════════════════════════════════════════════

// الحالة الداخلية للإشعار — نحتفظ بها هنا لأن كل قطعة تُحمَّل بشكل مستقل
var _msTitle   = '';
var _msArtist  = '';
var _msAlbum   = '';
var _msArtworkDataUrl = null; // data: URL جاهز للإشعار — var لضمان window._msArtworkDataUrl
var _msArtworkTimer   = null; // للحد من التحديثات المتكررة

/** يبني قائمة الأحجام المطلوبة بواسطة Media Session */
function _msBuildArtwork(url) {
    if (!url) return [];
    const mime = url.startsWith('data:image/png') ? 'image/png' : 'image/jpeg';
    return ['96x96','128x128','192x192','256x256','384x384','512x512']
           .map(s => ({ src: url, sizes: s, type: mime }));
}

/**
 * يطبّق الحالة الداخلية الحالية على navigator.mediaSession
 * — النقطة الوحيدة التي تلمس الـ API
 */
function msApply() {
    if (!('mediaSession' in navigator)) return;
    try {
        navigator.mediaSession.metadata = new MediaMetadata({
            title:   _msTitle  || 'Aurora Player',
            artist:  _msArtist || '',
            album:   _msAlbum  || 'Aurora Player',
            artwork: _msBuildArtwork(_msArtworkDataUrl)
        });
    } catch (e) { console.warn('[MS] metadata error:', e); }
}

/**
 * يُحدّث النصوص في الإشعار — يُستدعى من updateTrackInfo بعد قراءة البيانات الحقيقية
 */
function msSetText(title, artist, album) {
    if (title  !== undefined) _msTitle  = title  || '';
    if (artist !== undefined) _msArtist = artist || '';
    if (album  !== undefined) _msAlbum  = album  || '';
    msApply();
}

/**
 * يُحدّث صورة الغلاف في الإشعار — يُستدعى من setCover بعد كل تحميل للصورة
 * يحوّل blob: → data: URL للتوافق الكامل مع أندرويد وiOS وويندوز
 */
function msSetArtwork(imageUrl) {
    if (!('mediaSession' in navigator)) return;

    // إلغاء أي تحديث معلق (حماية من استدعاءات متتالية سريعة)
    if (_msArtworkTimer) { clearTimeout(_msArtworkTimer); _msArtworkTimer = null; }

    // إذا لم تكن هناك صورة، امسح الأرتورك القديم فوراً من الإشعار
    if (!imageUrl) {
        _msArtworkDataUrl = null;
        msApply();
        return;
    }

    _msArtworkTimer = setTimeout(async () => {
        try {
            let dataUrl = imageUrl;
            // capacitor:// أو https://capacitor → رابط مباشر، لا يحتاج تحويل
            const isCapacitor = imageUrl.startsWith('capacitor://') || imageUrl.startsWith('https://capacitor');
            if (imageUrl.startsWith('blob:') && !isCapacitor) {
                // تحويل blob: → data: لضمان ظهور الصورة في جميع أنظمة الإشعارات
                const resp = await fetch(imageUrl);
                const blob = await resp.blob();
                dataUrl = await new Promise(res => {
                    const fr = new FileReader();
                    fr.onloadend = () => res(fr.result);
                    fr.readAsDataURL(blob);
                });
            }
            _msArtworkDataUrl = dataUrl;
            msApply();
        } catch (e) {
            // في حال فشل التحويل، نستخدم الرابط الأصلي كـ fallback
            _msArtworkDataUrl = imageUrl;
            msApply();
        }
        _msArtworkTimer = null;
    }, 100);
}

/** يُعيد ضبط الإشعار عند إيقاف التشغيل / مسح القائمة */
function msClear() {
    _msTitle = _msArtist = _msAlbum = '';
    _msArtworkDataUrl = null;
    if (!('mediaSession' in navigator)) return;
    try { navigator.mediaSession.metadata = null; } catch(_) {}
}

// ── تحديث شريط التقدم وحالة التشغيل في شاشة القفل ──────────────────────
function updatePositionState() {
    if (!('mediaSession' in navigator)) return;
    const player = getActivePlayer();
    const playing = !!(player && !player.paused);

    // تحديث أيقونة play/pause في الإشعار النظامي (PWA)
    try {
        navigator.mediaSession.playbackState = playing ? 'playing' : 'paused';
    } catch(_) {}

    if (player && isFinite(player.duration) && player.duration > 0) {
        try {
            navigator.mediaSession.setPositionState({
                duration:     player.duration,
                playbackRate: player.playbackRate || 1,
                position:     Math.min(player.currentTime, player.duration)
            });
        } catch(_) {}
    }

    // تحديث أيقونة play/pause في إشعار خدمة الأندرويد الأمامية
    if (typeof AuroraBridge !== 'undefined' && AuroraBridge.isNative()) {
        AuroraBridge.updateNotification({
            title:     _msTitle          || 'Aurora Player',
            artist:    _msArtist         || '',
            album:     _msAlbum          || '',
            isPlaying: playing,
            artwork:   _msArtworkDataUrl || null
        });
    }
}

// دالة قديمة — تمت إعادة هيكلتها (نحتفظ بها فارغة لمنع أي خطأ إذا استُدعيت في مكان آخر)
function updateMediaSession() { msApply(); }

// ===============================================
// دوال معالجة الكلمات المحسنة (LRC & SRT Parsing)
